import React
import linphonesw

@objc(SipModule)
class SipModule: RCTEventEmitter {
  private let factory = Factory.Instance
  private var core: Core
  private var listener = CoreDelegateStub()
  private var call: Call? {
    get {
      return core.currentCall ?? core.calls.first
    }
  }
  
  override static func moduleName() -> String! {
    return "SipModule"
  }
  
  override func supportedEvents() -> [String]! {
    return ["incomingReceived", "callReleased"]
  }
  
  override static func requiresMainQueueSetup() -> Bool {
    return false
  }
  
  override init() {
#if DEBUG
    LoggingService.Instance.logLevel = LogLevel.Debug
#endif
    
    try! core = factory.createCore(configPath: nil, factoryConfigPath: nil, systemContext: nil)
    
    super.init()
    
    listener = CoreDelegateStub(
      onCallStateChanged: {
        (core: Core, call: Call, state: Call.State?, message: String) in
        switch(state) {
        case .IncomingReceived:
          let payload = [
            "displayName": call.remoteAddress?.displayName,
            "username": call.remoteAddress?.username
          ]

          self.sendEvent(withName: "incomingReceived", body: payload)
          
        case .Released:
          self.sendEvent(withName: "callReleased", body: [:])
          
        default:
          return
        }
      },
      onAccountRegistrationStateChanged: {
        (core: Core, account: Account, state: RegistrationState, message: String) in
        let eee = message
        
      }
    )
    
    core.addDelegate(delegate: listener)
  }
  
  @objc
  func login(_ username: String, password: String, domain: String) {
    do {
      let authInfo = try Factory.Instance.createAuthInfo(username: username, userid: nil,
                                                         passwd: password, ha1: nil, realm: nil,
                                                         domain: domain, algorithm: nil)
      let params = try core.createAccountParams()
      let identityAddress = try Factory.Instance.createAddress(addr: "sip:\(username)@\(domain)")
      try params.setIdentityaddress(newValue: identityAddress)
      params.registerEnabled = true
      
      let serverAddress = try Factory.Instance.createAddress(addr: "sip:\(domain)")
      try serverAddress.setTransport(newValue: .Tls)
      try params.setServeraddress(newValue: serverAddress)
      
      let account = try core.createAccount(params: params)
      
      core.addAuthInfo(info: authInfo)
      try core.addAccount(account: account)
      core.defaultAccount = account
      
      try core.start()
    } catch {
      
    }
  }
  
  @objc
  func startCall(_ phone: String, domain: String) {
    do {
      let address = core.interpretUrl(url: "\(phone)@\(domain)", applyInternationalPrefix: true)
      
      guard let address = address else {
        return
      }
      
      try address.setDisplayname(newValue: "Caller")
      let params = try core.createCallParams(call: nil)
      
      let _ = core.inviteAddressWithParams(addr: address, params: params)
    } catch {
      
    }
  }
  
  @objc
  func answerCall() {
    do {
      try call?.accept()
    } catch {
      
    }
  }
  
  @objc
  func endCall() {
    do {
      try call?.terminate()
    } catch {
      
    }
  }
  
  @objc
  func sendDtmf(_ dtmf: String) {
    do {
      try call?.sendDtmf(dtmf: dtmf.utf8CString[0])
    } catch {
      
    }
  }
  
  @objc
  func changeAudioOutput(_ output: Int) {
    call?.outputAudioDevice = core.audioDevices.first { device in
      device.type.rawValue == output
    }
  }
  
  @objc
  func toggleMicrophone() {
    core.micEnabled = !core.micEnabled
  }
}
