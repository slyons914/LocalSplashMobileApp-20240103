#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

@interface RCT_EXTERN_MODULE(SipModule, RCTEventEmitter)

RCT_EXTERN_METHOD(login:(NSString *)username password:(NSString *)password domain:(NSString *)domain)

RCT_EXTERN_METHOD(startCall:(NSString *)phone domain:(NSString *)domain)

RCT_EXTERN_METHOD(answerCall)

RCT_EXTERN_METHOD(endCall)

RCT_EXTERN_METHOD(changeAudioOutput:(NSInteger)output)

RCT_EXTERN_METHOD(toggleMicrophone)

@end
