import { AppRegistry } from "react-native"

import TrackPlayer from "react-native-track-player"

import { name } from "./app.json"
import { App } from "./src/App"

AppRegistry.registerComponent(name, () => App)
TrackPlayer.registerPlaybackService(() => require("./player-service"))
