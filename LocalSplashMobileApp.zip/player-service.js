module.exports = Promise.resolve
