import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    paddingTop: insets.top || 16,
    backgroundColor: colors.background,
  },
  text: {
    color: colors.orangePrimary,
    alignSelf: "flex-start",
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
}))
