import { View } from "react-native"

import { useNavigation } from "@react-navigation/native"

import { Typography } from "@components"
import { Routes, Stacks } from "@utils/constants"

import { useStyles } from "./styles"

export const Header = () => {
  const { navigate } = useNavigation()

  const styles = useStyles()

  const onPress = () => {
    navigate(Stacks.Home, { screen: Routes.Home })
  }

  return (
    <View style={styles.container}>
      <Typography onPress={onPress} style={styles.text}>
        Cancel
      </Typography>
    </View>
  )
}
