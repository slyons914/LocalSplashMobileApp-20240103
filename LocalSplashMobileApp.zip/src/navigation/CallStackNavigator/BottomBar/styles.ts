import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme, insets }) => ({
  container: {
    paddingTop: 16,
    gap: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderTopWidth: 1,
    borderTopColor: isDarkTheme ? colors.blueDark : colors.greyLight,
    paddingBottom: insets.bottom || 16,
    backgroundColor: colors.background,
  },
  tab: {
    gap: 8,
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 32,
    backgroundColor: isDarkTheme ? colors.lightBlack : colors.greyLight,
  },
  activeTab: {
    backgroundColor: isDarkTheme ? colors.blueDark : colors.blue,
  },
  activeText: {
    color: colors.white,
  },
}))
