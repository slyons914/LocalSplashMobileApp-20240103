import { TouchableOpacity, View } from "react-native"

import { BottomTabBarProps } from "@react-navigation/bottom-tabs"

import { Icon, Typography } from "@components"
import { Routes } from "@utils/constants"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Tab {
  route: Routes
  name: string
  icon: IconName
}

const tabs: Array<Tab> = [
  {
    route: Routes.DialPad,
    name: "Dial Pad",
    icon: "dialpad",
  },
  {
    route: Routes.CallLog,
    name: "Call Log",
    icon: "callLog",
  },
]

export const BottomBar = ({ state, navigation }: BottomTabBarProps) => {
  const styles = useStyles()

  const { white, subText } = useColors()

  const { navigate } = navigation

  const renderTab = ({ route, name, icon }: Tab, index: number) => {
    const isActive = state.index === index

    return (
      <TouchableOpacity
        key={index}
        onPress={() => navigate(route)}
        style={[styles.tab, isActive && styles.activeTab]}
      >
        <Icon name={icon} width={20} height={20} stroke={isActive ? white : subText} />
        <Typography style={isActive && styles.activeText}>{name}</Typography>
      </TouchableOpacity>
    )
  }

  return <View style={styles.container}>{tabs.map(renderTab)}</View>
}
