import { useEffect, useState } from "react"

import { NavigationContainer } from "@react-navigation/native"
import {
  NativeStackNavigationOptions,
  createNativeStackNavigator,
} from "@react-navigation/native-stack"
import SplashScreen from "react-native-splash-screen"

import { Stacks } from "@utils/constants"
import { AuthHelper } from "@utils/helpers"

import { CallStackNavigator } from "./CallStackNavigator"
import { HomeStackNavigator } from "./HomeStackNavigator"
import { LeadsStackNavigator } from "./LeadsStackNavigator"
import { LoginStackNavigator } from "./LoginStackNavigator"
import { MessageStackNavigator } from "./MessageStackNavigator"
import { SettingsStackNavigator } from "./SettingsNavigator"
import { RouteParamList } from "./types"

const Stack = createNativeStackNavigator<RouteParamList>()

const options: NativeStackNavigationOptions = {
  headerShown: false,
}

export const Navigation = () => {
  const [initialScreen, setInitialScreen] = useState<Stacks | null>(null)

  useEffect(() => {
    AuthHelper.getIsAuthorized().then((isAuthorized) => {
      setInitialScreen(isAuthorized ? Stacks.Home : Stacks.Login)
      SplashScreen.hide()
    })
  }, [])

  if (!initialScreen) return null

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={options} initialRouteName={initialScreen}>
        <Stack.Screen name={Stacks.Login} component={LoginStackNavigator} />
        <Stack.Screen name={Stacks.Call} component={CallStackNavigator} />
        <Stack.Screen name={Stacks.Home} component={HomeStackNavigator} />
        <Stack.Screen name={Stacks.Leads} component={LeadsStackNavigator} />
        <Stack.Screen name={Stacks.Settings} component={SettingsStackNavigator} />
        <Stack.Screen name={Stacks.Messages} component={MessageStackNavigator} />
      </Stack.Navigator>
    </NavigationContainer>
  )
}
