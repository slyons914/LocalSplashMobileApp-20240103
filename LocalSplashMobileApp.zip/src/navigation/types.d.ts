import { ParamListBase } from "@react-navigation/native"
import { NativeStackScreenProps } from "@react-navigation/native-stack"

import { Routes } from "@utils/constants"

interface RouteParamList extends ParamListBase {
  [Routes.Login]: undefined
  [Routes.Home]: undefined
  [Routes.Welcome]: undefined
  [Routes.Terms]: undefined
  [Routes.Notifications]: undefined
  [Routes.Permissions]: undefined
  [Routes.Code]: { phoneNumber: string; phoneRawNumber: string }
  [Routes.Leads]: undefined
  [Routes.LeadsDetails]: { id: string | number }
  [Routes.DialPad]: { phoneNumber?: string } | undefined
  [Routes.CallLog]: undefined
  [Routes.Settings]: undefined
  [Routes.PersonalInfo]: undefined
  [Routes.SettingsNotifications]: undefined
  [Routes.SettingsMakeCalls]: undefined
  [Routes.SettingsGSM]: undefined
  [Routes.RingerBehavior]: undefined
  [Routes.BusinessInformation]: undefined
  [Routes.PrimarySearchPhrase]: undefined
}

declare global {
  type ScreenProps<T extends Routes> = NativeStackScreenProps<RouteParamList, T>

  namespace ReactNavigation {
    interface RootParamList extends RouteParamList {}
    type RouteName = keyof typeof Routes
  }
}
