import { useNavigation } from "@react-navigation/native"
import {
  NativeStackNavigationOptions,
  createNativeStackNavigator,
} from "@react-navigation/native-stack"

import { Header } from "@components"
import { LeadsDetailsScreen, LeadsScreen } from "@screens"
import { Routes } from "@utils/constants"
import { withPlayer } from "@utils/hocs"

import { RouteParamList } from "../types"

const Stack = createNativeStackNavigator<RouteParamList>()

const StackNavigator = () => {
  const { navigate } = useNavigation()

  const options: NativeStackNavigationOptions = {
    header: () => <Header onLeftPress={() => navigate(Routes.Home)} />,
  }
  return (
    <Stack.Navigator screenOptions={options}>
      <Stack.Screen name={Routes.Leads} component={LeadsScreen} />
      <Stack.Screen name={Routes.LeadsDetails} component={LeadsDetailsScreen} />
    </Stack.Navigator>
  )
}
export const LeadsStackNavigator = withPlayer(StackNavigator)
