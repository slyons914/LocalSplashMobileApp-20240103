import {
  BottomTabBarProps,
  BottomTabNavigationOptions,
  createBottomTabNavigator,
} from "@react-navigation/bottom-tabs"
import { useNavigation } from "@react-navigation/native"

import { Header } from "@components"
import { HomeScreen, LeadsScreen } from "@screens"
import { Routes } from "@utils/constants"

import { BottomBar } from "./BottomBar"
import { RouteParamList } from "../types"

const Tab = createBottomTabNavigator<RouteParamList>()

export const HomeStackNavigator = () => {
  const { navigate } = useNavigation()

  const options: BottomTabNavigationOptions = {
    header: () => <Header onLeftPress={() => navigate(Routes.Home)} />,
  }
  const renderBottomBar = (props: BottomTabBarProps) => {
    return <BottomBar {...props} />
  }

  return (
    <Tab.Navigator screenOptions={options} tabBar={renderBottomBar}>
      <Tab.Screen name={Routes.Home} component={HomeScreen} />
      <Tab.Screen name={Routes.Leads} component={LeadsScreen} />
    </Tab.Navigator>
  )
}
