import { useEffect } from "react"

import { Alert, TouchableOpacity, View } from "react-native"

import { BottomTabBarProps } from "@react-navigation/bottom-tabs"
import { observer } from "mobx-react-lite"
import Svg, { Path } from "react-native-svg"

import { Icon, Typography } from "@components"
import { useStore } from "@store"
import { Routes, Stacks, colors } from "@utils/constants"

import { useStyles } from "./styles"

interface Tab {
  key: number
  name: string
  stack: Stacks
  route: Routes
  activeIcon: IconName
  inactiveIcon: IconName
}

const tabs: Array<Tab> = [
  {
    key: 0,
    stack: Stacks.Home,
    route: Routes.Home,
    name: "Home",
    activeIcon: "homeFilled",
    inactiveIcon: "homeOutlined",
  },
  {
    key: 1,
    stack: Stacks.Leads,
    route: Routes.Leads,
    name: "Leads",
    activeIcon: "leadsFilled",
    inactiveIcon: "leadsOutlined",
  },
  {
    key: 2,
    stack: Stacks.Call,
    route: Routes.CallLog,
    name: "Calls",
    activeIcon: "callsFilled",
    inactiveIcon: "callsOutlined",
  },
  {
    key: 3,
    stack: Stacks.Messages,
    route: Routes.Messages,
    name: "Messages",
    activeIcon: "messagesFilled",
    inactiveIcon: "messagesOutlined",
  },
]

const Component = ({ state, navigation }: BottomTabBarProps) => {
  const styles = useStyles()

  const { navigate } = navigation

  const { settingsStore } = useStore()
  const { sipSettings, checkSipSettings, requestSipSettings } = settingsStore
  const isSipAvailable = !!sipSettings?.profileId
  const contactAlert = () => {
    requestSipSettings()
    Alert.alert("Submitted", "Someone will contact you shortly.")
  }

  const makeCallAlert = () => {
    Alert.alert(
      "Want to make a call?",
      "This feature is not available with your current subscription, please contact us to enable.",
      [
        {
          text: "Request Call Tracking",
          onPress: contactAlert,
          style: "default",
        },
      ],
      {
        cancelable: true,
      },
    )
  }

  const onPhonePress = () => {
    if (isSipAvailable) {
      navigate(Stacks.Call, { screen: Routes.DialPad })
    } else {
      makeCallAlert()
    }
  }

  useEffect(() => {
    checkSipSettings()
  }, [])

  const renderTab = ({ key, route, name, activeIcon, inactiveIcon, stack }: Tab) => {
    const isActive = state.index === key

    return (
      <TouchableOpacity
        key={key}
        onPress={() => navigate(stack, { screen: route })}
        style={styles.tab}
      >
        <Icon name={isActive ? activeIcon : inactiveIcon} />
        <Typography style={[styles.text, isActive && styles.textActive]}>{name}</Typography>
      </TouchableOpacity>
    )
  }

  const leftTabs = tabs.slice(0, tabs.length / 2)
  const rightTabs = tabs.slice(tabs.length / 2)

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={onPhonePress} style={styles.phone}>
        <Icon name={"phonePlus"} />
      </TouchableOpacity>

      <View style={styles.tabs}>
        <View style={styles.tabRow}>{leftTabs.map(renderTab)}</View>
        <View style={styles.tabRow}>{rightTabs.map(renderTab)}</View>
      </View>

      <Svg width={"100%"} height={70} viewBox={"0 0 342 70"}>
        <Path
          d="M0 35C0 15.67 15.67 0 35 0h78.501a40.019 40.019 0 0128.995 12.46c15.741 16.575 42.205 16.599 57.92.001A39.884 39.884 0 01229.376 0H307c19.33 0 35 15.67 35 35s-15.67 35-35 35H35C15.67 70 0 54.33 0 35z"
          fill={colors.common.blueDark}
        />
      </Svg>
    </View>
  )
}

export const BottomBar = observer(Component)
