import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    position: "absolute",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    bottom: insets.bottom || 16,
  },
  phone: {
    position: "absolute",
    bottom: 58,
    height: 66,
    width: 66,
    borderRadius: 66,
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.orangePrimary,
  },
  tabs: {
    position: "absolute",
    zIndex: 1,
    gap: 32,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  tabRow: {
    gap: 16,
    flexDirection: "row",
    alignItems: "center",
  },
  tab: {
    gap: 6,
    width: 64,
    alignItems: "center",
  },
  text: {
    fontSize: 12,
    fontWeight: "400",
    color: colors.white,
  },
  textActive: {
    color: colors.orangePrimary,
  },
}))
