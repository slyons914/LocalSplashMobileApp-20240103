import { useEffect } from "react"

import { Mixpanel } from "mixpanel-react-native"
import { SafeAreaProvider } from "react-native-safe-area-context"

import { MIXPANEL_TOKEN } from "@env"
import { Navigation } from "@navigation"
import { CallProvider } from "@providers"

export const App = () => {
  useEffect(() => {
    if (__DEV__) return

    new Mixpanel(MIXPANEL_TOKEN, true).init()
  }, [])

  return (
    <SafeAreaProvider>
      <CallProvider>
        <Navigation />
      </CallProvider>
    </SafeAreaProvider>
  )
}
