import { Linking, Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { Icon, Typography } from "@components"
import { DudaUrls } from "@models/home"
import { useColors } from "@utils/hooks"

import { ModalItem } from "./ModalItem"
import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
  dudaLinks: DudaUrls | null
}

export const ProfileActionsModal = ({ isVisible, onClose, dudaLinks }: Props) => {
  const styles = useStyles()

  const { text } = useColors()

  const onWebsitePress = () => {
    if (!dudaLinks?.permalinkUrl) return onClose()
    Linking.openURL(`https://${dudaLinks.permalinkUrl}`)
    onClose()
  }

  const onEditorPress = () => {
    if (!dudaLinks?.ssoUrl) return onClose()
    Linking.openURL(dudaLinks.ssoUrl)
    onClose()
  }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography style={styles.title}>Profile Actions</Typography>
        <Pressable style={styles.close} onPress={onClose}>
          <Icon name={"remove"} stroke={text} />
        </Pressable>

        <ModalItem label={"View Website"} onPress={onWebsitePress} />
        <ModalItem label={"Edit Website"} onPress={onEditorPress} />
        <ModalItem label={"Edit Business Info"} onPress={onClose} />
      </View>
    </Modal>
  )
}
