import { useState } from "react"

import { Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { Icon, Typography } from "@components"
import { DateFilter } from "@models"
import { useColors } from "@utils/hooks"

import { ModalItem } from "./ModalItem"
import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
  setAnalyticsLabel: (tabName: string) => void
  setDateFilter: (date: DateFilter) => void
}

export const AnalyticsModal = ({ isVisible, onClose, setDateFilter, setAnalyticsLabel }: Props) => {
  const styles = useStyles()

  const { text } = useColors()

  const [active, setActive] = useState(1)

  const formatDate = (date: Date) => {
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, "0")
    const day = String(date.getDate()).padStart(2, "0")
    return `${year}-${month}-${day}`
  }

  const getLastNDaysDateRange = (days: number) => {
    const today = new Date()
    const fromDate = new Date()
    const toDate = new Date()

    fromDate.setDate(today.getDate() - days + 1)

    return { fromDate: formatDate(fromDate), toDate: formatDate(toDate) }
  }

  const getLastNMonthsDateRange = (months: number) => {
    const today = new Date()
    const fromDate = new Date(today.getFullYear(), today.getMonth() - months, 1)
    const toDate = new Date(today.getFullYear(), today.getMonth() + 1, 0)

    return { fromDate: formatDate(fromDate), toDate: formatDate(toDate) }
  }

  const getAllTime = () => {
    const today = new Date()
    const toDate = new Date(today.getFullYear(), today.getMonth() + 1, 0)

    return { fromDate: "1970-01-01", toDate: formatDate(toDate) }
  }

  const pickDateRange = (activeTab: number) => {
    switch (activeTab) {
      case 1:
        setDateFilter(getAllTime())
        break
      case 2:
        setDateFilter(getLastNDaysDateRange(7))
        break
      case 3:
        setDateFilter(getLastNDaysDateRange(30))
        break
      case 4:
        setDateFilter(getLastNMonthsDateRange(3))
        break
      case 5:
        setDateFilter(getLastNMonthsDateRange(6))
        break

      default:
        break
    }
  }

  const onItemPress = (activeTab: number, tabName: string) => {
    setAnalyticsLabel(tabName)
    pickDateRange(activeTab)
    setActive(activeTab)
    onClose()
  }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography style={styles.title}>Time Filter</Typography>
        <Pressable style={styles.close} onPress={onClose}>
          <Icon name={"remove"} stroke={text} />
        </Pressable>
        <ModalItem
          label={"All time"}
          active={active === 1}
          onPress={() => onItemPress(1, "All time")}
        />
        <ModalItem
          label={"Last 7 day"}
          active={active === 2}
          onPress={() => onItemPress(2, "Last 7 day")}
        />
        <ModalItem
          label={"Last 30 days"}
          active={active === 3}
          onPress={() => onItemPress(3, "Last 30 days")}
        />
        <ModalItem
          label={"Last 3 months"}
          active={active === 4}
          onPress={() => onItemPress(4, "Last 3 months")}
        />
        <ModalItem
          label={"Last 6 months"}
          active={active === 5}
          onPress={() => onItemPress(5, "Last 6 months")}
        />
        {/* <ModalItem
          label={"Custom Range"}
          active={active === 6}
          onPress={() => onItemPress(6)}
        /> */}
      </View>
    </Modal>
  )
}
