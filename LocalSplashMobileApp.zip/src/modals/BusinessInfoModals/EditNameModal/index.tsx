import { useCallback, useState } from "react"

import { View } from "react-native"

import { useFocusEffect } from "@react-navigation/native"
import { observer } from "mobx-react-lite"
import Modal from "react-native-modal"

import { BusinessInfoAPI } from "@api"
import { Input, SimpleHeader, Typography } from "@components"
import { useStore } from "@store"

import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
}

const Component = ({ isVisible, onClose }: Props) => {
  const styles = useStyles()

  const { businessInfoStore, homeStore } = useStore()
  const { locationsItem } = homeStore
  const { locationInfo, getLocationInfo } = businessInfoStore

  const [name, setName] = useState<string | null>(null)
  const [error, setError] = useState<string | undefined>()
  const [isLoading, setIsLoading] = useState(false)

  const onSubmit = async () => {
    const id = locationsItem?.id
    if (!id || !name) return
    setIsLoading(true)

    const { data, error } = await BusinessInfoAPI.changeProfileLocation(id, {
      propertyName: "name",
      name,
    })
    if (data === true) {
      onClose()
      getLocationInfo(id)
    } else if (error) {
      setError(error.Name[0])
    }
    setIsLoading(false)
  }

  useFocusEffect(
    useCallback(() => {
      if (!locationInfo?.name) return
      setName(locationInfo.name)
    }, []),
  )

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      onSwipeComplete={onClose}
      style={styles.modal}
      avoidKeyboard
      swipeDirection={["down"]}
      propagateSwipe
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <SimpleHeader
          onLeftPress={onClose}
          onRightPress={onSubmit}
          rightText={"Save"}
          isRightVisible
          title={"Edit Business Name"}
          isLoading={isLoading}
        />
        <Typography style={styles.warningText}>
          Changes to your core business information such as business name, address, phone number or
          Google Categories could possibly trigger a PIN re-verification process through Google.
        </Typography>
        <Input
          label={"Please provide your business name"}
          value={name!}
          onChange={setName}
          onSubmitEditing={onSubmit}
          error={error}
          setError={setError}
        />
      </View>
    </Modal>
  )
}

export const EditNameModal = observer(Component)
