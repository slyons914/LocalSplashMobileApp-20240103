import { useCallback, useState } from "react"

import { ScrollView, View } from "react-native"

import { useFocusEffect } from "@react-navigation/native"
import { observer } from "mobx-react-lite"
import Modal from "react-native-modal"

import { BusinessInfoAPI } from "@api"
import { GooglePlacesInput, Input, SimpleHeader, Typography } from "@components"
import { Address } from "@models/settings"
import { useStore } from "@store"

import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
}

const Component = ({ isVisible, onClose }: Props) => {
  const styles = useStyles()

  const { businessInfoStore, homeStore } = useStore()
  const { locationsItem } = homeStore
  const { locationInfo, getLocationInfo } = businessInfoStore

  const [address, setAddress] = useState<Address | null>(null)
  const [error, setError] = useState<string | undefined>()
  const [isLoading, setIsLoading] = useState(false)

  const onSubmit = async () => {
    const id = locationsItem?.id
    if (!id || !address) return
    setIsLoading(true)

    const { data, error } = await BusinessInfoAPI.changeProfileLocation(id, {
      propertyName: "address",
      address,
    })
    if (data === true) {
      onClose()
      getLocationInfo(id)
    } else if (error) {
      setError(error.Address[0])
    }
    setIsLoading(false)
  }

  useFocusEffect(
    useCallback(() => {
      if (!locationInfo) return
      setAddress({
        address: locationInfo.address,
        address2: locationInfo.address2,
        countryCode: locationInfo.countryCode,
        city: locationInfo.city,
        state: locationInfo.state,
        zip: locationInfo.zip,
        isHidden: locationInfo.isHidden,
      })
    }, []),
  )

  const onChangeSecondAddress = (text: string) => {
    text &&
      setAddress((prev) => {
        return {
          ...prev,
          address2: text,
        }
      })
  }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      onSwipeComplete={onClose}
      style={styles.modal}
      avoidKeyboard
      animationIn={"slideInUp"}
      animationOut={"slideOutDown"}
      swipeDirection={["down"]}
      propagateSwipe
    >
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps={"handled"}>
        <View style={styles.dash} />
        <SimpleHeader
          onLeftPress={onClose}
          onRightPress={onSubmit}
          rightText={"Save"}
          isRightVisible
          title={"Edit email"}
          isLoading={isLoading}
        />
        <Typography style={styles.warningText}>
          Changes to your core business information such as business name, address, phone number or
          Google Categories could possibly trigger a PIN re-verification process through Google.
        </Typography>
        {address ? (
          <>
            <GooglePlacesInput setAddress={setAddress} />
            <Input label={"Address"} value={address.address!} error={error} disabled />
            <Input
              label={"Floor, Suite, Unit, etc"}
              onChange={onChangeSecondAddress}
              value={address.address2!}
            />
            <Input label={"Country"} value={address.countryCode!} disabled />
            <Input label={"City"} value={address.city!} disabled />
            <Input label={"State"} value={address.state!} disabled />
            <Input label={"Zip"} value={address.zip!} disabled />
          </>
        ) : null}
      </ScrollView>
    </Modal>
  )
}

export const EditAddressModal = observer(Component)
