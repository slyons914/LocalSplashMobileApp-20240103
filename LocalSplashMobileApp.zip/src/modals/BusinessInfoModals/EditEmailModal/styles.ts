import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height, isDarkTheme }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.4,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    padding: 16,
    gap: 16,
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
    alignSelf: "center",
  },
  warningText: {
    color: colors.red,
    backgroundColor: isDarkTheme ? colors.backgroundSecondary : "#FEF8F2",
    borderRadius: 16,
    padding: 10,
  },
}))
