import { Pressable, View } from "react-native"

import { useNavigation } from "@react-navigation/native"
import Modal from "react-native-modal"

import { Button, Icon } from "@components"
import { Routes, Stacks } from "@utils/constants"

import { ModalItem } from "./ModalItem"
import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
}

export const BurgerMenuModal = ({ isVisible, onClose }: Props) => {
  const styles = useStyles()
  const { navigate } = useNavigation()

  const onLeadsPress = () => {
    onClose()
    navigate(Stacks.Home, { screen: Routes.Leads })
  }
  const onBusinessInfoPress = () => {
    onClose()
    navigate(Stacks.Settings, { screen: Routes.BusinessInformation })
  }

  return (
    <Modal
      isVisible={isVisible}
      animationIn={"fadeInRight"}
      animationOut={"fadeOutRight"}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.logoBlock}>
          <Icon name={"burgerLogo"} />
          <Pressable onPress={onClose}>
            <Icon name={"remove"} />
          </Pressable>
        </View>
        <ModalItem onPress={onLeadsPress} label={"Leads"} />
        <ModalItem label={"Website"} />
        <ModalItem label={"Reviews"} />
        <ModalItem label={"Google Insights"} />
        <ModalItem label={"Facebook Ads"} />
        <ModalItem label={"Google Ads"} />
        <ModalItem label={"Listings"} />
        <ModalItem label={"Posts"} />
        <ModalItem label={"Business Info"} onPress={onBusinessInfoPress} />
        <Button
          btnStyle={styles.button}
          onPress={onClose}
          icon={"customerService"}
          label={"Contact Us"}
        />
      </View>
    </Modal>
  )
}
