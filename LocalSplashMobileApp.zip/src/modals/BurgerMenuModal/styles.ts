import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets, height, width }) => ({
  modal: {
    alignSelf: "flex-end",
    margin: 0,
  },
  container: {
    backgroundColor: colors.background,
    height: height,
    width: width * 0.8,
    alignItems: "center",
    paddingTop: insets.top || 40,
    paddingHorizontal: 24,
  },
  logoBlock: {
    flexDirection: "row",
    alignItems: "center",
    gap: 48,
    marginBottom: 16,
  },
  itemContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 16,
    paddingHorizontal: 12,
    width: "100%",
  },
  itemText: {
    fontSize: 16,
    fontWeight: "400",
  },
  button: {
    marginTop: 16,
    width: 250,
  },
}))
