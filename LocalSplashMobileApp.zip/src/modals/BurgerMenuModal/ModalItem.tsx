import { TouchableOpacity } from "react-native"

import { Icon, Typography } from "@components"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  label: string
  onPress?: () => void
  active?: boolean
}

export const ModalItem = ({ label, onPress }: Props) => {
  const styles = useStyles()

  const { text } = useColors()

  return (
    <TouchableOpacity onPress={onPress} style={styles.itemContainer}>
      <Typography style={styles.itemText}>{label}</Typography>
      <Icon name={"chevronRight"} stroke={text} />
    </TouchableOpacity>
  )
}
