import { View } from "react-native"

import { useNavigation } from "@react-navigation/native"
import Modal from "react-native-modal"

import { Button, Typography } from "@components"
import { Routes, Stacks } from "@utils/constants"
import { AuthHelper } from "@utils/helpers"

import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
}

export const LogOutModal = ({ isVisible, onClose }: Props) => {
  const styles = useStyles()
  const { navigate } = useNavigation()

  const onEnable = async () => {
    await AuthHelper.logout()
    onClose()
    navigate(Stacks.Login, { screen: Routes.Welcome })
  }

  const onDecline = () => {
    onClose()
  }

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography type={"title"} style={styles.title}>
          Log Out
        </Typography>
        <Typography type={"subtext"} style={styles.text}>
          Are you sure you would like to log out of your Local Splash account?
        </Typography>
        <Button label={"Yes, Log Out"} onPress={onEnable} />
        <Typography onPress={onDecline} style={styles.anotherTime}>
          No, Cancel
        </Typography>
      </View>
    </Modal>
  )
}
