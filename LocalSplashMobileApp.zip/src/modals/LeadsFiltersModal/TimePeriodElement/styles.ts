import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(() => ({
  itemContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 16,
    paddingHorizontal: 12,
    width: "100%",
  },
  itemText: {
    fontSize: 16,
    fontWeight: "400",
  },
}))
