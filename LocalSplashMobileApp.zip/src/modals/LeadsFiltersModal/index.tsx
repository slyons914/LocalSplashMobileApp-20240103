import { useCallback, useEffect, useState } from "react"

import {
  Animated,
  Dimensions,
  Pressable,
  Switch,
  TouchableOpacity,
  View,
  useAnimatedValue,
} from "react-native"

import Modal from "react-native-modal"

import { Button, Icon, Typography } from "@components"
import { DateFilter } from "@models/index"
import { LeadFilters } from "@models/leads"
import { useStore } from "@store"
import { colors } from "@utils/constants"
import { useColors } from "@utils/hooks"

import { LeadTypeElement } from "./LeadTypeElement"
import { LocationsElement } from "./LocationsElement"
import { TimePeriodElement } from "./TimePeriodElement"
import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
  setFilters: (value?: Partial<LeadFilters>) => void
  filters: LeadFilters
}

interface MenuItem {
  title: string
  subTitle: string
  onPress: () => void
}

type Section = "type" | "period" | "location"

const { width } = Dimensions.get("screen")
const translateX = width

export const LeadsFiltersModal = ({ isVisible, onClose, setFilters, filters }: Props) => {
  const [currentSection, setCurrentSection] = useState<Section | null>(null)
  const [periodLabel, setPeriodLabel] = useState<string>("All time")

  const [dateFilter, setDateFilter] = useState<DateFilter>({
    fromDate: "",
    toDate: "",
  })

  useEffect(() => {
    setFilters({
      FromDate: dateFilter.fromDate,
      ToDate: dateFilter.toDate,
    })
  }, [dateFilter])

  const menuValue = useAnimatedValue(0)

  const sectionValue = useAnimatedValue(translateX)

  const { homeStore } = useStore()
  const { profiles } = homeStore

  const [overflow, setOverflow] = useState<"hidden" | "visible">("hidden")

  const move = useCallback((direction: "forward" | "backward") => {
    setOverflow("hidden")
    const settings = { duration: 400, useNativeDriver: true }
    Animated.parallel([
      Animated.timing(menuValue, {
        toValue: direction === "forward" ? -translateX : 0,
        ...settings,
      }),
      Animated.timing(sectionValue, {
        toValue: direction === "forward" ? 0 : translateX,
        ...settings,
      }),
    ]).start(() => {
      direction === "backward" && setCurrentSection(null)
      setOverflow("visible")
    })
  }, [])

  const goBack = useCallback(() => {
    move("backward")
  }, [move])

  useEffect(() => {
    currentSection && move("forward")
  }, [currentSection])

  const menuItems: Array<MenuItem> = [
    {
      title: "Lead Type",
      onPress: () => setCurrentSection("type"),
      subTitle: "",
    },
    {
      title: "Time Period",
      onPress: () => setCurrentSection("period"),
      subTitle: periodLabel,
    },
    {
      title: "Location",
      onPress: () => setCurrentSection("location"),
      subTitle:
        profiles?.profiles?.find((item) => item.id === filters.ProfileId)?.title || "All Locations",
    },
  ]

  const sections = [
    {
      name: "type",
      component: <LeadTypeElement filters={filters} setFilters={setFilters} goBack={goBack} />,
    },
    {
      name: "period",
      component: (
        <TimePeriodElement
          setPeriodLabel={setPeriodLabel}
          setDateFilter={setDateFilter}
          goBack={goBack}
        />
      ),
    },
    {
      name: "location",
      component: (
        <LocationsElement
          locationsId={filters.ProfileId || null}
          setFilters={setFilters}
          goBack={goBack}
          profiles={profiles}
        />
      ),
    },
  ]

  const styles = useStyles()

  const { text } = useColors()

  return (
    <Modal
      useNativeDriverForBackdrop
      isVisible={isVisible}
      onBackdropPress={onClose}
      onModalHide={goBack}
      style={styles.modal}
    >
      <View style={[styles.container, { overflow }]}>
        <View style={styles.dash} />
        {currentSection && (
          <Pressable style={styles.back} onPress={goBack}>
            <Icon name="chevronLeft" stroke={text} />
          </Pressable>
        )}

        <Typography style={styles.title}>Filters</Typography>
        <Pressable style={styles.close} onPress={onClose}>
          <Icon name={"remove"} stroke={text} />
        </Pressable>
        <Animated.View style={[styles.content, { transform: [{ translateX: menuValue }] }]}>
          {
            <View style={currentSection ? styles.hidden : styles.flexed}>
              {menuItems.map((item) => (
                <TouchableOpacity key={item.title} onPress={item.onPress} style={styles.menuItem}>
                  <View>
                    <Typography style={styles.menuItemTitle} type="title">
                      {item.title}
                    </Typography>
                    <Typography type="title" style={styles.menuItemSubTitle}>
                      {item.subTitle}
                    </Typography>
                  </View>
                  <Icon name="chevronRight" stroke={colors.common.dark} />
                </TouchableOpacity>
              ))}
              <View style={styles.menuItem}>
                <Typography style={styles.menuItemTitle} type="title">
                  Include Spam
                </Typography>
                <Switch
                  value={!!filters.isSpam}
                  onChange={() => {
                    setFilters({ isSpam: !filters.isSpam })
                  }}
                  thumbColor={"#FFF"}
                  trackColor={{ true: colors.common.green, false: "#78788029" }}
                />
              </View>
              <View style={styles.menuItem}>
                <Typography style={styles.menuItemTitle} type="title">
                  Include Blocked
                </Typography>
                <Switch
                  value={!!filters.isBlocked}
                  onChange={() => {
                    setFilters({ isBlocked: !filters.isBlocked })
                  }}
                  thumbColor={"#FFF"}
                  trackColor={{ true: colors.common.green, false: "#78788029" }}
                />
              </View>

              <Button btnStyle={styles.button} onPress={onClose} label={"View Leads"} />
            </View>
          }
        </Animated.View>
        <Animated.View style={[styles.section, { transform: [{ translateX: sectionValue }] }]}>
          {sections.map(({ component, name }, i) => (
            <View key={i} style={currentSection === name ? styles.flexed : styles.hidden}>
              {component}
            </View>
          ))}
        </Animated.View>
      </View>
    </Modal>
  )
}
