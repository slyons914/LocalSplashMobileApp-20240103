import { FlatList, TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"
import { LeadFilters } from "@models/leads"

import { useStyles } from "./styles"

interface Props {
  setFilters: (value?: Partial<LeadFilters>) => void
  filters: LeadFilters
  goBack: () => void
}

interface LeadType {
  title: string
  iconName: IconName
  onPress: () => void
  value: boolean
}

export const LeadTypeElement = ({ setFilters, goBack, filters }: Props) => {
  const styles = useStyles()

  const setTypeHandler = (key: keyof LeadFilters) => {
    setFilters({ [key]: !filters[key] })
    goBack()
  }

  const leadTypes: Array<LeadType> = [
    {
      title: "CTM",
      onPress: () => setTypeHandler("AreCtmLeadLogsIncluded"),
      iconName: "filterCtm",
      value: !!filters.AreCtmLeadLogsIncluded,
    },
    {
      title: "Website",
      onPress: () => setTypeHandler("AreWebsiteFormLeadLogsIncluded"),
      iconName: "filterWebsite",
      value: !!filters.AreWebsiteFormLeadLogsIncluded,
    },

    {
      title: "Facebook Ads",
      onPress: () => setTypeHandler("AreFacebookLeadLogsIncluded"),
      iconName: "filterFacebook",
      value: !!filters.AreFacebookLeadLogsIncluded,
    },
  ]

  const setInitialTypeHandler = () => {
    setFilters({
      AreCtmLeadLogsIncluded: !filters.AreCtmLeadLogsIncluded,
      AreWebsiteFormLeadLogsIncluded: !filters.AreCtmLeadLogsIncluded,
      AreFacebookLeadLogsIncluded: !filters.AreCtmLeadLogsIncluded,
    })
    goBack()
  }

  const renderItem = ({ item }: { item: LeadType }) => {
    return (
      <TouchableOpacity onPress={item.onPress} style={styles.itemContainer}>
        <View style={styles.menuItemContainer}>
          <Icon name={item.iconName} />
          <Typography style={styles.itemText}>{item.title}</Typography>
        </View>

        {item.value && <Icon name={"checkBlue"} />}
      </TouchableOpacity>
    )
  }

  return (
    <View>
      <TouchableOpacity style={styles.itemContainer} onPress={setInitialTypeHandler}>
        <Typography style={styles.itemText}>All Leads</Typography>
        {filters.AreCtmLeadLogsIncluded &&
          filters.AreFacebookLeadLogsIncluded &&
          filters.AreWebsiteFormLeadLogsIncluded && <Icon name={"checkBlue"} />}
      </TouchableOpacity>
      <FlatList
        data={leadTypes}
        contentContainerStyle={styles.list}
        scrollEnabled
        renderItem={renderItem}
      />
    </View>
  )
}
