import { FlatList, TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"
import { LeadFilters } from "@models/leads"
import {
  IGetProfileListResponseViewModel,
  ProfileViewModel,
} from "@models/localsplash-mobile-api.service"

import { useStyles } from "./styles"

interface Props {
  locationsId: number | null | string
  setFilters: (value?: Partial<LeadFilters>) => void
  goBack: () => void
  profiles: IGetProfileListResponseViewModel | null
}

export const LocationsElement = ({ locationsId, setFilters, goBack, profiles }: Props) => {
  const styles = useStyles()

  const setLocationHandler = (id?: number | null) => {
    setFilters({ ProfileId: id })
    goBack()
  }

  const renderItem = ({ item }: { item: ProfileViewModel }) => (
    <TouchableOpacity onPress={() => setLocationHandler(item.id)} style={styles.itemContainer}>
      <Typography style={styles.itemText}>{item.title!}</Typography>
      {locationsId === item.id && <Icon name={"checkBlue"} />}
    </TouchableOpacity>
  )

  return (
    <View>
      <TouchableOpacity style={styles.itemContainer} onPress={() => setLocationHandler(null)}>
        <Typography style={styles.itemText}>All Locations</Typography>
        {!locationsId && <Icon name={"checkBlue"} />}
      </TouchableOpacity>
      <FlatList
        data={profiles?.profiles}
        contentContainerStyle={styles.list}
        scrollEnabled
        renderItem={renderItem}
      />
    </View>
  )
}
