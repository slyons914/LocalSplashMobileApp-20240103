import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(() => ({
  list: {
    maxWidth: "100%",
  },
  itemContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 16,
    paddingHorizontal: 12,
    width: "100%",
  },
  itemText: {
    fontSize: 16,
    fontWeight: "400",
  },
}))
