import { useState } from "react"

import { Pressable, View } from "react-native"

import Modal from "react-native-modal"

import { Button, Icon, Input, Typography } from "@components"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  isVisible: boolean
  onClose: () => void
}

type InputValue = {
  name: string
  phone: string
  email: string
}

interface InputData {
  label: string
  onChange: (value: string) => void
  value: string
  type?: "phone" | "default"
}

export const RequestReviewModal = ({ isVisible, onClose }: Props) => {
  const [inputValues, setInputValues] = useState<InputValue>({
    name: "",
    phone: "",
    email: "",
  })
  const styles = useStyles()

  const { text } = useColors()

  const onChangeHandler = (value: string, key: string) => {
    setInputValues((prevData) => {
      return {
        ...prevData,
        [key]: value,
      }
    })
  }

  const inputData: InputData[] = [
    {
      label: "Name* ",
      onChange: (value: string) => onChangeHandler(value, "name"),
      value: inputValues.name,
    },
    {
      label: "Phone Number*",
      onChange: (value: string) => onChangeHandler(value, "phone"),
      value: inputValues.phone,
      type: "phone",
    },
    {
      label: "Customer Email*",
      onChange: (value: string) => onChangeHandler(value, "email"),
      value: inputValues.email,
    },
  ]

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <View style={styles.container}>
        <View style={styles.dash} />
        <Typography style={styles.title}>Request Review</Typography>
        <Pressable style={styles.close} onPress={onClose}>
          <Icon name={"remove"} stroke={text} />
        </Pressable>
        <View style={styles.inputContainer}>
          {inputData.map((item) => (
            <Input
              key={item.label}
              label={item.label}
              type={item.type}
              value={item.value}
              onChange={item.onChange}
            />
          ))}
        </View>
        <View>
          <Button btnStyle={styles.button} onPress={onClose} label={"Send"} />
          <Button
            btnStyle={styles.cancelButton}
            labelStyle={styles.cancelButtonText}
            onPress={onClose}
            label={"Cancel"}
          />
        </View>
      </View>
    </Modal>
  )
}
