import { AUTH_API_URL, MOBILE_API_URL } from "@env"
import axios, { AxiosResponse } from "axios"

import { StorageHelper } from "@utils/helpers"

const authClient = axios.create({
  baseURL: AUTH_API_URL,
})

const mobileClient = axios.create({
  baseURL: MOBILE_API_URL,
})

mobileClient.interceptors.request.use(async (config) => {
  const accessToken = await StorageHelper.get<string>("accessToken")

  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`
  }

  return config
}, Promise.reject)

export const authAPI = {
  get: <T>(url: string, params = {}) => authClient.get<T, AxiosResponse<T>>(url, { params }),
  post: <T>(url: string, data = {}, params = {}) =>
    authClient.post<T, AxiosResponse<T>>(url, data, { params }),
  put: <T>(url: string, data = {}, params = {}) =>
    authClient.put<T, AxiosResponse<T>>(url, data, { params }),
  delete: <T>(url: string, params = {}) => authClient.delete<T, AxiosResponse<T>>(url, { params }),
}

export const mobileAPI = {
  get: <T>(url: string, params = {}) => mobileClient.get<T, AxiosResponse<T>>(url, { params }),
  post: <T>(url: string, data = {}, params = {}) =>
    mobileClient.post<T, AxiosResponse<T>>(url, data, { params }),
  patch: <T>(url: string, data = {}, params = {}) =>
    mobileClient.patch<T, AxiosResponse<T>>(url, data, { params }),
  put: <T>(url: string, data = {}, params = {}) =>
    mobileClient.put<T, AxiosResponse<T>>(url, data, { params }),
  delete: <T>(url: string, params = {}) =>
    mobileClient.delete<T, AxiosResponse<T>>(url, { params }),
}
