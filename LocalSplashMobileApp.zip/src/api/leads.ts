import {
  CallLeadLog,
  Lead,
  LeadFilters,
  LeadList,
  LeadListItem,
  LeadLogType,
  LeadUpdate,
} from "@models/leads"

import { mobileAPI } from "./base"
import { ServerError } from "./types"

export class LeadsAPI {
  static async getLeads(filters?: LeadFilters) {
    try {
      const { data } = await mobileAPI.get<LeadList<LeadListItem>>("/Leads", filters)
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async getCtmLeadLogs(leadStructure: LeadLogType) {
    try {
      const { data } = await mobileAPI.get<LeadList<CallLeadLog>>("/CtmLeadLogs", {
        LeadStructure: leadStructure,
      })
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async getLeadsDetails(id: string | number) {
    try {
      const { data } = await mobileAPI.get<Lead>(`/Leads/${id}`)
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async setLeadsLogIsRead(id: number, logId: number) {
    try {
      const { data } = await mobileAPI.patch<Lead>(`/Leads/${id}/Logs/${logId}`, {
        isRead: true,
      })
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async updateLead(id: number, payload: Partial<LeadUpdate>) {
    try {
      await mobileAPI.patch(`/Leads/${id}`, payload)
      return { error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async setLeadStatus(id: number | string, payload: LeadFilters) {
    try {
      const { data } = await mobileAPI.patch<Lead>(`/Leads/${id}`, payload)
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }
}
