import { LoginSuccess, SendMessageSuccessResponse } from "@models"

import { authAPI } from "./base"
import { Response, ServerError } from "./types"

export class AuthAPI {
  static async sendMessage(to: string): Promise<Response<SendMessageSuccessResponse>> {
    try {
      const { data } = await authAPI.post<SendMessageSuccessResponse>("/message", { to })
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async Login(messageCode: string, clientId: string, state: string) {
    const payload = { messageCode, clientId, state }

    try {
      const { data } = await authAPI.post<LoginSuccess>("/token", payload)
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.errors?.MessageCode[0]
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }
}
