import { AxiosError } from "axios"

import { getUserData } from "@models/user"

import { mobileAPI } from "./base"
import { Response } from "./types"

interface ChangeUserError {
  ContactPhone: Array<string>
  EmailAddress: Array<string>
  FirstName: Array<string>
  LastName: Array<string>
}

export class UserAPI {
  static async getUserData(): Promise<Response<getUserData>> {
    try {
      const { data } = await mobileAPI.get<getUserData>("/Members/me")
      return { data, error: null }
    } catch (err) {
      if (err instanceof AxiosError) {
        const error = err.response?.data.errors.Signature[0]
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async changeUserData(
    firstName: string,
    lastName: string,
    emailAddress: string,
    contactPhone: string,
  ): Promise<Response<boolean, ChangeUserError>> {
    try {
      await mobileAPI.put("/Members/me", {
        firstName,
        lastName,
        emailAddress,
        contactPhone,
      })
      return { data: true, error: null }
    } catch (err) {
      if (err instanceof AxiosError) {
        const error = err.response?.data.errors
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }
}
