import { AxiosError } from "axios"

import {
  AvailableCategories,
  AvailableGoogleCategories,
  GetProfileLocation,
  PatchProfileLocation,
  ProfileGoogleCategories,
} from "@models/settings"

import { mobileAPI } from "./base"
import { Response } from "./types"

interface ChangeBusinessInfoError {
  Name: Array<string>
  Phone: Array<string>
  Email: Array<string>
  Website: Array<string>
  Address: Array<string>
}
export class BusinessInfoAPI {
  static async getProfileLocation(id: number): Promise<Response<GetProfileLocation>> {
    try {
      const { data } = await mobileAPI.get<GetProfileLocation>(`Profiles/${id}/Location`)
      return { data, error: null }
    } catch (err) {
      if (err instanceof AxiosError) {
        const error = err.response?.data.errors.Signature[0]
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async changeProfileLocation(
    id: number,
    locationInfo: PatchProfileLocation,
  ): Promise<Response<boolean, ChangeBusinessInfoError>> {
    try {
      await mobileAPI.patch(`Profiles/${id}/Location`, locationInfo)
      return { data: true, error: null }
    } catch (err) {
      if (err instanceof AxiosError) {
        const error = err.response?.data.errors
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async getAvailableCategories(): Promise<Response<AvailableCategories>> {
    try {
      const { data } = await mobileAPI.get<AvailableCategories>("/AvailableCategories")
      return { data, error: null }
    } catch (err) {
      if (err instanceof AxiosError) {
        const error = err.response?.data.errors.Signature[0]
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async changeAvailableCategories(
    profileId: number,
    id: number,
    customTitle?: string,
  ): Promise<Response<boolean, ChangeBusinessInfoError>> {
    try {
      await mobileAPI.post(`Profiles/${profileId}/Categories`, { id, customTitle })
      return { data: true, error: null }
    } catch (err) {
      if (err instanceof AxiosError) {
        const error = err.response?.data.errors
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async getAvailableGoogleCategories(): Promise<Response<AvailableGoogleCategories>> {
    try {
      const { data } = await mobileAPI.get<AvailableGoogleCategories>("/AvailableGoogleCategories")
      return { data, error: null }
    } catch (err) {
      if (err instanceof AxiosError) {
        const error = err.response?.data.errors.Signature[0]
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async getProfileGoogleCategories(
    profileId: number,
  ): Promise<Response<ProfileGoogleCategories>> {
    try {
      const { data } = await mobileAPI.get<ProfileGoogleCategories>(
        `Profiles/${profileId}/GoogleCategories`,
      )
      return { data, error: null }
    } catch (err) {
      if (err instanceof AxiosError) {
        const error = err.response?.data.errors.Signature[0]
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }
}
