import { AxiosError } from "axios"

import {
  GetTermsAndConditionsContentResponseViewModel,
  IAcceptTermsAndConditionsRequestViewModel,
  IGetProfileAnalyticsOverTimeResponseViewModel,
  IGetProfileAnalyticsResponseViewModel,
  IGetProfileListResponseViewModel,
  IGetProfileLogoResponseViewModel,
  IProfileLocationViewModel,
  UnreadLeads,
} from "@models"
import { DudaUrls, UserCallTrackingSipSettings } from "@models/home"

import { mobileAPI } from "./base"
import { Response, ServerError } from "./types"

export class MobileAPI {
  static async getProfiles(): Promise<Response<IGetProfileListResponseViewModel>> {
    try {
      const { data } = await mobileAPI.get<IGetProfileListResponseViewModel>("/Profiles")
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async getLocations(id: number): Promise<Response<IProfileLocationViewModel>> {
    try {
      const { data } = await mobileAPI.get<IProfileLocationViewModel>(`/Profiles/${id}/Location`)
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }
      return { data: null, error: null }
    }
  }

  static async getLogo(profileId: number): Promise<Response<IGetProfileLogoResponseViewModel>> {
    try {
      const { data } = await mobileAPI.get<IGetProfileLogoResponseViewModel>(
        `/Profiles/${profileId}/Logo`,
      )
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async getAnalytics(
    profileId: number,
  ): Promise<Response<IGetProfileAnalyticsResponseViewModel>> {
    try {
      const { data } = await mobileAPI.get<IGetProfileAnalyticsResponseViewModel>(
        `/Profiles/${profileId}/Analytics`,
      )

      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async filterAnalytics(
    profileId: number,
    fromDate: string,
    toDate: string,
  ): Promise<Response<IGetProfileAnalyticsResponseViewModel>> {
    try {
      const { data } = await mobileAPI.get<IGetProfileAnalyticsResponseViewModel>(
        `/Profiles/${profileId}/Analytics?FromDate=${fromDate}&ToDate=${toDate}`,
      )

      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async getAnalyticsOverTime(
    profileId: number,
  ): Promise<Response<IGetProfileAnalyticsOverTimeResponseViewModel>> {
    try {
      const { data } = await mobileAPI.get<IGetProfileAnalyticsOverTimeResponseViewModel>(
        `/Profiles/${profileId}/AnalyticsOverTime`,
      )
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async filterAnalyticsOverTime(
    profileId: number,
    fromDate: string,
    toDate: string,
  ): Promise<Response<IGetProfileAnalyticsOverTimeResponseViewModel>> {
    try {
      const { data } = await mobileAPI.get<IGetProfileAnalyticsOverTimeResponseViewModel>(
        `/Profiles/${profileId}/AnalyticsOverTime?FromDate=${fromDate}&ToDate=${toDate}`,
      )
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async getUnreadLeads(): Promise<Response<UnreadLeads>> {
    try {
      const { data } = await mobileAPI.get<UnreadLeads>("/LeadCount")
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async getTerms(): Promise<Response<GetTermsAndConditionsContentResponseViewModel>> {
    try {
      const { data } = await mobileAPI.get<GetTermsAndConditionsContentResponseViewModel>("/Terms")
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async confirmTerms(
    signature: string,
  ): Promise<Response<IAcceptTermsAndConditionsRequestViewModel>> {
    try {
      const { data } = await mobileAPI.post<IAcceptTermsAndConditionsRequestViewModel>("/Terms", {
        signature,
      })
      return { data, error: null }
    } catch (err) {
      if (err instanceof AxiosError) {
        const error = err.response?.data.errors.Signature[0]
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async getSipSettings(): Promise<Response<UserCallTrackingSipSettings>> {
    try {
      const { data } = await mobileAPI.get<UserCallTrackingSipSettings>("/CallTrackingSipSettings")
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async requestSipSettings(): Promise<Response<UserCallTrackingSipSettings>> {
    try {
      const { data } = await mobileAPI.post<UserCallTrackingSipSettings>("/CallTrackingSipSettings")
      return { data, error: null }
    } catch (err) {
      if (err instanceof ServerError) {
        const error = err.response?.data.title
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }

  static async getWebsiteUrls(profileId: number): Promise<Response<DudaUrls>> {
    try {
      const { data } = await mobileAPI.get<DudaUrls>(`/Profiles/${profileId}/DudaUrls`, {
        profileId,
      })
      return { data, error: null }
    } catch (err) {
      if (err instanceof AxiosError) {
        const error = err.response?.data
        return { data: null, error }
      }

      return { data: null, error: null }
    }
  }
}
