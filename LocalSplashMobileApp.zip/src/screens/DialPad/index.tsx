import { useEffect, useState } from "react"

import { TouchableOpacity, View } from "react-native"

import { TextInputMask } from "react-native-masked-text"

import { Icon } from "@components"
import { useCall } from "@providers"
import { Routes } from "@utils/constants"

import { Button } from "./Button"
import { useStyles } from "./styles"

const buttons = "123\n456\n789\n*0#".split("\n").map((row) => row.split(""))

const MAX_NUMBER_LENGTH = 13

export const DialPadScreen = ({ route }: ScreenProps<Routes.DialPad>) => {
  const [value, setValue] = useState("")

  const { startCall } = useCall()

  const styles = useStyles()

  useEffect(() => {
    setValue(route.params?.phoneNumber ?? "")
  }, [route.params])

  const onButtonPress = (button: string) => {
    setValue((value) => (value.length < MAX_NUMBER_LENGTH ? value + button : value))
  }

  const onCallPress = () => {
    startCall(value)
  }

  const onErasePress = () => {
    setValue((value) => value.slice(0, -1))
  }

  const renderButton = (button: string, i: number) => {
    return <Button key={i} value={button} onPress={onButtonPress} />
  }

  const renderButtonRow = (row: Array<string>, i: number) => {
    return (
      <View key={i} style={styles.row}>
        {row.map(renderButton)}
      </View>
    )
  }

  return (
    <View style={styles.container}>
      <TextInputMask
        type={"custom"}
        editable={false}
        value={value}
        options={{ mask: "(***) ***-****" }}
        style={styles.value}
      />
      <View style={styles.buttons}>
        {buttons.map(renderButtonRow)}
        <View style={styles.footer}>
          <TouchableOpacity onPress={onCallPress} style={styles.callButton}>
            <Icon name={"phone"} />
          </TouchableOpacity>
          {value && (
            <TouchableOpacity onPress={onErasePress} style={styles.eraser}>
              <Icon name={"eraser"} />
            </TouchableOpacity>
          )}
        </View>
      </View>
    </View>
  )
}
