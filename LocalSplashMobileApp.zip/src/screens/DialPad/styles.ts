import { withStyles } from "@utils/hocs"

const BUTTON_SIZE = 64

export const useStyles = withStyles(({ colors }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    justifyContent: "space-around",
  },
  value: {
    fontSize: 32,
    fontWeight: "400",
    textAlign: "center",
    color: colors.text,
  },
  buttons: {
    alignSelf: "center",
    gap: 24,
  },
  row: {
    flexDirection: "row",
    gap: 32,
  },
  footer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  callButton: {
    width: BUTTON_SIZE,
    height: BUTTON_SIZE,
    borderRadius: BUTTON_SIZE,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: colors.green,
  },
  eraser: {
    position: "absolute",
    right: 20,
  },
}))
