import { useState } from "react"

import { View } from "react-native"

import { observer } from "mobx-react-lite"

import { SimpleHeader, Typography } from "@components"
import { useStore } from "@store"
import { Routes } from "@utils/constants"

import { ScreenItem } from "./ScreenItem"
import { useStyles } from "./styles"

const Component = ({ navigation }: ScreenProps<Routes.SettingsGSM>) => {
  const styles = useStyles()
  const { goBack, navigate } = navigation

  const { settingsStore } = useStore()
  const { ringerBehavior } = settingsStore

  const [switchValue, setSwitch] = useState(false)

  const onSwitchChange = () => {
    setSwitch(!switchValue)
  }

  return (
    <View style={styles.container}>
      <SimpleHeader onLeftPress={goBack} rightText={"Save"} isRightVisible />
      <Typography style={styles.screenTitle}>GSM call settings</Typography>
      <ScreenItem
        onPress={() => navigate(Routes.RingerBehavior)}
        title="Ringer behavior on call"
        label={ringerBehavior}
        description="Ringer behavior in situation when an incoming GSM call interrupts a VoIP call."
      />
      <ScreenItem
        onPress={Promise.resolve}
        title="Do not disturb access permission needed"
        description="To be able to control ringer behavior during VoIP calls, the app requires the Do Not Disturb access permission."
      />
      <ScreenItem
        onPress={onSwitchChange}
        title="Show persistent notification"
        description="Show persistent notification if the switch is on or there is at least one account which uses “Standard” mode for incoming calls. Application will hide the notification if incoming call mode is not set to “Standard” and the switch is set to off."
        type="switch"
        switchValue={switchValue}
      />
    </View>
  )
}

export const SettingsGSMScreen = observer(Component)
