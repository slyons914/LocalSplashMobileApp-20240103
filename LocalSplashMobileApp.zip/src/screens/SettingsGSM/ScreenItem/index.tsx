import { Switch, TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"
import { colors } from "@utils/constants"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  title: string
  label?: string
  onPress: () => void
  description: string
  type?: "button" | "switch"
  switchValue?: boolean
}

export const ScreenItem = ({ title, label, onPress, description, type, switchValue }: Props) => {
  const styles = useStyles()

  const { text } = useColors()

  return (
    <View style={styles.itemWrapper}>
      <TouchableOpacity onPress={onPress} style={styles.btnContainer}>
        <View>
          <Typography style={styles.title}>{title}</Typography>
          {label && <Typography style={styles.label}>{label}</Typography>}
        </View>
        {type === "switch" ? (
          <Switch
            value={switchValue}
            onChange={onPress}
            thumbColor={"#FFF"}
            trackColor={{ true: colors.common.green, false: "#78788029" }}
          />
        ) : (
          <Icon name={"chevronRight"} stroke={text} />
        )}
      </TouchableOpacity>
      <Typography>{description}</Typography>
    </View>
  )
}
