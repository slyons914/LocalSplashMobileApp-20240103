import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    gap: 16,
    paddingHorizontal: 24,
    paddingTop: insets.top | 16,
    backgroundColor: colors.background,
  },
  screenTitle: {
    color: colors.text,
    fontSize: 24,
    fontWeight: "600",
  },
  switchContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  itemWrapper: {
    padding: 16,
    gap: 8,
  },
  btnContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  title: {
    fontSize: 16,
    maxWidth: 270,
  },
  label: {
    color: colors.blue,
  },
}))
