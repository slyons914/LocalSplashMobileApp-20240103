import { TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"
import { IGetProfileAnalyticsResponseViewModel } from "@models"
import { useColors } from "@utils/hooks"

import { AnalyticsItem } from "./AnalyticsItem"
import { useStyles } from "./styles"

interface Props {
  onOpenAnalyticsModal: () => void
  onOpenTotalLeadsModal: () => void
  isLightTheme: boolean
  analyticsMock: IGetProfileAnalyticsResponseViewModel
  analyticsLabel: string
  unreadLeads: number
}

export const Analytics = ({
  onOpenAnalyticsModal,
  onOpenTotalLeadsModal,
  isLightTheme,
  analyticsMock,
  analyticsLabel,
  unreadLeads,
}: Props) => {
  const styles = useStyles()

  const arrowIcon1 = isLightTheme ? "arrowUpRight" : "arrowUpRightWhite"
  const arrowIcon2 = isLightTheme ? "helpSquare" : "helpSquareBlack"

  const { background, text } = useColors()

  return (
    <>
      <View style={styles.analyticsHeader}>
        <Typography style={styles.analyticsHeaderName}>Analytics</Typography>
        <TouchableOpacity onPress={onOpenAnalyticsModal} style={styles.filterBtn}>
          <Typography type={"subtext"}>{analyticsLabel}</Typography>
          <Icon name={isLightTheme ? "chevronDown" : "chevronDownWhite"} height={17} width={17} />
        </TouchableOpacity>
      </View>
      <View style={styles.analyticsContainer}>
        <AnalyticsItem
          isActive={true}
          onPress={onOpenTotalLeadsModal}
          title={"Total Results"}
          count={analyticsMock.totalResults!}
          icon={"totalResults"}
          iconFill={background}
          isLightTheme={isLightTheme}
          topIcon={arrowIcon2}
        />
        <AnalyticsItem
          title={"Local Leads"}
          count={analyticsMock.localLeads!}
          icon={"mapPin"}
          iconFill={text}
          isLightTheme={isLightTheme}
          topIcon={arrowIcon1}
          unreadLeads={unreadLeads}
        />
      </View>
      <View style={styles.analyticsContainer}>
        <AnalyticsItem
          title={"Reviews"}
          count={analyticsMock.reviews!}
          icon={"star"}
          iconFill={text}
          isLightTheme={isLightTheme}
          topIcon={arrowIcon1}
        />
        <AnalyticsItem
          title={"Google Profile Actions"}
          count={analyticsMock.googleProfileActions!}
          icon={"google"}
          iconFill={text}
          isLightTheme={isLightTheme}
          topIcon={arrowIcon1}
        />
      </View>
      <View style={styles.analyticsContainer}>
        <AnalyticsItem
          title={"Google Ads Clicks"}
          count={analyticsMock.googleAdsClicks!}
          icon={"googleAds"}
          iconFill={text}
          isLightTheme={isLightTheme}
          topIcon={arrowIcon1}
        />
        <AnalyticsItem
          title={"Listings"}
          count={analyticsMock.listings!}
          icon={"list"}
          iconFill={text}
          isLightTheme={isLightTheme}
          topIcon={arrowIcon1}
        />
      </View>
    </>
  )
}
