import { Pressable, View } from "react-native"

import { Icon, Typography } from "@components"

import { useStyles } from "./styles"

interface Props {
  title: string
  count: number
  icon: IconName
  topIcon: IconName
  iconFill: string
  onPress?: () => void
  isActive?: boolean
  isLightTheme: boolean
  unreadLeads?: number
}

export const AnalyticsItem = ({
  title,
  count,
  icon,
  iconFill,
  onPress,
  isActive,
  topIcon,
  unreadLeads,
}: Props) => {
  const styles = useStyles()
  const unread = `+ ${unreadLeads} new`
  return (
    <Pressable
      onPress={onPress}
      style={[styles.analyticsItem, isActive && styles.activeAnalyticsItem]}
    >
      <View style={styles.analyticsItemTitleContainer}>
        <Typography
          style={[styles.analyticsItemTitle, isActive && styles.activeAnalyticsItemTitle]}
        >
          {title}
        </Typography>
        <Icon name={topIcon} />
      </View>
      <View style={styles.countContainer}>
        <Typography style={[styles.count, isActive && styles.activeCount]}>{count}</Typography>
        <Icon name={icon} fill={iconFill} />
      </View>
      {!!unreadLeads && (
        <View style={styles.unreadLeads}>
          <Typography style={styles.unreadText}>{unread}</Typography>
        </View>
      )}
    </Pressable>
  )
}
