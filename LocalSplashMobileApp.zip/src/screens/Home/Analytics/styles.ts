import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {},
  analyticsHeader: {
    width: "95%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  analyticsHeaderName: {
    fontSize: 24,
    fontWeight: "600",
  },
  filterBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
    paddingLeft: 12,
    paddingRight: 8,
    borderWidth: 2,
    borderColor: colors.greyLight,
    borderRadius: 42,
    gap: 8,
  },
  analyticsContainer: {
    flexDirection: "row",
    gap: 8,
    marginTop: 8,
  },
}))
