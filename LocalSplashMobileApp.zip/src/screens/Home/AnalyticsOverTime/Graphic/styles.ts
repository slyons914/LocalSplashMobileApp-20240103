import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(() => ({
  container: {
    gap: 34,
    flexDirection: "row",
    height: 182,
  },
  placeholder: {
    paddingBottom: 25,
    justifyContent: "center",
    alignItems: "center",
  },
  metrics: {
    justifyContent: "space-between",
    marginBottom: 23,
  },
  list: {
    width: "75%",
  },
  listContent: {
    gap: 16,
  },
  item: {
    gap: 8,
    justifyContent: "flex-end",
    height: "100%",
  },
  bar: {
    width: 42,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
}))
