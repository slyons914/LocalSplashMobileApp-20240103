import { useEffect, useState } from "react"

import { FlatList, View, ViewStyle } from "react-native"

import { Typography } from "@components"
import {
  DataType,
  IGetProfileAnalyticsOverTimeResponseViewModel,
  IReactionsOverTimeViewModel,
} from "@models"

import { useStyles } from "./styles"

interface Props {
  analyticsOverTime: IGetProfileAnalyticsOverTimeResponseViewModel
  dataType: DataType
}

interface RenderItem {
  item: IReactionsOverTimeViewModel
  index: number
}

export const Graphic = ({ analyticsOverTime, dataType }: Props) => {
  const styles = useStyles()

  const [maxCount, setMaxCount] = useState<number | undefined>(0)

  const findMax = () => {
    const maxValue = analyticsOverTime[dataType]?.sort((a, b) => (b.count || 0) - (a.count || 0))[0]
    maxValue && setMaxCount(maxValue.count)
  }

  useEffect(() => {
    findMax()
  }, [dataType])

  const formatDate = (inputDate: Date) => {
    const months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ]
    const date = new Date(inputDate)
    const month = months[date.getUTCMonth()]
    const day = date.getUTCDate()
    return `${month} ${day < 10 ? "0" : ""}${day}`
  }

  const isDataExist = (analyticsOverTime[dataType] ?? []).length > 0

  const renderAnalyticsItem = ({ item, index }: RenderItem) => {
    const barStyle: ViewStyle = {
      backgroundColor: +item.count! === maxCount ? "#FF770B" : "#1E4B7F",
      height: `${(+item.count! / maxCount!) * 100}%`,
    }

    return (
      <View key={index} style={styles.item}>
        <View style={[styles.bar, barStyle]} />
        <Typography>{formatDate(item.date!)}</Typography>
      </View>
    )
  }

  return isDataExist ? (
    <View style={styles.container}>
      <View style={styles.metrics}>
        {new Array(3).fill("").map((item, index) => {
          const handleItem = () => {
            switch (index) {
              case 0:
                return maxCount
              case 1:
                return maxCount && maxCount / 2
              case 2:
                return 0
              default:
                break
            }
          }

          return <Typography key={index}>{handleItem()}</Typography>
        })}
      </View>
      <FlatList
        data={analyticsOverTime[dataType]}
        renderItem={renderAnalyticsItem}
        horizontal
        contentContainerStyle={styles.listContent}
        style={styles.list}
        scrollEnabled
        showsHorizontalScrollIndicator={false}
      />
    </View>
  ) : (
    <View style={styles.placeholder}>
      <Typography>No data to display</Typography>
    </View>
  )
}
