import { TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"
import { DataType, IGetProfileAnalyticsOverTimeResponseViewModel, ResultsLabel } from "@models"

import { Graphic } from "./Graphic"
import { useStyles } from "./styles"

interface Props {
  dataType: DataType
  analyticsOverTime: IGetProfileAnalyticsOverTimeResponseViewModel
  onOpenAnalyticsOverTimeModal: () => void
  resultsLabel: ResultsLabel
  isLightTheme: boolean
}

export const AnalyticsOverTime = ({
  dataType,
  analyticsOverTime,
  onOpenAnalyticsOverTimeModal,
  resultsLabel,
  isLightTheme,
}: Props) => {
  const styles = useStyles()

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Typography style={styles.filterLabel}>Results Over Time</Typography>
        <TouchableOpacity onPress={onOpenAnalyticsOverTimeModal} style={styles.filterBtn}>
          <Typography type={"subtext"} style={styles.filterTitle}>
            {resultsLabel}
          </Typography>
          <Icon name={isLightTheme ? "chevronDown" : "chevronDownWhite"} height={17} width={17} />
        </TouchableOpacity>
      </View>
      <Graphic analyticsOverTime={analyticsOverTime} dataType={dataType} />
    </View>
  )
}
