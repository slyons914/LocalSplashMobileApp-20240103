import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: 24,
  },
  content: {
    alignItems: "center",
    paddingBottom: 120,
  },
  indicatorContainer: {
    justifyContent: "center",
    flex: 1,
  },
  spinner: {
    alignSelf: "center",
  },
}))
