import { useCallback, useEffect, useState } from "react"

import { ActivityIndicator, ScrollView, useColorScheme, View } from "react-native"

import { useFocusEffect } from "@react-navigation/native"
import { observer } from "mobx-react-lite"

import { Header, Logo } from "@components"
import { AnalyticsModal, AnalyticsOverTimeModal, TotalLeadsModal } from "@modals"
import { DataType, ResultsLabel, DateFilter } from "@models"
import { useStore } from "@store"
import { colors, Routes } from "@utils/constants"

import { Analytics } from "./Analytics"
import { AnalyticsOverTime } from "./AnalyticsOverTime"
import { useStyles } from "./styles"

const Component = ({ navigation }: ScreenProps<Routes.Home>) => {
  const { homeStore } = useStore()
  const { setOptions } = navigation
  const {
    analyticsData,
    getProfiles,
    profiles,
    filterAnalytics,
    unreadLeads,
    getUnreadLeads,
    analyticsOverTime,
    getAnalyticsOverTime,
    filterAnalyticsOverTime,
    locationsIndex,
    locationsItem,
    setLocationsItem,
  } = homeStore

  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const styles = useStyles()

  const [dataType, setDataType] = useState<DataType>("leads")

  const [analyticsLabel, setAnalyticsLabel] = useState<string>("All time")
  const [resultsLabel, setResultsLabel] = useState<ResultsLabel>("Local Leads")

  const [dateFilter, setDateFilter] = useState<DateFilter>({
    fromDate: "",
    toDate: "",
  })

  const [analyticsModal, setAnalyticsModal] = useState(false)
  const [analyticsOverTimeModal, setAnalyticsOverTimeModal] = useState(false)
  const [totalLeadsModal, setTotalLeadsModal] = useState(false)

  const fetchFilterAnalytics = async () => {
    if (!locationsItem?.id) return
    filterAnalytics(locationsItem.id, dateFilter.fromDate, dateFilter.toDate)
    filterAnalyticsOverTime(locationsItem.id, dateFilter.fromDate, dateFilter.toDate)
    getUnreadLeads()
  }

  const fetchProfiles = async () => {
    await getProfiles()
    await getUnreadLeads()
  }

  const fetchAnalytics = async (id: number) => {
    const today = new Date()

    const year = today.getFullYear()
    const month = String(today.getMonth() + 1).padStart(2, "0")
    const day = String(today.getDate()).padStart(2, "0")

    const formattedToday = `${year}-${month}-${day}`
    await filterAnalytics(id, "1970-01-01", formattedToday)
  }

  useFocusEffect(
    useCallback(() => {
      fetchProfiles()
    }, []),
  )

  useFocusEffect(
    useCallback(() => {
      const item = profiles?.profiles?.[locationsIndex]
      if (!item?.id || !item.title) return
      fetchAnalytics(item.id)
      getAnalyticsOverTime(item.id)
      setLocationsItem(item)
    }, [profiles, locationsIndex]),
  )

  useEffect(() => {
    fetchFilterAnalytics()
    setOptions({ header: () => <Header name={locationsItem?.name} /> })
  }, [locationsItem, dateFilter])

  return (
    <View style={styles.container}>
      {analyticsData && analyticsOverTime && unreadLeads ? (
        <>
          <ScrollView
            contentContainerStyle={styles.content}
            showsVerticalScrollIndicator={false}
            bounces={false}
          >
            <Logo />
            <Analytics
              analyticsMock={analyticsData}
              isLightTheme={isLightTheme}
              onOpenAnalyticsModal={() => setAnalyticsModal(true)}
              onOpenTotalLeadsModal={() => setTotalLeadsModal(true)}
              analyticsLabel={analyticsLabel}
              unreadLeads={unreadLeads.totalLeadCount}
            />
            <AnalyticsOverTime
              onOpenAnalyticsOverTimeModal={() => setAnalyticsOverTimeModal(true)}
              dataType={dataType}
              analyticsOverTime={analyticsOverTime}
              resultsLabel={resultsLabel}
              isLightTheme={isLightTheme}
            />
          </ScrollView>
        </>
      ) : (
        <View style={styles.indicatorContainer}>
          <ActivityIndicator
            color={colors.common.orangePrimary}
            style={styles.spinner}
            size={"large"}
          />
        </View>
      )}
      <AnalyticsModal
        isVisible={analyticsModal}
        onClose={() => setAnalyticsModal(false)}
        setDateFilter={setDateFilter}
        setAnalyticsLabel={setAnalyticsLabel}
      />
      <AnalyticsOverTimeModal
        isVisible={analyticsOverTimeModal}
        onClose={() => setAnalyticsOverTimeModal(false)}
        setResultsLabel={setResultsLabel}
        setDataType={setDataType}
      />
      <TotalLeadsModal isVisible={totalLeadsModal} onClose={() => setTotalLeadsModal(false)} />
    </View>
  )
}

export const HomeScreen = observer(Component)
