import { useWindowDimensions, View } from "react-native"

import { useNavigation } from "@react-navigation/native"

import { StatusBar, Button, Icon, Typography } from "@components"
import { Routes } from "@utils/constants"

import { useStyles } from "./styles"

export const WelcomeScreen = () => {
  const styles = useStyles()
  const { navigate } = useNavigation()

  const { height } = useWindowDimensions()

  return (
    <View style={styles.container}>
      <StatusBar />
      <Icon height={height * 0.65} style={styles.icon} name={"welcomeIcon"} />
      <View style={styles.content}>
        <Typography style={styles.contentInfo}>
          <Typography style={styles.contentTitle}>Effortlessly</Typography> manage your leads and
          everything else your company needs to succeed
        </Typography>
        <Button
          onPress={() => navigate(Routes.Notifications)}
          label={"get started"}
          right={"arrowRight"}
          btnStyle={styles.button}
        />
      </View>
    </View>
  )
}
