import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: 16,
    justifyContent: "flex-end",
    paddingBottom: 32,
    paddingTop: insets.top || 16,
  },
  content: {
    gap: 40,
  },
  contentTitle: {
    color: colors.blue,
    fontSize: 20,
    fontWeight: "700",
  },
  contentInfo: {
    fontSize: 20,
    fontWeight: "400",
    textAlign: "center",
  },
  button: {
    backgroundColor: colors.orangePrimary,
    justifyContent: "flex-start",
    paddingLeft: 35,
  },
  icon: {
    alignSelf: "center",
  },
}))
