import { useMemo } from "react"

import { View } from "react-native"

import { FlashList } from "@shopify/flash-list"

import { Header, Icon, SearchBar, Typography } from "@components"
import { Routes } from "@utils/constants"

import { useStyles } from "./styles"

interface Message {
  name: string
  preview: string
  unreadAmount: number
}

type ListItem = string | Message

const messages: Array<ListItem> = [
  "This Week",
  { name: "John Doe", preview: "Lorem ipsum dolor sit amet ...", unreadAmount: 2 },
  { name: "Jane Cooper", preview: "Lorem ipsum dolor sit amet ...", unreadAmount: 3 },
  { name: "Brooklyn Simmons", preview: "Lorem ipsum dolor sit amet ...", unreadAmount: 1 },
  "Last Week",
  { name: "John Doe", preview: "Lorem ipsum dolor sit amet ...", unreadAmount: 0 },
  { name: "Jane Cooper", preview: "Lorem ipsum dolor sit amet ...", unreadAmount: 0 },
  { name: "Brooklyn Simmons", preview: "Lorem ipsum dolor sit amet ...", unreadAmount: 0 },
]

export const MessagesScreen = ({ navigation }: ScreenProps<Routes.Messages>) => {
  const { navigate } = navigation

  const styles = useStyles()

  const onBackPress = () => {
    navigate(Routes.Home)
  }

  const stickyIndecies = useMemo(() => {
    return messages.reduce<Array<number>>((acc, item, index) => {
      if (typeof item === "string") {
        acc.push(index)
      }
      return acc
    }, [])
  }, [])

  const renderItem = ({ item }: { item: ListItem }) => {
    if (typeof item === "string") {
      return <Typography style={styles.section}>{item}</Typography>
    }

    const initials = item.name
      .split(" ")
      .map((str) => str[0])
      .join("")

    return (
      <View style={styles.message}>
        <View style={styles.icon}>
          <Typography style={styles.initials}>{initials}</Typography>
        </View>
        <View style={styles.center}>
          <Typography style={styles.name}>{item.name}</Typography>
          <Typography>{item.preview}</Typography>
        </View>
        <View style={styles.right}>
          <Typography>3 min</Typography>
          {item.unreadAmount ? (
            <View style={styles.unreadContainer}>
              <Typography style={styles.unreadText}>{item.unreadAmount}</Typography>
            </View>
          ) : (
            <Icon name={"readChecks"} />
          )}
        </View>
      </View>
    )
  }

  return (
    <View style={styles.container}>
      <Header onLeftPress={onBackPress} style={styles.header} />
      <Typography style={styles.title}>Messages</Typography>
      <SearchBar
        placeholder="Search by Name, Phone Number..."
        value={""}
        onSearch={Promise.resolve}
        style={styles.search}
      />
      <FlashList
        estimatedItemSize={20}
        data={messages}
        renderItem={renderItem}
        stickyHeaderIndices={stickyIndecies}
      />
    </View>
  )
}
