import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  itemContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 16,
    paddingHorizontal: 12,
    width: "100%",
    borderRadius: 12,
  },
  itemText: {
    fontSize: 16,
    fontWeight: "400",
  },
  activeItem: {
    backgroundColor: colors.backgroundSecondary,
  },
}))
