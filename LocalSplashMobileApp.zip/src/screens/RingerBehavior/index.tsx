import { useCallback, useState } from "react"

import { View } from "react-native"

import { useFocusEffect } from "@react-navigation/native"
import { observer } from "mobx-react-lite"

import { SimpleHeader } from "@components"
import { RingerBehavior } from "@models/settings"
import { useStore } from "@store"
import { Routes } from "@utils/constants"

import { RenderItem } from "./RenderItem"
import { useStyles } from "./styles"

const Component = ({ navigation }: ScreenProps<Routes.RingerBehavior>) => {
  const { settingsStore } = useStore()
  const { setRingerBehavior, ringerBehavior } = settingsStore

  const styles = useStyles()
  const { goBack } = navigation

  const [active, setActive] = useState(1)

  const onItemPress = (active: number, setting: RingerBehavior) => {
    setActive(active)
    setRingerBehavior(setting)
  }

  useFocusEffect(
    useCallback(() => {
      switch (ringerBehavior) {
        case RingerBehavior.default:
          setActive(1)
          break
        case RingerBehavior.vibrate:
          setActive(2)
          break
        case RingerBehavior.silent:
          setActive(3)
          break
        default:
          break
      }
    }, []),
  )

  return (
    <View style={styles.container}>
      <SimpleHeader onLeftPress={goBack} title={"Ringer behavior on call"} />
      <RenderItem
        onPress={() => onItemPress(1, RingerBehavior.default)}
        label={RingerBehavior.default}
        active={active === 1}
      />
      <RenderItem
        onPress={() => onItemPress(2, RingerBehavior.vibrate)}
        label={RingerBehavior.vibrate}
        active={active === 2}
      />
      <RenderItem
        onPress={() => onItemPress(3, RingerBehavior.silent)}
        label={RingerBehavior.silent}
        active={active === 3}
      />
    </View>
  )
}

export const RingerBehaviorScreen = observer(Component)
