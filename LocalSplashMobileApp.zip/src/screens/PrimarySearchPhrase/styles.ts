import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    gap: 16,
    paddingHorizontal: 24,
    paddingTop: insets.top | 16,
    backgroundColor: colors.background,
  },
  city: {
    alignSelf: "flex-end",
  },
  spinner: {
    flex: 1,
  },
}))
