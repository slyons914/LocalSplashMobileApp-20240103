import { useCallback, useState } from "react"

import { ActivityIndicator, View } from "react-native"

import { useFocusEffect } from "@react-navigation/native"
import { observer } from "mobx-react-lite"

import { Dropdown, SimpleHeader, Typography } from "@components"
import { AvailableCategory } from "@models/settings"
import { useStore } from "@store"
import { colors, Routes } from "@utils/constants"

import { useStyles } from "./styles"

const Component = ({ navigation }: ScreenProps<Routes.PrimarySearchPhrase>) => {
  const styles = useStyles()
  const { goBack } = navigation

  const { businessInfoStore, homeStore } = useStore()
  const { locationsItem } = homeStore
  const { availableCategories, getAvailableCategories, isLoading, changeAvailableCategories } =
    businessInfoStore

  const [value, setValue] = useState(locationsItem?.title)
  const [selectedItem, setSelectedItem] = useState<AvailableCategory | null>(null)
  const [customTitle, setCustomTitle] = useState("")
  const [loading, setLoading] = useState(false)

  const onSubmit = () => {
    if (locationsItem !== null && locationsItem.id && selectedItem !== null && selectedItem.id) {
      setLoading(true)
      changeAvailableCategories(locationsItem.id, selectedItem!.id, customTitle)
      setLoading(false)
      goBack()
    } else return
  }

  useFocusEffect(
    useCallback(() => {
      getAvailableCategories()
    }, []),
  )

  return (
    <View style={styles.container}>
      <SimpleHeader
        onLeftPress={goBack}
        onRightPress={onSubmit}
        isLoading={loading}
        rightText={"Save"}
        isRightVisible
      />
      {locationsItem && !isLoading ? (
        <>
          <Typography
            style={styles.city}
          >{`${locationsItem.city} ${locationsItem.state}`}</Typography>
          {availableCategories && value && (
            <Dropdown
              data={availableCategories}
              value={value}
              setValue={setValue}
              setSelectedItem={setSelectedItem}
              setCustomTitle={setCustomTitle}
              customTitle={customTitle}
            />
          )}
        </>
      ) : (
        <ActivityIndicator
          color={colors.common.orangePrimary}
          style={styles.spinner}
          size={"large"}
        />
      )}
    </View>
  )
}

export const PrimarySearchPhraseScreen = observer(Component)
