import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: 24,
  },
  nameContainer: {
    marginVertical: 20,
    paddingVertical: 16,
    paddingLeft: 16,
    paddingRight: 8,
    backgroundColor: colors.backgroundSecondary,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderRadius: 8,
  },
  infoBoxItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 14,
  },
  infoPhone: {
    marginLeft: 12,
    fontSize: 20,
    fontWeight: "500",
  },
  infoText: {
    marginLeft: 12,
    fontSize: 16,
  },
  list: {
    marginBottom: 300,
  },
  timelineItem: {
    flexDirection: "row",
    alignItems: "flex-start",
  },
  line: {
    width: 1,
    backgroundColor: colors.subText,

    height: "100%",
    marginLeft: 5,
  },
  dotContainer: {
    position: "absolute",
    left: 0,
    width: "100%",
    flexDirection: "row",

    gap: 20,
  },
  dot: {
    width: 10,
    height: 10,
    backgroundColor: colors.subText,

    borderRadius: 5,
  },
  date: {
    fontWeight: "bold",
    color: colors.subText,
  },

  historyItemTitle: {
    color: colors.subText,

    fontSize: 18,
    fontWeight: "bold",
  },
  description: {
    color: colors.subText,
    marginTop: 5,
  },
  historyTitle: {
    marginBottom: 30,
    marginTop: 50,
    fontSize: 20,
    fontWeight: "500",
  },
  title: {
    fontSize: 20,
  },
  historyTitleAmount: {
    fontSize: 14,
    fontWeight: "400",
  },
  historyItemTypeContainer: {
    backgroundColor: colors.blue,
    flexDirection: "row",
    borderRadius: 4,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  historyItemTypeLabel: {
    color: colors.white,
    fontSize: 14,
    fontWeight: "600",
    paddingLeft: 8,
  },
  historyItemStatus: {
    flexDirection: "row",
    borderRadius: 4,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  historyStatusReadLabel: {
    fontSize: 14,
    fontWeight: "500",
    paddingLeft: 4,
  },
  historyStatusUnreadLabel: {
    color: colors.red,
    fontSize: 14,
    fontWeight: "500",
    paddingLeft: 4,
  },

  statusLabelContainer: {
    marginTop: 12,
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 4,
    backgroundColor: colors.black,
    alignItems: "center",
    alignSelf: "flex-start",
  },
  statusLabelText: {
    color: colors.white,
  },
  historyItemContainer: {
    flex: 1,
    marginLeft: 10,
    padding: 10,
    marginVertical: 30,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: 8,
  },
}))
