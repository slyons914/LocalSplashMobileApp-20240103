import { Alert, Linking, TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"
import { useStore } from "@store"
import { FormatHelper } from "@utils/helpers"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Tab {
  name: string
  icon: IconName
  callback?: () => void
}
interface Props {
  phoneNumber: string | number
  setRequestModal: (value: boolean) => void
}

export const LeadsBottomBar = ({ phoneNumber, setRequestModal }: Props) => {
  const styles = useStyles()

  const { subText } = useColors()

  const { settingsStore } = useStore()
  const { requestSipSettings } = settingsStore

  const contactAlert = () => {
    requestSipSettings()
    Alert.alert("Submitted", "Someone will contact you shortly.")
  }

  const deviceCall = () => {
    Linking.openURL(`tel:${phoneNumber}`)
  }

  const sendEmail = () => {
    Linking.openURL("mailto:support@example.com")
  }

  const makeCallAlert = () => {
    Alert.alert(
      "Want to make a call?",
      "This feature is not available with your current subscription, please contact us to enable.",
      [
        {
          text: "Request Call Tracking",
          onPress: contactAlert,
          style: "default",
        },
        {
          text: `Call ${FormatHelper.formatPhoneNumber(phoneNumber.toString())}`,
          onPress: deviceCall,
          style: "default",
        },
      ],
      {
        cancelable: true,
      },
    )
  }

  const tabs: Array<Tab> = [
    {
      name: "Call",
      icon: "barPhone",
      callback: makeCallAlert,
    },
    {
      name: "Message",
      icon: "barMessage",
    },
    {
      name: "Email",
      icon: "barEmail",
      callback: sendEmail,
    },
    {
      name: "Review",
      icon: "barReview",
      callback: () => {
        setRequestModal(true)
      },
    },
  ]

  const renderTab = ({ name, icon, callback }: Tab, index: number) => {
    return (
      <TouchableOpacity key={index} onPress={callback} style={styles.tab}>
        <Icon name={icon} width={20} height={20} stroke={subText} />
        <Typography style={styles.text}>{name}</Typography>
      </TouchableOpacity>
    )
  }

  return <View style={styles.container}>{tabs.map(renderTab)}</View>
}
