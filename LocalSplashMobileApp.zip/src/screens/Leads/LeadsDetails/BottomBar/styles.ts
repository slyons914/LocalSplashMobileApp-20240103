import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    paddingTop: 8,
    gap: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderTopWidth: 1,
    borderTopColor: colors.orangePrimary,
    paddingBottom: insets.bottom || 16,
    backgroundColor: colors.background,
  },
  tab: {
    gap: 8,
    flexDirection: "column",
    alignItems: "center",
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 32,
  },
  text: {
    color: colors.orangePrimary,
  },
}))
