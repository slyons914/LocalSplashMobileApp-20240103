import { useState } from "react"

import { LayoutAnimation, TouchableOpacity, View } from "react-native"

import { Typography } from "@components"
import { LeadLogType, MessageLeadLog, WebsiteFormLeadLog } from "@models/leads"

import { useStyles } from "./styles"
import { HistoryTypeLabel, HistoryTypeStatus, StatusLabel } from "../../utils"

interface Props {
  item: WebsiteFormLeadLog | MessageLeadLog
  text: string
  icon: IconName
  setLeadLogisRead: (id: number, logId: number) => void
}

const characterLimit = 80

export const WebsiteSMSItem = ({ item, text, icon, setLeadLogisRead }: Props) => {
  const styles = useStyles()
  const [expanded, setExpanded] = useState(false)
  const message = item.message || ""
  const shouldShowExpandButton = message.length > characterLimit
  const toggleExpand = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut)
    setExpanded(!expanded)
  }
  const isSms = item.leadStructure === LeadLogType.Sms
  return (
    <View
      style={[
        styles.historyItemWebsiteContainer,
        item.isRead ? styles.historyReadBackground : styles.historyUnreadBackground,
      ]}
    >
      <View style={styles.headerContainer}>
        <HistoryTypeLabel text={text} icon={icon} />
        <HistoryTypeStatus
          isRead={item.isRead}
          id={item.leadId}
          logId={item.id}
          setLeadLogisRead={setLeadLogisRead}
        />
      </View>
      {expanded ? (
        <Typography style={styles.websiteDescription}>{message}</Typography>
      ) : (
        <Typography style={styles.websiteDescription}>
          {message.length > characterLimit ? `${message.slice(0, characterLimit)}...` : message}
        </Typography>
      )}

      {shouldShowExpandButton && (
        <TouchableOpacity onPress={toggleExpand}>
          <Typography style={styles.expandButton}>{expanded ? "Less" : "More"}</Typography>
        </TouchableOpacity>
      )}

      {isSms && <StatusLabel item={item} />}
    </View>
  )
}
