import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  historyItemWebsiteContainer: {
    flex: 1,
    marginLeft: 10,
    padding: 16,
    marginVertical: 30,
    borderRadius: 5,
  },
  historyReadBackground: {
    backgroundColor: colors.backgroundSecondary,
  },
  historyUnreadBackground: {
    backgroundColor: colors.backgroundLeadItem,
  },
  audioContainer: {
    paddingVertical: 16,
  },
  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
}))
