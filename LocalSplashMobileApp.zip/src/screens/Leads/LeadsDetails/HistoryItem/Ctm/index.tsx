import { useEffect } from "react"

import { View } from "react-native"

import { useProgress } from "react-native-track-player"

import { Track, Typography } from "@components"
import { CallLeadLog } from "@models/leads"
import { usePlayer } from "@providers"

import { useStyles } from "./styles"
import { HistoryTypeLabel, HistoryTypeStatus, StatusLabel } from "../../utils"

interface Props {
  item: CallLeadLog
  setLeadLogisRead: (id: number, logId: number) => void
}

export const CallItem = ({ item, setLeadLogisRead }: Props) => {
  const styles = useStyles()
  const { playing, loading, showPlayer, remove, loadTracks, playTrack } = usePlayer()
  const { position, duration } = useProgress()

  useEffect(() => {
    loadTracks(item)

    return () => {
      remove()
    }
  }, [item])

  const onPlay = () => {
    playTrack(item)
    showPlayer()
  }

  const hasAudio = !!item.audioPath

  return (
    <View
      style={[
        styles.historyItemWebsiteContainer,
        item.isRead ? styles.historyReadBackground : styles.historyUnreadBackground,
      ]}
    >
      <View style={styles.headerContainer}>
        <HistoryTypeLabel text="PHONE CALL" icon="ctmPhone" />
        <HistoryTypeStatus
          isRead={item.isRead}
          setLeadLogisRead={setLeadLogisRead}
          id={item.leadId}
          logId={item.id}
        />
      </View>
      <View style={styles.audioContainer}>
        {hasAudio && <Typography>Call duration: {Math.round(duration)} sec</Typography>}
      </View>

      {hasAudio && (
        <Track
          playing={playing}
          position={position}
          duration={duration}
          loading={loading}
          onPlayToggle={onPlay}
        />
      )}
      <StatusLabel item={item} />
    </View>
  )
}
