import { View } from "react-native"

import { FacebookLeadLog } from "@models/leads"

import { useStyles } from "./styles"
import { HistoryTypeLabel, HistoryTypeStatus } from "../../utils"

interface Props {
  item: FacebookLeadLog
  setLeadLogisRead: (id: number, logId: number) => void
}

export const FaceBookItem = ({ item, setLeadLogisRead }: Props) => {
  const styles = useStyles()

  return (
    <View
      style={[
        styles.historyContainer,
        item.isRead ? styles.historyReadBackground : styles.historyUnreadBackground,
      ]}
    >
      <View style={styles.headerContainer}>
        <HistoryTypeLabel text="FACEBOOK ADS" icon="facebook" />

        <HistoryTypeStatus
          isRead={item.isRead}
          setLeadLogisRead={setLeadLogisRead}
          id={item.leadId}
          logId={item.id}
        />
      </View>
    </View>
  )
}
