import React from "react"

import { View, Text } from "react-native"

import { CtmLeadLog, FacebookLeadLog, LeadLogType, WebsiteFormLeadLog } from "@models/leads"

import { CallItem } from "./Ctm"
import { FaceBookItem } from "./Facebook"
import { WebsiteSMSItem } from "./WebsiteSMS"
import { useStyles } from "../styles"

interface Props {
  item: WebsiteFormLeadLog | CtmLeadLog | FacebookLeadLog
  setLeadLogisRead: (id: number, logId: number) => void
}

export const HistoryItem = ({ item, setLeadLogisRead }: Props) => {
  const styles = useStyles()

  switch (item.leadStructure) {
    case LeadLogType.Website: {
      return (
        <WebsiteSMSItem
          item={item}
          text="WEBSITE"
          icon="website"
          setLeadLogisRead={setLeadLogisRead}
        />
      )
    }
    case LeadLogType.Call:
      return <CallItem item={item} setLeadLogisRead={setLeadLogisRead} />

    case LeadLogType.Sms:
      return (
        <WebsiteSMSItem item={item} text="SMS" icon="sms" setLeadLogisRead={setLeadLogisRead} />
      )
    case LeadLogType.Facebook:
      return <FaceBookItem item={item} setLeadLogisRead={setLeadLogisRead} />

    default:
      return (
        <View style={styles.historyItemContainer}>
          <Text style={styles.historyItemTitle}>{"Placeholder"}</Text>
          <Text style={styles.description}>{"Placeholder"}</Text>
        </View>
      )
  }
}
