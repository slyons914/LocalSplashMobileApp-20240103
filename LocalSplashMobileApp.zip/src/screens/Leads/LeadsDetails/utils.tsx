import { Text, TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"
import { CtmLeadLog } from "@models/leads"
import { FormatHelper } from "@utils/helpers"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  icon: IconName
  text: string
}

interface PropsLabel {
  item: CtmLeadLog
}

interface StatusProps {
  isRead: boolean
  id: number
  logId: number
  setLeadLogisRead: (id: number, logId: number) => void
}

export const HistoryTypeLabel = ({ icon, text }: Props) => {
  const styles = useStyles()

  return (
    <View style={styles.historyItemTypeContainer}>
      <Icon name={icon} />
      <Text style={styles.historyItemTypeLabel}>{text}</Text>
    </View>
  )
}

export const HistoryTypeStatus = ({ isRead, id, logId, setLeadLogisRead }: StatusProps) => {
  const styles = useStyles()

  const { text } = useColors()

  return isRead ? (
    <View style={styles.historyItemStatus}>
      <Icon name={"checkedBlack"} stroke={text} />
      <Typography style={styles.historyStatusReadLabel}>READ</Typography>
    </View>
  ) : (
    <TouchableOpacity onPress={() => setLeadLogisRead(id, logId)}>
      <View style={styles.historyItemStatus}>
        <Icon name="warning" />
        <Typography style={styles.historyStatusUnreadLabel}>UNREAD</Typography>
      </View>
    </TouchableOpacity>
  )
}

export const StatusLabel = ({ item }: PropsLabel) => {
  const styles = useStyles()

  return (
    <View style={styles.statusLabelContainer}>
      <Typography style={styles.statusLabelText}>
        {FormatHelper.capitalizeFirstLetter(item.callStatus || "")}
      </Typography>
    </View>
  )
}
