import { useEffect, useMemo, useState } from "react"

import { ScrollView, Text, TouchableOpacity, View } from "react-native"

import { FlashList } from "@shopify/flash-list"

import { LeadsAPI } from "@api"
import { Icon, Typography } from "@components"
import { LeadsSpamBlockModal, RequestReviewModal } from "@modals"
import { Lead, LeadFilters, LeadLog } from "@models/leads"
import { Routes } from "@utils/constants"
import { FormatHelper } from "@utils/helpers"
import { useColors } from "@utils/hooks"

import { LeadsBottomBar } from "./BottomBar"
import { HistoryItem } from "./HistoryItem/historyItem"
import { useStyles } from "./styles"

export const LeadsDetailsScreen = ({ route }: ScreenProps<Routes.LeadsDetails>) => {
  const [leadsDetails, setLeadsDetails] = useState<Lead | null>(null)
  const [loading, setLoading] = useState(false)
  const [requestModal, setRequestModal] = useState(false)
  const [spamBlockModal, setSpamBlockModal] = useState(false)
  const [leadStatus, setLeadStatus] = useState<LeadFilters>({
    isSpam: null,
    isBooked: null,
    isBlocked: null,
    isResponded: null,
  })

  const handleModalStatus = (value?: Partial<LeadFilters>) => {
    setLeadStatus((prev) => ({ ...prev, ...value }))
  }

  const { id } = route.params

  const getLeadsDetails = async () => {
    setLoading(true)
    const { data } = await LeadsAPI.getLeadsDetails(id)
    setLeadsDetails(data)
    setLoading(false)
  }

  const setLeadLogisRead = async (id: number, logId: number) => {
    await LeadsAPI.setLeadsLogIsRead(id, logId)
    getLeadsDetails()
  }

  const setLeadStatusApi = async (id: number | string, leadStatus: LeadFilters) => {
    await LeadsAPI.setLeadStatus(id, leadStatus)
    getLeadsDetails()
  }

  useEffect(() => {
    setLeadStatusApi(id, leadStatus)
  }, [leadStatus])

  useEffect(() => {
    getLeadsDetails()
    return setLeadsDetails(null)
  }, [id])

  const sortedLeadsHistory = useMemo(() => {
    if (!leadsDetails) return []

    const { websiteFormLeadLogs, ctmLeadLogs, facebookLeadLogs } = leadsDetails

    const websiteLeads = websiteFormLeadLogs?.map((item) => ({ ...item })) || []
    const ctmLeads = ctmLeadLogs?.map((item) => ({ ...item })) || []
    const facebookLeads = facebookLeadLogs?.map((item) => ({ ...item })) || []

    const leads = [...websiteLeads, ...ctmLeads, ...facebookLeads]

    return leads.sort((a, b) => Number(new Date(b.createdAt!)) - Number(new Date(a.createdAt!)))
  }, [leadsDetails])

  const styles = useStyles()

  const renderItem = ({
    item,
    index,
  }: {
    item: (typeof sortedLeadsHistory)[number]
    index: number
  }) => {
    return (
      <View style={styles.timelineItem}>
        {index + 1 !== sortedLeadsHistory.length && <View style={styles.line} />}
        <View style={styles.dotContainer}>
          <View style={styles.dot} />
          {item.createdAt && (
            <Text style={styles.date}>
              {FormatHelper.formatDate(item.createdAt, { time: true })}
            </Text>
          )}
        </View>
        <HistoryItem item={item} setLeadLogisRead={setLeadLogisRead} />
      </View>
    )
  }

  const keyExtractor = (item: LeadLog, index: number) => {
    return (item.id || index).toString()
  }

  const { text } = useColors()

  return (
    <>
      <ScrollView style={styles.container}>
        <View style={styles.nameContainer}>
          <View>
            <Typography type={"title"} style={styles.title}>
              {leadsDetails?.name}
            </Typography>
            {leadsDetails?.isBlocked && <Icon name={"blocked"} />}
            {leadsDetails?.isSpam && <Icon name={"spam"} />}
          </View>
          <TouchableOpacity onPress={() => setSpamBlockModal(true)}>
            <Icon name={"dotsVerticalDark"} stroke={text} />
          </TouchableOpacity>
        </View>
        <View>
          <View style={styles.infoBoxItem}>
            <Icon name="smallPhone" stroke={text} />
            <Typography type={"title"} style={styles.infoPhone}>
              {leadsDetails?.phoneNumber
                ? FormatHelper.formatPhoneNumber(leadsDetails.phoneNumber.toString())
                : "--"}
            </Typography>
          </View>
          <View style={styles.infoBoxItem}>
            <Icon name="email" stroke={text} />
            <Typography type={"title"} style={styles.infoText}>
              {leadsDetails?.email || "--"}
            </Typography>
          </View>
          <View style={styles.infoBoxItem}>
            <Icon name="location" stroke={text} />
            <Typography style={styles.infoText}>{leadsDetails?.streetAddress || "--"}</Typography>
          </View>
        </View>
        <Typography type={"title"} style={styles.historyTitle}>
          {"History "}
          <Typography style={styles.historyTitleAmount}>
            ({sortedLeadsHistory.length || 0} interactions)
          </Typography>
        </Typography>
        <FlashList
          estimatedItemSize={20}
          scrollEnabled={false}
          nestedScrollEnabled={false}
          data={sortedLeadsHistory}
          refreshing={loading}
          keyExtractor={keyExtractor}
          contentContainerStyle={styles.list}
          renderItem={renderItem}
        />
      </ScrollView>
      <LeadsBottomBar
        phoneNumber={leadsDetails?.phoneNumber || ""}
        setRequestModal={setRequestModal}
      />
      <RequestReviewModal isVisible={requestModal} onClose={() => setRequestModal(false)} />
      <LeadsSpamBlockModal
        isSpam={leadsDetails?.isSpam}
        isBlocked={leadsDetails?.isBlocked}
        isVisible={spamBlockModal}
        onClose={() => setSpamBlockModal(false)}
        setLeadStatus={handleModalStatus}
      />
    </>
  )
}
