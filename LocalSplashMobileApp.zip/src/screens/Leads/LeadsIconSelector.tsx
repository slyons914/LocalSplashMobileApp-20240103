import React from "react"

import { Icon } from "@components"
import { LeadListItem, LeadLogType } from "@models/leads"

import { useStyles } from "./styles"

interface Props {
  item: LeadListItem
}

export const LeadsIconSelector = ({ item }: Props) => {
  const styles = useStyles()

  switch (item.lastLeadStructure) {
    case LeadLogType.Website: {
      return (
        <Icon
          name={item.isBlocked ? "webLeadBlocked" : "webLead"}
          height={40}
          width={40}
          style={styles.leadIconSpacing}
        />
      )
    }
    case LeadLogType.Call:
      return (
        <Icon
          name={item.isBlocked ? "leadsPhoneBlocked" : "leadsPhone"}
          height={40}
          width={40}
          style={styles.leadIconSpacing}
        />
      )

    case LeadLogType.Sms:
      return (
        <Icon
          name={item.isBlocked ? "smsIconBlocked" : "smsIcon"}
          height={40}
          width={40}
          style={styles.leadIconSpacing}
        />
      )
    default:
      return <Icon name={"leadsPhone"} height={40} width={40} style={styles.leadIconSpacing} />
  }
}
