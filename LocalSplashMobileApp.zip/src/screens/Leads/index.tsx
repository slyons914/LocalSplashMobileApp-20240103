import { useEffect, useState } from "react"

import { FlatList, TouchableOpacity, View } from "react-native"

import { LeadsAPI } from "@api"
import { Icon, SearchBar, Typography } from "@components"
import { LeadsFiltersModal } from "@modals"
import { LeadFilters, LeadList, LeadListItem } from "@models/leads"
import { Routes, Stacks } from "@utils/constants"
import { FormatHelper } from "@utils/helpers"
import { useColors, useDebounce } from "@utils/hooks"

import { LeadsIconSelector } from "./LeadsIconSelector"
import { useStyles } from "./styles"

export const LeadsScreen = ({ navigation }: ScreenProps<Routes.Leads>) => {
  const { navigate } = navigation

  const [loading, setLoading] = useState(false)
  const [filters, setFilters] = useState<LeadFilters>({
    isSpam: false,
    isBlocked: false,
    isRead: null,
    ProfileId: null,
    FromDate: null,
    ToDate: null,
    Search: "",
  })
  const [filtersModal, setFiltersModal] = useState(false)
  const [leads, setLeads] = useState<LeadList<LeadListItem> | null>(null)
  const styles = useStyles()

  const getLeads = async () => {
    setLoading(true)
    const { data } = await LeadsAPI.getLeads(filters)
    setLeads(data)
    setLoading(false)
  }

  useEffect(() => {
    getLeads()
  }, [filters])

  const handleModalFiler = (value?: Partial<LeadFilters>) => {
    setFilters((prev) => ({ ...prev, ...value }))
  }

  const renderItem = ({ item }: { item: LeadListItem }) => {
    const lastSeenDate = new Date(item.lastInAt)
    const phoneNumber = item.phoneNumber.toString()

    return (
      <TouchableOpacity
        onPress={() => {
          navigate(Stacks.Leads, { screen: Routes.LeadsDetails, params: { id: item.id } })
        }}
      >
        <View style={[styles.leadItemContainer, !item.isRead && styles.leadItemReadedContainer]}>
          <View style={styles.leadIcon}>
            <LeadsIconSelector item={item} />
          </View>
          <View style={styles.leadTitle}>
            <Typography type={"title"} style={[styles.leadName, item.isBlocked && styles.blocked]}>
              {item.name}
            </Typography>
            <Typography type={"title"} style={item.isBlocked && styles.blocked}>
              {FormatHelper.formatPhoneNumber(phoneNumber)}
            </Typography>
            <Typography style={styles.dateText}>
              {FormatHelper.formatDate(lastSeenDate, { time: true })}
            </Typography>
          </View>
          <View style={styles.statusLead}>
            <Icon name={"leadsDetailsArrow"} height={35} width={35} />
            {item.isSpam && !item.isBlocked && <Icon name={"spam"} style={styles.spam} />}
            {!item.isSpam && item.isBlocked && <Icon name={"blocked"} style={styles.spam} />}
            {item.isSpam && item.isBlocked && <Icon name={"spamblock"} style={styles.spamblock} />}
          </View>
        </View>
      </TouchableOpacity>
    )
  }

  const { text } = useColors()

  const onSearchHandler = useDebounce((searchValue?: string) => {
    setFilters((prev: LeadFilters) => ({
      ...prev,
      Search: searchValue,
    }))
  }, 1000)

  const keyExtractor = (item: LeadListItem, index: number) => {
    return (item.id || index).toString()
  }

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <SearchBar
          placeholder="Search by Name, Phone Number..."
          value={filters.Search || ""}
          onSearch={onSearchHandler}
        />
        <View style={styles.leadsHeader}>
          <Typography style={styles.leadsHeaderName}>{`Total (${
            leads?.totalCount || 0
          })`}</Typography>
          <TouchableOpacity style={styles.filterBtn} onPress={() => setFiltersModal(true)}>
            <Typography type={"title"}>Filters</Typography>
            <Icon name={"filters"} stroke={text} height={17} width={17} />
          </TouchableOpacity>
        </View>
      </View>
      <FlatList
        onRefresh={getLeads}
        refreshing={loading}
        data={leads?.items || []}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
      />
      <LeadsFiltersModal
        isVisible={filtersModal}
        onClose={() => setFiltersModal(false)}
        setFilters={handleModalFiler}
        filters={filters}
      />
    </View>
  )
}
