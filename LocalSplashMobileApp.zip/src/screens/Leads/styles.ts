import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  leadsHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  leadsHeaderName: {
    fontSize: 24,
    fontWeight: "600",
  },
  statusLead: {
    width: "15%",
    flexDirection: "column",
    alignItems: "flex-end",
    marginTop: 35,
    height: "100%",
  },
  leadName: {
    fontSize: 20,
    fontWeight: "500",
    lineHeight: 25,
  },
  spam: {
    marginTop: 10,
  },
  spamblock: {
    marginTop: 15,
  },
  headerContainer: {
    paddingHorizontal: 24,
    paddingBottom: 16,
  },
  leadIcon: {
    flexDirection: "column",
    alignItems: "flex-end",
    marginTop: 35,
    height: "100%",
  },
  leadIconSpacing: {
    marginRight: 8,
  },
  filterBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
    paddingLeft: 12,
    paddingRight: 8,
    borderWidth: 2,
    borderColor: colors.greyLight,
    borderRadius: 42,
    gap: 8,
  },
  leadItemContainer: {
    paddingHorizontal: 20,
    height: 100,
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
  },
  leadTitle: {
    width: "70%",
  },
  leadItemReadedContainer: {
    borderColor: colors.orangePrimary,
    borderLeftWidth: 3.5,
    paddingHorizontal: 16.5,
    backgroundColor: isDarkTheme ? colors.darklightBackground : colors.orangeLight,
  },
  dateText: {
    color: colors.greyText,
    marginTop: 10,
  },
  blocked: {
    color: colors.greyText,
  },
  spamBadge: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 50,
    borderColor: colors.red,
    justifyContent: "center",
    width: 90,
  },
  spamText: {
    color: colors.red,
  },
}))
