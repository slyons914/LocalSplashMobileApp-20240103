import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    gap: 16,
    paddingHorizontal: 24,
    paddingTop: insets.top | 16,
    backgroundColor: colors.background,
  },
  screenTitle: {
    color: colors.text,
    fontSize: 24,
    fontWeight: "600",
  },
  inputsContainer: {
    gap: 16,
  },
}))
