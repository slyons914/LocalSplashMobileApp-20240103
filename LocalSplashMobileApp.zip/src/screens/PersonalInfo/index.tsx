import { useCallback, useState } from "react"

import { ActivityIndicator, Alert, ScrollView, View } from "react-native"

import { useFocusEffect } from "@react-navigation/native"

import { UserAPI } from "@api"
import { Input, SimpleHeader, Typography } from "@components"
import { colors, Routes } from "@utils/constants"

import { useStyles } from "./styles"

export const PersonalInfoScreen = ({ navigation }: ScreenProps<Routes.PersonalInfo>) => {
  const styles = useStyles()
  const { goBack } = navigation

  const [isLoading, setIsLoading] = useState(false)

  const [firstName, setFirstName] = useState("")
  const [firstNameError, setFirstNameError] = useState("")
  const [lastName, setLastName] = useState("")
  const [lastNameError, setLastNameError] = useState("")
  const [email, setEmail] = useState("")
  const [emailError, setEmailError] = useState("")
  const [phone, setPhone] = useState("")
  const [phoneError, setPhoneError] = useState("")

  const [secondPhoneState, setSecondPhoneState] = useState("")

  const succesfulChange = () => {
    const isDirty = phone == secondPhoneState
    if (!isDirty) {
      Alert.alert(
        "",
        "Are you sure you want to change your phone number?",
        [
          {
            text: "Cancel",
            onPress: Promise.resolve,
            style: "default",
          },
          {
            text: "Change",
            onPress: changeUserData,
            style: "default",
          },
        ],
        {
          cancelable: true,
        },
      )
    } else {
      changeUserData()
    }
  }

  const fetchUserData = async () => {
    setIsLoading(true)
    const { data } = await UserAPI.getUserData()
    if (!data) return
    setFirstName(data.firstName)
    setLastName(data.lastName)
    setEmail(data.emailAddress)
    setPhone(data.contactPhone)
    setSecondPhoneState(data.contactPhone)
    setIsLoading(false)
  }

  const changeUserData = async () => {
    try {
      const { data, error } = await UserAPI.changeUserData(firstName, lastName, email, phone)

      if (data) {
        goBack()
      } else {
        !!error?.FirstName && setFirstNameError(error.FirstName[0])
        !!error?.LastName && setLastNameError(error.LastName[0])
        !!error?.EmailAddress && setEmailError(error.EmailAddress[0])
        !!error?.ContactPhone && setPhoneError(error.ContactPhone[0])
      }
    } catch (err) {
      console.log("1", err)
    }
  }

  useFocusEffect(
    useCallback(() => {
      fetchUserData()
    }, []),
  )

  return (
    <View style={styles.container}>
      <SimpleHeader
        onLeftPress={goBack}
        rightText={"Save"}
        onRightPress={succesfulChange}
        isRightVisible
      />
      <Typography style={styles.screenTitle}>Personal Info</Typography>
      {isLoading ? (
        <ActivityIndicator color={colors.common.orangePrimary} size={"large"} />
      ) : (
        <ScrollView
          contentContainerStyle={styles.inputsContainer}
          showsVerticalScrollIndicator={false}
        >
          <Input
            label="First name*"
            value={firstName}
            onChange={setFirstName}
            error={firstNameError}
            setError={setFirstNameError}
          />
          <Input
            label="Last Name*"
            value={lastName}
            onChange={setLastName}
            error={lastNameError}
            setError={setLastNameError}
          />
          <Input
            label="Email*"
            value={email}
            onChange={setEmail}
            error={emailError}
            setError={setEmailError}
          />
          <Input
            label="Phone*"
            value={phone}
            onChange={setPhone}
            error={phoneError}
            setError={setPhoneError}
            type={"phone"}
          />
        </ScrollView>
      )}
    </View>
  )
}
