import { useCallback, useMemo, useState } from "react"

import { ActivityIndicator, ScrollView, useColorScheme, View } from "react-native"

import { useFocusEffect } from "@react-navigation/native"
import { observer } from "mobx-react-lite"

import { Icon, Input, Locations, SimpleHeader, Tabs, Typography } from "@components"
import {
  EditAddressModal,
  EditEmailModal,
  EditNameModal,
  EditPhoneModal,
  EditWebsiteModal,
} from "@modals"
import { useStore } from "@store"
import { colors, Routes } from "@utils/constants"

import { GoogleCategories } from "./GoogleCategories"
import { useStyles } from "./styles"

const tabs = ["Location", "Keywords", "Content", "Media"]

const Component = ({ navigation }: ScreenProps<Routes.BusinessInformation>) => {
  const styles = useStyles()
  const { goBack, navigate } = navigation

  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const { businessInfoStore, homeStore } = useStore()
  const { profiles, locationsIndex, locationsItem } = homeStore
  const {
    getLocationInfo,
    locationInfo,
    isLoading,
    profileGoogleCategories,
    getProfileGoogleCategories,
  } = businessInfoStore

  const [nameModal, setNameModal] = useState(false)
  const [phoneModal, setPhoneModal] = useState(false)
  const [emailModal, setEmailModal] = useState(false)
  const [websiteModal, setWebsiteModal] = useState(false)
  const [addressModal, setAddressModal] = useState(false)

  const onEditWebsitePress = () => {
    if (locationInfo?.isWebsiteEditable) {
      setWebsiteModal(true)
    } else return
  }

  const searchTerms = useMemo((): string => {
    if (!locationsItem) return ""
    return locationsItem.searchTerms.map((item: string) => `• ${item}`).join("\n")
  }, [locationsItem])

  useFocusEffect(
    useCallback(() => {
      const item = profiles?.profiles?.[locationsIndex]
      if (!item?.id) return
      getLocationInfo(item.id)
      getProfileGoogleCategories(item.id)
    }, [profiles, locationsIndex]),
  )

  return (
    <View style={styles.container}>
      <SimpleHeader onLeftPress={goBack} />
      <Typography style={styles.screenTitle}>Business Information</Typography>
      <Locations />
      <Tabs tabs={tabs} />
      {!isLoading ? (
        <>
          <ScrollView
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps={"handled"}
          >
            {locationInfo && (
              <View style={styles.sectionContent}>
                <View style={styles.section}>
                  <Typography style={styles.sectionTitle}>Location Information</Typography>
                  <Icon name={isLightTheme ? "helpSquareBlack" : "helpSquare"} />
                </View>
                <Input
                  label={"Business Name"}
                  onPress={() => setNameModal(true)}
                  value={locationInfo.name}
                  editable={false}
                />
                <Input
                  onPress={() => setAddressModal(true)}
                  label={"Address"}
                  value={locationInfo.address}
                  editable={false}
                />
                <Input
                  onPress={() => setPhoneModal(true)}
                  label={"Phone"}
                  value={locationInfo.phone}
                  type={"phone"}
                  editable={false}
                />
                <Input
                  label={"Tracking Phone Number"}
                  value={locationInfo.trackingPhone}
                  type={"phone"}
                  disabled
                  editable={false}
                />
                <Input
                  onPress={() => setEmailModal(true)}
                  label={"Email"}
                  value={locationInfo.email}
                  editable={false}
                />
                <Input
                  onPress={onEditWebsitePress}
                  label={"Website"}
                  value={locationInfo.website}
                  editable={false}
                  disabled={!locationInfo.isWebsiteEditable}
                />
                <EditNameModal isVisible={nameModal} onClose={() => setNameModal(false)} />
                <EditPhoneModal isVisible={phoneModal} onClose={() => setPhoneModal(false)} />
                <EditEmailModal isVisible={emailModal} onClose={() => setEmailModal(false)} />
                <EditWebsiteModal isVisible={websiteModal} onClose={() => setWebsiteModal(false)} />
                <EditAddressModal isVisible={addressModal} onClose={() => setAddressModal(false)} />
              </View>
            )}
            {locationsItem && profileGoogleCategories && (
              <View style={styles.sectionContent}>
                <View style={styles.section}>
                  <Typography style={styles.sectionTitle}>Keywords</Typography>
                  <Icon name={isLightTheme ? "helpSquareBlack" : "helpSquare"} />
                </View>
                <Input
                  onPress={() => navigate(Routes.PrimarySearchPhrase)}
                  label={"Primary Search Phrase"}
                  value={locationsItem.title!}
                  editable={false}
                  disabled={false}
                />
                <GoogleCategories
                  value={profileGoogleCategories}
                  label={"Google Categories"}
                  onPress={Promise.resolve}
                />
                <Input
                  label={"Search Phrases"}
                  onPress={Promise.resolve}
                  value={searchTerms}
                  editable={false}
                  disabled
                  multiline
                />
              </View>
            )}
          </ScrollView>
        </>
      ) : (
        <ActivityIndicator
          color={colors.common.orangePrimary}
          style={styles.spinner}
          size={"large"}
        />
      )}
    </View>
  )
}

export const BusinessInformationScreen = observer(Component)
