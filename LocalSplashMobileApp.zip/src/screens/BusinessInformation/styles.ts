import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    gap: 16,
    paddingHorizontal: 24,
    paddingTop: insets.top | 16,
    backgroundColor: colors.background,
  },
  screenTitle: {
    color: colors.text,
    fontSize: 24,
    fontWeight: "600",
  },
  scrollContent: {
    gap: 24,
  },
  sectionContent: {
    gap: 16,
  },
  section: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "500",
  },
  spinner: {
    flex: 1,
  },
}))
