import { Switch, View } from "react-native"

import { observer } from "mobx-react-lite"

import { SimpleHeader, Typography } from "@components"
import { useStore } from "@store"
import { colors, Routes } from "@utils/constants"

import { useStyles } from "./styles"

const Component = ({ navigation }: ScreenProps<Routes.SettingsNotifications>) => {
  const { settingsStore } = useStore()
  const { setNotificationsState, notificationsEnabled } = settingsStore

  const styles = useStyles()
  const { goBack } = navigation

  const toggleSwitch = () => {
    setNotificationsState(!notificationsEnabled)
  }

  return (
    <View style={styles.container}>
      <SimpleHeader onLeftPress={goBack} rightText={"Save"} isRightVisible />
      <Typography style={styles.screenTitle}>Notifications</Typography>
      <View style={styles.switchContainer}>
        <Typography>All push notifications</Typography>
        <Switch
          value={notificationsEnabled}
          onChange={toggleSwitch}
          thumbColor={"#FFF"}
          trackColor={{ true: colors.common.green, false: "#78788029" }}
        />
      </View>
      <Typography>
        Turn on to be able to see in real time when your customers are trying to reach you.
      </Typography>
    </View>
  )
}

export const SettingsNotificationsScreen = observer(Component)
