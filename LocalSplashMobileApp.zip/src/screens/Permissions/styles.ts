import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: 16,
    paddingBottom: 32,
    alignItems: "center",
    justifyContent: "center",
    paddingTop: insets.top || 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
  },
  text: {
    fontSize: 16,
    textAlign: "center",
    maxWidth: 300,
    marginTop: 8,
  },
  infoBlock: {
    gap: 12,
    marginTop: 24,
    marginBottom: 24,
  },
  settingsText: {
    textAlign: "center",
    maxWidth: 300,
    fontSize: 16,
  },
  settings: {
    color: colors.orangePrimary,
  },
  later: {
    color: colors.orangePrimary,
    fontSize: 16,
    fontWeight: "500",
    marginTop: 40,
  },
}))
