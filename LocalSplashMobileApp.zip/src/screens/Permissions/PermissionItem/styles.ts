import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme, width }) => ({
  container: {
    padding: 16,
    backgroundColor: isDarkTheme ? colors.lightBlack : colors.superLightBlue,
    borderRadius: 16,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: width * 0.9,
  },
  leftBlock: {
    flexDirection: "row",
    gap: 16,
  },
  blueCircle: {
    height: 50,
    width: 50,
    borderRadius: 25,
    backgroundColor: colors.blue,
    alignItems: "center",
    justifyContent: "center",
  },
  label: {
    fontSize: 16,
    fontWeight: "500",
  },
  text: {
    maxWidth: 200,
  },
  textBlock: {
    gap: 4,
  },
}))
