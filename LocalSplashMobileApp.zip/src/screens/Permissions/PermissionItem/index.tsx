import { Switch, View } from "react-native"

import { Icon, Typography } from "@components"
import { colors } from "@utils/constants"

import { useStyles } from "./styles"

interface Props {
  iconName: IconName
  value: boolean
  onChange: () => void
  label: string
  text: string
}

export const PermissionsItem = ({ iconName, value, onChange, label, text }: Props) => {
  const styles = useStyles()

  return (
    <View style={styles.container}>
      <View style={styles.leftBlock}>
        <View style={styles.blueCircle}>
          <Icon name={iconName} />
        </View>
        <View style={styles.textBlock}>
          <Typography style={styles.label}>{label}</Typography>
          <Typography type={"subtext"} style={styles.text}>
            {text}
          </Typography>
        </View>
      </View>
      <Switch
        value={value}
        onChange={onChange}
        thumbColor={"#FFF"}
        trackColor={{ true: colors.common.green, false: "#78788029" }}
      />
    </View>
  )
}
