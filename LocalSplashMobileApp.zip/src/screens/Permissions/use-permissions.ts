import { useState } from "react"

import { Platform } from "react-native"

import { PERMISSIONS, RESULTS, request } from "react-native-permissions"

import { useCall } from "@providers"

const initials = {
  micro: false,
  camera: false,
  galery: false,
}

export const usePermissions = () => {
  const [permissions, setPermissions] = useState(initials)

  const { setup } = useCall()

  const requestPermission = async (type: keyof typeof initials) => {
    let isGranted: boolean | undefined

    switch (type) {
      case "micro": {
        if (Platform.OS === "android") {
          isGranted = await setup()
        } else {
          const status = await request(PERMISSIONS.IOS.MICROPHONE)
          isGranted = status === RESULTS.GRANTED || status === RESULTS.LIMITED
        }
        break
      }
      case "camera": {
        const permission = Platform.select({
          ios: PERMISSIONS.IOS.CAMERA,
          android: PERMISSIONS.ANDROID.CAMERA,
        })

        const status = permission ? await request(permission) : RESULTS.BLOCKED
        isGranted = status === RESULTS.GRANTED || status === RESULTS.LIMITED
        break
      }
      case "galery": {
        const permission = Platform.select({
          ios: PERMISSIONS.IOS.PHOTO_LIBRARY,
          android: PERMISSIONS.ANDROID.READ_MEDIA_IMAGES,
        })

        const status = permission ? await request(permission) : RESULTS.BLOCKED
        isGranted = status === RESULTS.GRANTED || status === RESULTS.LIMITED
        break
      }
    }

    setPermissions((permissions) => ({ ...permissions, [type]: isGranted }))
  }

  return { permissions, requestPermission }
}
