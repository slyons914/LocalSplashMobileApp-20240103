import { useState } from "react"

import { Linking, View } from "react-native"

import { useNavigation } from "@react-navigation/native"
import { SafeAreaView } from "react-native-safe-area-context"

import { Button, StatusBar, Typography } from "@components"
import { AreYouShureModal } from "@modals"
import { Routes } from "@utils/constants"

import { PermissionsItem } from "./PermissionItem"
import { useStyles } from "./styles"
import { usePermissions } from "./use-permissions"

export const PermissionsScreen = () => {
  const styles = useStyles()
  const { navigate } = useNavigation()

  const [confirmModal, setConfirmModal] = useState(false)

  const { permissions, requestPermission } = usePermissions()

  const allPemrissionsGranted = Object.values(permissions).every(Boolean)

  const onDecline = () => {
    setConfirmModal(false)
    navigate(Routes.Login)
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar />
      <Typography style={styles.title}>App Permissions</Typography>
      <Typography type={"subtext"} style={styles.text}>
        Before we get started, you'll want to grant the following permissions for the best app
        experience:
      </Typography>
      <View style={styles.infoBlock}>
        <PermissionsItem
          label={"Camera"}
          text={"To take and upload photos"}
          iconName={"camera"}
          value={permissions.camera}
          onChange={() => requestPermission("camera")}
        />
        <PermissionsItem
          label={"Microphone"}
          text={"To place & receive calls"}
          iconName={"microphone"}
          value={permissions.micro}
          onChange={() => requestPermission("micro")}
        />
        <PermissionsItem
          label={"Access to gallery"}
          text={"To update media gallery"}
          iconName={"image"}
          value={permissions.galery}
          onChange={() => requestPermission("galery")}
        />
      </View>

      {allPemrissionsGranted ? (
        <Button label="Continue" onPress={() => navigate(Routes.Login)} right={"arrowRight"} />
      ) : (
        <>
          <Typography type={"subtext"} style={styles.settingsText}>
            You can always adjust these later from within the{" "}
            <Typography onPress={Linking.openSettings} style={styles.settings}>
              System Settings.
            </Typography>
          </Typography>
          <Typography onPress={() => setConfirmModal(true)} style={styles.later}>
            Maybe later
          </Typography>
        </>
      )}
      <AreYouShureModal
        isVisible={confirmModal}
        onClose={() => setConfirmModal(false)}
        onEnable={() => setConfirmModal(false)}
        onDecline={onDecline}
        text={"These permissions are required for the application to function properly."}
      />
    </SafeAreaView>
  )
}
