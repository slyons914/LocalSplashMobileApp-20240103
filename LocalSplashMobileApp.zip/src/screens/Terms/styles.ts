import { Platform } from "react-native"

import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets, height }) => ({
  btnContainer: {
    alignItems: "center",
    gap: 16,
  },
  textBtn: {
    color: colors.orangePrimary,
  },
  termsTitle: {
    fontSize: 24,
    fontWeight: "700",
    marginVertical: 4,
  },
  termsTitleSmall: {
    color: colors.text,
    fontSize: 20,
    fontWeight: "600",
    marginVertical: 4,
  },
  termsText: {
    marginVertical: 4,
  },
  termsBlock: {
    marginVertical: 10,
  },
  modalContainer: {
    backgroundColor: colors.background,
    justifyContent: "space-between",
    paddingTop: insets.top || 8,
    paddingBottom: insets.bottom || 16,
    flex: 1,
    paddingHorizontal: 20,
  },
  modalContent: {
    flexGrow: 1,
  },
  confirmBlock: {
    flexDirection: "row",
    gap: 12,
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  termsLink: {
    color: colors.orangePrimary,
    textDecorationLine: "underline",
  },
  inputContainer: {
    gap: 16,
    marginVertical: 20,
  },
  spinner: {
    alignSelf: "center",
    marginTop: height * 0.5,
  },
  confirmation: {
    marginVertical: 0,
  },
  confirmSMSBlock: {
    flexDirection: "row",
    gap: 12,
    paddingVertical: 10,
    paddingHorizontal: Platform.OS === "ios" ? 5 : 15,
  },
}))
