import { useEffect, useState } from "react"

import { ActivityIndicator, ScrollView, View } from "react-native"

import { useNavigation } from "@react-navigation/native"
import jwt_decode from "jwt-decode"

import { MobileAPI } from "@api"
import { Button, Typography } from "@components"
import { DecodedToken, GetTermsAndConditionsContentResponseViewModel } from "@models"
import { useStore } from "@store"
import { colors, Routes, Stacks } from "@utils/constants"

import { ConfirmTemrsModal } from "./ConfirmTermsModal"
import { Content } from "./Content"
import { useStyles } from "./styles"

export const TermsScreen = () => {
  const styles = useStyles()
  const { navigate } = useNavigation()
  const [check, setCheck] = useState<boolean>(false)
  const [checkSMS, setCheckSMS] = useState<boolean>(false)
  const [terms, setTerms] = useState<GetTermsAndConditionsContentResponseViewModel | null>(null)

  const { authStore } = useStore()
  const { accessToken } = authStore

  const decoded: DecodedToken = jwt_decode(accessToken)

  const handleCheck = () => {
    setCheck(!check)
  }

  const handleCheckSMS = () => {
    setCheckSMS(!checkSMS)
  }

  const [name, setName] = useState("")
  const [error, setError] = useState<string | null | undefined>(null)
  const [confirmTemrsModal, setConfirmTemrsModal] = useState(false)
  const [isloading, setIsLoading] = useState(false)

  const today = new Date()
  const day = today.getDate().toString().padStart(2, "0")
  const month = (today.getMonth() + 1).toString().padStart(2, "0")
  const year = today.getFullYear()

  const formattedToday = `${month}/${day}/${year}`

  const onChangeName = (text: string) => {
    setName(text)
    setError(null)
  }

  const onConfirmPress = async () => {
    if (!check || !checkSMS || name.length === 0) return
    setIsLoading(true)
    const { error } = await MobileAPI.confirmTerms(name)
    if (error) {
      setError(error)
      setIsLoading(false)
    } else {
      setIsLoading(false)
      setConfirmTemrsModal(false)
      navigate(Stacks.Home, { screen: Routes.Home })
    }
  }

  const fetchTerms = async () => {
    const { data } = await MobileAPI.getTerms()
    setTerms(data)
  }

  useEffect(() => {
    fetchTerms()
  }, [])

  return (
    <View style={styles.modalContainer}>
      {terms ? (
        <ScrollView
          scrollEnabled
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.modalContent}
        >
          <Typography style={styles.termsTitle}>Local Splash Terms of Experience</Typography>
          <Content html={terms.content} />
        </ScrollView>
      ) : (
        <ActivityIndicator
          color={colors.common.orangePrimary}
          style={styles.spinner}
          size={"large"}
        />
      )}
      <View style={styles.btnContainer}>
        <Button onPress={() => setConfirmTemrsModal(true)} label={"I agree"} />
      </View>
      <ConfirmTemrsModal
        isVisible={confirmTemrsModal}
        onClose={() => setConfirmTemrsModal(false)}
        fullName={terms?.firstLastBillingName}
        name={name}
        setName={onChangeName}
        formattedToday={formattedToday}
        onConfirmPress={onConfirmPress}
        decoded={decoded}
        handleCheckSMS={handleCheckSMS}
        checkSMS={checkSMS}
        handleCheck={handleCheck}
        check={check}
        error={error}
        isloading={isloading}
      />
    </View>
  )
}
