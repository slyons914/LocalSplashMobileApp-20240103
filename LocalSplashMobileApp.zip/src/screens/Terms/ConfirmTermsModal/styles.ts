import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, height }) => ({
  modal: {
    margin: 0,
    justifyContent: "flex-end",
  },
  container: {
    backgroundColor: colors.background,
    minHeight: height * 0.95,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    alignItems: "center",
    padding: 16,
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
    marginTop: 8,
  },
  dash: {
    backgroundColor: colors.grey,
    height: 5,
    width: 36,
    borderRadius: 20,
    position: "absolute",
    top: 5,
  },
  content: {
    flex: 1,
    marginBottom: 24
  },
  termsText: {
    marginVertical: 4,
  },
  termsTitleSmall: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "600",
  },
  inputContainer: {
    gap: 16,
    marginVertical: 20,
    paddingHorizontal: 16,
  },
  confirmation: {
    marginVertical: 0,
    maxWidth: 270,
  },
  confirmBlock: {
    flexDirection: "row",
    gap: 12,
    paddingVertical: 10,
  },
  concelBtn: {
    position: "absolute",
    top: 24,
    left: 16,
  },
  cancelText: {
    color: colors.orangePrimary,
    fontSize: 16,
  },
  nameInputBlock: {
    gap: 6,
  },
  orangeText: {
    color: colors.orangePrimary,
  },
  errorText: {
    color: colors.red,
    textAlign: "center",
  },
}))
