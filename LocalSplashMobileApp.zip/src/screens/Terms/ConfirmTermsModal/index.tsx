import {
  KeyboardAvoidingView,
  KeyboardAvoidingViewProps,
  Linking,
  Platform,
  Pressable,
  ScrollView,
  View,
} from "react-native"

import Modal from "react-native-modal"

import { Button, Checkbox, Typography } from "@components"
import { DecodedToken } from "@models"

import { useStyles } from "./styles"
import { Input } from "../Input"
import { NameInput } from "../NameInput"

interface Props {
  isVisible: boolean
  onClose: () => void
  fullName?: string
  name: string
  setName: (name: string) => void
  formattedToday: string
  onConfirmPress: () => void
  decoded: DecodedToken
  handleCheckSMS: () => void
  handleCheck: () => void
  checkSMS: boolean
  check: boolean
  error?: string | null | undefined
  isloading?: boolean
}

export const ConfirmTemrsModal = ({
  isVisible,
  onClose,
  fullName,
  name,
  setName,
  formattedToday,
  onConfirmPress,
  decoded,
  handleCheckSMS,
  checkSMS,
  check,
  handleCheck,
  error,
  isloading,
}: Props) => {
  const styles = useStyles()

  const onOrangeTextPress = () => {
    Linking.openURL("https://localsplash.com/terms-and-conditions")
  }

  const behavior = Platform.select<KeyboardAvoidingViewProps["behavior"]>({
    ios: "padding",
  })

  return (
    <Modal
      isVisible={isVisible}
      onBackdropPress={onClose}
      onBackButtonPress={onClose}
      style={styles.modal}
    >
      <KeyboardAvoidingView behavior={behavior} style={styles.container} >
        <View style={styles.dash} />
        <Typography type={"title"} style={styles.title}>
          Confirm Signature
        </Typography>
        <Pressable style={styles.concelBtn} onPress={onClose}>
          <Typography style={styles.cancelText}>Cancel</Typography>
        </Pressable>
        <ScrollView showsVerticalScrollIndicator={false} style={styles.content} overScrollMode={"always"} bounces={false} >
          <View style={styles.inputContainer}>
            <View style={styles.nameInputBlock}>
              <Typography>Phone Number*</Typography>
              <Input phoneMask={true} value={decoded.phone_number} editable={false} />
            </View>
            <View>
              <View style={styles.confirmBlock}>
                <Checkbox value={checkSMS} onPress={handleCheckSMS} />
                <Typography style={[styles.termsText, styles.confirmation]}>
                  I agree to receive SMS messages sent to my phone number.
                </Typography>
              </View>
              <View style={styles.confirmBlock}>
                <Checkbox value={check} onPress={handleCheck} />
                <Typography style={[styles.termsText, styles.confirmation]}>
                  I certify that I am the authorized holder and signer of the credit card and that
                  all of the information is complete and accurate.
                </Typography>
              </View>
            </View>
            <Typography style={styles.termsText}>
              By signing my eSignature below, I affirm that I am authorized to enter into this
              Statement of Work on behalf of The Company. Furthermore, I acknowledge that I have
              read, understand, and agree to{" "}
              <Typography onPress={onOrangeTextPress} style={styles.orangeText}>
                Local Splash Terms and Conditions
              </Typography>{" "}
              . I also acknowledge that my eSignature is the electronic equivalent of a handwritten
              signature.
            </Typography>
            <Typography style={styles.termsTitleSmall}>Signature</Typography>
            <Typography>
              To agree please electronically sign this document by typing your name exactly as it
              appears bellow and click “Confirm Signature”.
            </Typography>
            <Typography style={styles.termsTitleSmall}>Your Name: {fullName}</Typography>
            <NameInput onChange={setName} value={name} onSubmitEditing={onConfirmPress} />
            <Input value={formattedToday} editable={false} />
            {!!error && <Typography style={styles.errorText}>{error}</Typography>}
          </View>

          <Button
            label={"Confirm Signature"}
            onPress={onConfirmPress}
            disabled={!check || !checkSMS || name.length === 0}
            isLoading={isloading}
          />
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  )
}
