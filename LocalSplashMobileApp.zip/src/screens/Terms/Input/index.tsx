import { TextInput, useColorScheme, View } from "react-native"

import { TextInputMask } from "react-native-masked-text"

import { colors } from "@utils/constants"

import { useStyles } from "./styles"

interface Props {
  value: string
  editable?: boolean
  phoneMask?: boolean
}

export const Input = ({ value, editable, phoneMask }: Props) => {
  const styles = useStyles()

  const isDarkTheme = useColorScheme() === "dark"
  const placeholderColor = isDarkTheme ? colors.common.white : colors.common.grey

  return (
    <View style={styles.container}>
      {phoneMask ? (
        <TextInputMask
          editable={editable}
          // onChangeText={(text, rawText) => handleChangePhone(text, rawText)}
          value={value}
          type={"cel-phone"}
          options={{
            maskType: "BRL",
            withDDD: true,
            dddMask: "(999) 999-9999",
          }}
          style={styles.input}
          placeholder={"Your phone number"}
          placeholderTextColor={placeholderColor}
          maxLength={14}
          textContentType={"telephoneNumber"}
          dataDetectorTypes={"phoneNumber"}
          includeRawValueInChangeText={true}
        />
      ) : (
        <TextInput editable={editable} style={styles.input} value={value} />
      )}
    </View>
  )
}
