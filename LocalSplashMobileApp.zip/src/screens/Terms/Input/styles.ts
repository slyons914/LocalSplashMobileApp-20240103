import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme }) => ({
  container: {
    backgroundColor: isDarkTheme ? colors.darklightBackground : colors.greyLight,
    paddingHorizontal: 24,
    paddingVertical: 16,
    borderRadius: 8,
  },
  input: {
    padding: 0,
    color: colors.title,
  },
}))
