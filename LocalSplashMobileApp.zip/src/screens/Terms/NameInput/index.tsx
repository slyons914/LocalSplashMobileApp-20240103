import { TextInput, View } from "react-native"

import { useStyles } from "./styles"

interface Props {
  value: string
  onChange: (text: string) => void
  onSubmitEditing: () => void
}

export const NameInput = ({ value, onChange, onSubmitEditing }: Props) => {
  const styles = useStyles()

  return (
    <View style={styles.container}>
      <TextInput
        value={value}
        autoComplete={"off"}
        autoCapitalize={"none"}
        style={styles.input}
        onChangeText={onChange}
        placeholder={"Enter your name"}
        onSubmitEditing={onSubmitEditing}
      />
    </View>
  )
}
