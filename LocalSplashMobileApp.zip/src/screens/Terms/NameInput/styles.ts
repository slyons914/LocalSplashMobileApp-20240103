import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme }) => ({
  container: {
    paddingHorizontal: 24,
    paddingVertical: 16,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: isDarkTheme ? colors.darklightBackground : colors.grey,
  },
  input: {
    padding: 0,
    color: colors.text,
  },
}))
