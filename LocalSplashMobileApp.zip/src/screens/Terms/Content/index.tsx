import { useState } from "react"

import { StyleProp, ViewStyle } from "react-native"

import WebView, { WebViewMessageEvent } from "react-native-webview"

import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  html?: string
  style?: StyleProp<ViewStyle>
}

const injectHtml = (html: string) => {
  return `
    <!DOCTYPE HTML>
    <html>
      <head>
        <link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1" />
        <style>
          body {
            font-family: Poppins;
          }
          .tnc {
            font-size: 14px;
          }
        </style>
      </head>
      <body>
        ${html}
      </body>
    </html>
  `
}

const injectJS = (backgroundColor: string, color: string) => {
  return `
      document.body.style.backgroundColor = '${backgroundColor}'
      document.body.style.color = '${color}'
      document.querySelectorAll('.tnc').forEach((item) => {
        item.style.color = '${color}'
      })

      const timeout = setTimeout(() => {
        window.ReactNativeWebView.postMessage(document.body.offsetHeight + 16)
        clearTimeout(timeout)
      }, 100)
    `
}

export const Content = ({ html, style }: Props) => {
  const [height, setHeight] = useState(0)

  const styles = useStyles()

  const { background, text } = useColors()

  if (!html) return null

  const onMessage = ({ nativeEvent }: WebViewMessageEvent) => {
    setHeight(Number(nativeEvent.data))
  }

  const key = `${background}-${text}`

  return (
    <WebView
      key={key}
      onMessage={onMessage}
      scrollEnabled={false}
      source={{ html: injectHtml(html) }}
      injectedJavaScript={injectJS(background, text)}
      style={[styles.webview, { height }, style]}
    />
  )
}
