import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, isDarkTheme, insets }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    gap: 16,
    paddingHorizontal: 24,
    paddingTop: insets.top || 16,
    paddingBottom: insets.bottom || 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
  },
  buttonsBlock: {
    flex: 1,
    padding: 16,
    borderRadius: 16,
    backgroundColor: isDarkTheme ? colors.lightBlack : colors.superLightBlue,
  },
  blockedButtonsBlock: {
    backgroundColor: isDarkTheme ? colors.lightBlack : colors.greyLight,
  },
  buttonsBlockTitle: {
    color: colors.blue,
    fontSize: 16,
    fontWeight: "600",
    marginBottom: 8,
  },
  blockedbuttonsBlockTitle: {
    color: colors.greyDarkMode,
  },
  logOutBtn: {
    flexDirection: "row",
    gap: 8,
  },
  logOutText: {
    fontSize: 16,
    color: colors.orangePrimary,
    fontWeight: "500",
  },
  contactUs: {
    color: colors.orangePrimary,
  },
}))
