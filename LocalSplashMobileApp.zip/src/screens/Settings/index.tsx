import { useState } from "react"

import { ScrollView, TouchableOpacity, View } from "react-native"

import { observer } from "mobx-react-lite"

import { Icon, SimpleHeader, Typography } from "@components"
import { LogOutModal } from "@modals"
import { useStore } from "@store"
import { Routes } from "@utils/constants"

import { SettingsItem } from "./SettingsItem"
import { useStyles } from "./styles"

export const Component = ({ navigation }: ScreenProps<Routes.Settings>) => {
  const { settingsStore } = useStore()
  const { notificationsEnabled, callsSettings, sipSettings } = settingsStore

  const isSipNotAvailable = !sipSettings?.profileId

  const styles = useStyles()
  const { goBack, navigate } = navigation

  const [logOut, setLogOut] = useState(false)

  return (
    <ScrollView contentContainerStyle={styles.content} style={styles.container}>
      <View>
        <SimpleHeader onLeftPress={goBack} />
        <Typography style={styles.title}>Settings</Typography>
      </View>
      <View style={styles.buttonsBlock}>
        <Typography style={styles.buttonsBlockTitle}>ACCOUNT</Typography>
        <SettingsItem title="Personal Info" onPress={() => navigate(Routes.PersonalInfo)} />
        <SettingsItem title="Billing" onPress={Promise.resolve} />
        <SettingsItem
          title="Business Information"
          onPress={() => navigate(Routes.BusinessInformation)}
        />
        <SettingsItem
          title="Notifications"
          label={notificationsEnabled ? "On" : "Off"}
          onPress={() => navigate(Routes.SettingsNotifications)}
        />
      </View>
      <View style={[styles.buttonsBlock, isSipNotAvailable && styles.blockedButtonsBlock]}>
        {isSipNotAvailable && (
          <Typography>
            This feature is not available with your current subscription. Please{" "}
            <Typography style={styles.contactUs}>Contact Us</Typography> to enable.
          </Typography>
        )}
        <Typography
          style={[styles.buttonsBlockTitle, isSipNotAvailable && styles.blockedbuttonsBlockTitle]}
        >
          CALLS & MESSAGES
        </Typography>
        <SettingsItem
          title="Make and receive calls"
          label={callsSettings}
          onPress={() => navigate(Routes.SettingsMakeCalls)}
          blocked={isSipNotAvailable}
        />
        <SettingsItem
          title="GSM call settings"
          onPress={() => navigate(Routes.SettingsGSM)}
          blocked={isSipNotAvailable}
        />
      </View>
      <View style={styles.buttonsBlock}>
        <Typography style={styles.buttonsBlockTitle}>GENERAL</Typography>
        <SettingsItem title="Preferences" onPress={Promise.resolve} />
        <SettingsItem title="About" onPress={Promise.resolve} />
      </View>
      <View style={styles.buttonsBlock}>
        <Typography style={styles.buttonsBlockTitle}>GET HELP</Typography>
        <SettingsItem title="Terms & Conditions" onPress={Promise.resolve} />
        <SettingsItem title="Customer Support" onPress={Promise.resolve} />
      </View>
      <TouchableOpacity onPress={() => setLogOut(true)} style={styles.logOutBtn}>
        <Icon name="logOut" />
        <Typography style={styles.logOutText}>Log Out</Typography>
      </TouchableOpacity>
      <LogOutModal isVisible={logOut} onClose={() => setLogOut(false)} />
    </ScrollView>
  )
}
export const SettingsScreen = observer(Component)
