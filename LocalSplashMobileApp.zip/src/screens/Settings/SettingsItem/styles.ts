import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  btnContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16,
  },
  title: {
    fontSize: 16,
  },
  blockedText: {
    color: colors.greyDarkMode,
  },
  label: {
    color: colors.blue,
  },
}))
