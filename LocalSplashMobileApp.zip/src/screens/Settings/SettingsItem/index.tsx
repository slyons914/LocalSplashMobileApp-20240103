import { TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  title: string
  label?: string
  onPress: () => void
  blocked?: boolean
}

export const SettingsItem = ({ title, label, onPress, blocked }: Props) => {
  const styles = useStyles()

  const { text, greyDarkMode } = useColors()

  return (
    <TouchableOpacity onPress={onPress} style={styles.btnContainer} disabled={blocked}>
      <View>
        <Typography style={[styles.title, blocked && styles.blockedText]}>{title}</Typography>
        {label && (
          <Typography style={[styles.label, blocked && styles.blockedText]}>{label}</Typography>
        )}
      </View>
      <Icon name={"chevronRight"} stroke={blocked ? greyDarkMode : text} />
    </TouchableOpacity>
  )
}
