import { TouchableOpacity, View } from "react-native"

import { Icon, Typography } from "@components"

import { useStyles } from "./styles"

interface Props {
  title: string
  description: string
  isActive: boolean
  onPress: () => void
}

export const RenderItem = ({ title, description, onPress, isActive }: Props) => {
  const styles = useStyles()

  return (
    <View style={styles.itemContainer}>
      <TouchableOpacity onPress={onPress} style={[styles.button, isActive && styles.activeButton]}>
        <Typography>{title}</Typography>
        {isActive && <Icon name={"checkBlue"} />}
      </TouchableOpacity>
      <Typography>{description}</Typography>
    </View>
  )
}
