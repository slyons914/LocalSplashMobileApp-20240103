import { useCallback, useState } from "react"

import { View } from "react-native"

import { useFocusEffect } from "@react-navigation/native"
import { observer } from "mobx-react-lite"

import { SimpleHeader, Typography } from "@components"
import { MakeCalls } from "@models/settings"
import { useStore } from "@store"
import { Routes } from "@utils/constants"

import { RenderItem } from "./RenderItem"
import { useStyles } from "./styles"

const Component = ({ navigation }: ScreenProps<Routes.SettingsMakeCalls>) => {
  const styles = useStyles()
  const { goBack } = navigation

  const { settingsStore } = useStore()
  const { setCallsSettings, callsSettings } = settingsStore

  const [activeItem, setActiveItem] = useState(0)

  const onFirstPress = () => {
    setActiveItem(0)
    setCallsSettings(MakeCalls.wifi)
  }

  const onSecondPress = () => {
    setActiveItem(1)
    setCallsSettings(MakeCalls.carrier)
  }

  useFocusEffect(
    useCallback(() => {
      if (callsSettings === MakeCalls.wifi) {
        setActiveItem(0)
      } else {
        setActiveItem(1)
      }
    }, []),
  )

  return (
    <View style={styles.container}>
      <SimpleHeader onLeftPress={goBack} rightText={"Save"} isRightVisible />
      <Typography style={styles.screenTitle}>Make and receive calls</Typography>
      <RenderItem
        onPress={onFirstPress}
        title={"Prefer Wi-Fi and Mobile data"}
        description={
          "Make and receive calls over Wi-Fi and Mobile data when available. Carrier rates may apply if Wi-Fi is unavailable."
        }
        isActive={activeItem === 0}
      />
      <RenderItem
        onPress={onSecondPress}
        title={"Use carrier only"}
        description={"Carrier rates apply."}
        isActive={activeItem === 1}
      />
    </View>
  )
}

export const SettingsMakeCallsScreen = observer(Component)
