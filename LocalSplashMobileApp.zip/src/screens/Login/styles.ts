import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: insets.top + 8,
    paddingBottom: insets.bottom || 16,
    backgroundColor: colors.background,
    alignItems: "center",
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
    marginTop: 8,
  },
  text: {
    fontSize: 16,
    marginVertical: 24,
  },
  error: {
    color: colors.red,
    fontSize: 16,
    marginTop: 12,
  },
  spinner: {
    marginTop: 40,
  },
}))
