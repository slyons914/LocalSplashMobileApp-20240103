import { useState } from "react"

import { ActivityIndicator, View } from "react-native"

import { observer } from "mobx-react-lite"

import { AuthAPI } from "@api"
import { PhoneInput, SimpleHeader, Typography } from "@components"
import { useStore } from "@store"
import { colors, Routes } from "@utils/constants"

import { useStyles } from "./styles"

const Component = ({ navigation }: ScreenProps<Routes.Login>) => {
  const styles = useStyles()
  const { navigate, goBack } = navigation

  const [phone, setPhone] = useState<string>("")
  const [rawValue, setRawValue] = useState<string>("")
  const [errorText, setErrorText] = useState<string>("")
  const [isLoading, setIsLoading] = useState<boolean>(false)

  const { authStore } = useStore()
  const { setAuthState } = authStore

  const handleChangePhone = (text: string, rawPhone: string | undefined) => {
    setErrorText("")
    setRawValue(rawPhone!)
    setPhone(text)
  }

  const onSubmit = async () => {
    setIsLoading(true)
    const { data, error } = await AuthAPI.sendMessage(rawValue!)

    if (data) {
      setIsLoading(false)
      setAuthState(data.state)
      navigate(Routes.Code, { phoneNumber: phone!, phoneRawNumber: rawValue! })
    }
    if (error) {
      setIsLoading(false)
      setErrorText(error)
    }
  }

  return (
    <View style={styles.container}>
      <SimpleHeader
        rightText={"Next"}
        onLeftPress={goBack}
        onRightPress={onSubmit}
        isRightVisible={rawValue.length >= 10}
      />
      <Typography type={"title"} style={styles.title}>
        Your Phone Number
      </Typography>
      <Typography type={"subtext"} style={styles.text}>
        Enter your phone number to get started.
      </Typography>
      <PhoneInput value={phone!} handleChangePhone={handleChangePhone} onSubmitEditing={onSubmit} />
      {isLoading && (
        <ActivityIndicator
          style={styles.spinner}
          size={"large"}
          color={colors.common.orangePrimary}
        />
      )}
      {errorText && <Typography style={styles.error}>{errorText}</Typography>}
    </View>
  )
}

export const LoginScreen = observer(Component)
