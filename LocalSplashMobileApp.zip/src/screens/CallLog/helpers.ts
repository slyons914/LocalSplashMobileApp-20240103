import { CallLeadLog, LeadList } from "@models/leads"
import { FormatHelper } from "@utils/helpers"

const today = new Date()
today.setHours(0, 0, 0)

const yesterday = new Date(today)
yesterday.setDate(today.getDate() - 1)

export const groupLeadsToCallSections = (leads: LeadList<CallLeadLog> | null) => {
  if (!leads?.items?.length) return []

  const callMap = new Map<number, Map<number, CallLeadLog>>()

  leads.items.forEach((log) => {
    if (!log.createdAt) return

    const timeStamp = new Date(log.createdAt).setHours(0, 0, 0)

    const dayCalls = callMap.get(timeStamp) ?? new Map()
    const call = dayCalls.get(log.id)

    const leadName = FormatHelper.normalizeSpaces(log.leadName)
    const newDayCalls = call ? dayCalls : dayCalls.set(log.id, { ...log, leadName })

    callMap.set(timeStamp, newDayCalls)
  })

  return [...callMap.entries()].flatMap(([timeStamp, map]) => {
    const date = new Date(timeStamp)

    const isToday = date === today
    const isYesterday = date === yesterday

    let title = FormatHelper.formatDate(date, { year: true })

    if (isToday) {
      title = "Today"
    } else if (isYesterday) {
      title = `${title}, Yesterday`
    }

    return [title, ...map.values()]
  })
}
