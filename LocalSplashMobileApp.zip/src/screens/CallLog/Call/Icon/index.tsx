import { StyleProp, View, ViewStyle } from "react-native"

import { Icon } from "@components"
import { CallDirection, CallLeadLog, CallStatus } from "@models/leads"
import { colors } from "@utils/constants"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"

interface Props {
  filled?: boolean
  call: CallLeadLog
  style?: StyleProp<ViewStyle>
}

export const CallIcon = ({ filled, call, style }: Props) => {
  const { isSpam, isBlocked, callStatus, direction } = call

  const styles = useStyles()

  const { background, blocked } = useColors()

  const getColor = () => {
    if (isSpam || (callStatus && [CallStatus.HangUp, CallStatus.NoAnswer].includes(callStatus))) {
      return colors.common.red
    }

    if (isBlocked) {
      return blocked
    }

    if (direction === CallDirection.Inbound) {
      return colors.common.green
    }
  }

  const getIcon = () => {
    if (isSpam) {
      const stroke = filled ? background : colors.common.red
      return <Icon name={"spamCall"} stroke={stroke} />
    }

    if (isBlocked) {
      const stroke = filled ? background : blocked
      return <Icon name={"blockedCall"} stroke={stroke} />
    }

    if (callStatus === CallStatus.NoAnswer) {
      const stroke = filled ? background : colors.common.red
      return <Icon name={"missedCall"} stroke={stroke} />
    }

    if (direction === CallDirection.Inbound) {
      const stroke = filled ? background : colors.common.green
      return <Icon name={"incomingCall"} stroke={stroke} />
    }

    return null
  }

  const getStyle = (): ViewStyle => {
    const backgroundColor = filled ? getColor() : background

    return { backgroundColor, borderColor: getColor() }
  }

  return <View style={[styles.container, getStyle(), style]}>{getIcon()}</View>
}
