import { useState } from "react"

import { Dimensions, TouchableOpacity, View } from "react-native"

import { Icon, Track, Typography } from "@components"
import { CallLeadLog } from "@models/leads"
import { usePlayer } from "@providers"
import { FormatHelper } from "@utils/helpers"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"
import { CallHeader } from "../Header"
import { CallMenu } from "../Menu"

interface Props {
  call: CallLeadLog
  onHeadPress: () => void
  onCallPress: () => void
  onMessagePress: () => void
}

const { height } = Dimensions.get("screen")

export const FullInfo = ({ call, onHeadPress, onCallPress, onMessagePress }: Props) => {
  const [menuOffset, setMenuOffset] = useState(0)
  const [isMenuVisible, setIsMenuVisible] = useState(false)

  const styles = useStyles()
  const { text } = useColors()

  const { playing, loading, position, duration, showPlayer } = usePlayer()

  const name = call.leadName || ""
  const hasAudio = !!call.audioPath
  const date = FormatHelper.formatDate(call.createdAt, { time: true, year: true })

  const onLayout = (view: TouchableOpacity | null) => {
    view?.measureInWindow((_, y) => {
      setMenuOffset(y > height * 0.75 ? y - 160 : y + 12)
    })
  }

  const toggleMenu = () => {
    setIsMenuVisible((isVisible) => !isVisible)
  }

  return (
    <>
      <View>
        <CallHeader
          filledIcon
          call={call}
          title={name}
          onPress={onHeadPress}
          style={[styles.block, styles.header]}
        >
          <TouchableOpacity ref={onLayout} hitSlop={10} onPress={toggleMenu} style={styles.dots}>
            <Icon name={"dotsHorizontal"} stroke={text} width={24} height={24} />
          </TouchableOpacity>
        </CallHeader>
        <View style={[styles.block, styles.body]}>
          <View>
            <Typography style={styles.text}>Outgoing Call</Typography>
            <Typography style={styles.text}>{date}</Typography>
            {hasAudio && (
              <Typography style={styles.text}>Call duration: {Math.round(duration)} sec</Typography>
            )}
          </View>
          {hasAudio && (
            <Track
              loading={loading}
              playing={playing}
              position={position}
              duration={duration}
              onPlayToggle={showPlayer}
            />
          )}
        </View>
        <View style={[styles.block, styles.footer]}>
          <TouchableOpacity hitSlop={10} onPress={onCallPress} style={styles.action}>
            <Icon name={"phoneOutlined"} stroke={text} width={24} height={24} />
            <Typography style={styles.text}>Call {name}</Typography>
          </TouchableOpacity>
          <TouchableOpacity hitSlop={10} onPress={onMessagePress} style={styles.action}>
            <Icon name={"logMessage"} stroke={text} width={24} height={24} />
            <Typography style={styles.text}>Text {name}</Typography>
          </TouchableOpacity>
        </View>
      </View>
      <CallMenu call={call} visible={isMenuVisible} onClose={toggleMenu} offset={menuOffset} />
    </>
  )
}
