import { StyleProp, View, ViewStyle } from "react-native"

import { useNavigation } from "@react-navigation/native"

import { CallLeadLog } from "@models/leads"
import { Routes, Stacks } from "@utils/constants"
import { CallHelper } from "@utils/helpers"

import { FullInfo } from "./FullInfo"
import { ShortInfo } from "./ShortInfo"

interface Props {
  call: CallLeadLog
  expanded: boolean
  onToggle: () => void
  style?: StyleProp<ViewStyle>
}

export const Call = ({ call, expanded, onToggle, style }: Props) => {
  const { navigate } = useNavigation()

  const phoneNumber = CallHelper.getOpponentPhoneNumber(call)

  const onCallPress = () => {
    navigate(Routes.DialPad, { phoneNumber })
  }

  const onMessagePress = () => {
    navigate(Stacks.Home, { screen: Routes.Messages })
  }

  const props = { call, onCallPress, onMessagePress }

  return (
    <View style={style}>
      {expanded ? (
        <FullInfo onHeadPress={onToggle} {...props} />
      ) : (
        <ShortInfo onPress={onToggle} {...props} />
      )}
    </View>
  )
}
