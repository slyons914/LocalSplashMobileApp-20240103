import { withStyles } from "@utils/hocs"

const ICON_SIZE = 50

export const useStyles = withStyles(({ colors }) => ({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  left: {
    flexDirection: "row",
    gap: 12,
  },
  icon: {
    width: ICON_SIZE,
    height: ICON_SIZE,
    borderRadius: ICON_SIZE,
    backgroundColor: "red",
  },
  info: {
    justifyContent: "space-between",
  },
  title: {
    fontSize: 16,
    fontWeight: "500",
  },
  subtitle: {
    gap: 4,
    flexDirection: "row",
  },
  spam: {
    color: colors.red,
  },
  blocked: {
    color: colors.blocked,
  },
  date: {
    fontSize: 14,
    fontWeight: "300",
  },
}))
