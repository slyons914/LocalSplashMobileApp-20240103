import { PropsWithChildren } from "react"

import { StyleProp, TouchableOpacity, View, ViewStyle } from "react-native"

import { Typography } from "@components"
import { CallLeadLog, CallStatus } from "@models/leads"
import { FormatHelper } from "@utils/helpers"

import { useStyles } from "./styles"
import { CallIcon } from "../Icon"

interface Props {
  title: string
  filledIcon?: boolean
  call: CallLeadLog
  onPress: () => void
  style?: StyleProp<ViewStyle>
}

export const CallHeader = ({
  call,
  filledIcon,
  title,
  children,
  onPress,
  style,
}: PropsWithChildren<Props>) => {
  const styles = useStyles()

  const date = FormatHelper.formatDate(call.createdAt, { time: true, year: true })

  const noAnswer = call.callStatus === CallStatus.NoAnswer

  const getCallStatus = () => {
    if (call.isSpam) {
      return <Typography style={styles.spam}>Spam</Typography>
    }

    if (call.isBlocked) {
      return <Typography style={styles.blocked}>Blocked</Typography>
    }
  }

  return (
    <TouchableOpacity onPress={onPress} style={[styles.container, style]}>
      <View style={styles.left}>
        <CallIcon filled={filledIcon} call={call} />
        <View style={styles.info}>
          <Typography style={[styles.title, noAnswer && styles.spam]}>{title}</Typography>
          <View style={styles.subtitle}>
            {getCallStatus()}
            <Typography type={"subtext"} style={styles.date}>
              {date}
            </Typography>
          </View>
        </View>
      </View>
      {children}
    </TouchableOpacity>
  )
}
