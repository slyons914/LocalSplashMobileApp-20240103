import { TouchableOpacity, View, ViewStyle } from "react-native"

import Clipboard from "@react-native-clipboard/clipboard"
import Modal from "react-native-modal"

import { Icon, Typography } from "@components"
import { CallLeadLog } from "@models/leads"
import { CallHelper } from "@utils/helpers"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"
import { useProvider } from "../../provider"

interface Props {
  offset: number
  call: CallLeadLog
  visible: boolean
  onClose: () => void
}

export const CallMenu = ({ call, visible, offset, onClose }: Props) => {
  const styles = useStyles()
  const { text, background } = useColors()

  const { updateLead } = useProvider()

  const onCopyNumber = () => {
    const phoneNumber = CallHelper.getOpponentPhoneNumber(call)
    phoneNumber && Clipboard.setString(phoneNumber)
  }

  const onUpdateLead = (field: keyof CallLeadLog) => {
    return () => updateLead(call, field)
  }

  const style: ViewStyle = { top: offset }

  return (
    <Modal
      isVisible={visible}
      animationIn={"fadeIn"}
      animationOut={"fadeOut"}
      onBackdropPress={onClose}
      backdropColor={"transparent"}
    >
      <View style={[styles.modal, style]}>
        <TouchableOpacity onPress={onCopyNumber} style={styles.item}>
          <Typography>Copy Number</Typography>
          <Icon name={"copy"} stroke={text} fill={background} />
        </TouchableOpacity>
        <View style={styles.separator} />
        <TouchableOpacity
          disabled={!!call.isBlocked}
          onPress={onUpdateLead("isBlocked")}
          style={[styles.item, !!call.isBlocked && styles.disabled]}
        >
          <Typography>Block Number</Typography>
          <Icon name={"block"} stroke={text} fill={background} />
        </TouchableOpacity>
        <View style={styles.separator} />
        <TouchableOpacity
          disabled={!!call.isSpam}
          onPress={onUpdateLead("isSpam")}
          style={[styles.item, !!call.isSpam && styles.disabled]}
        >
          <Typography>Mark as spam</Typography>
          <Icon name={"info"} stroke={text} fill={background} />
        </TouchableOpacity>
      </View>
    </Modal>
  )
}
