import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, width }) => ({
  modal: {
    position: "absolute",
    width: width * 0.5,
    right: 12,
    borderRadius: 12,
    backgroundColor: colors.background,
  },
  item: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  disabled: {
    opacity: 0.4,
  },
  separator: {
    height: 1,
    backgroundColor: `${colors.text}30`,
  },
}))
