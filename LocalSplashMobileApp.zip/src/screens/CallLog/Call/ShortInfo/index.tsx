import { StyleProp, TouchableOpacity, View, ViewStyle } from "react-native"

import { Icon } from "@components"
import { CallLeadLog } from "@models/leads"
import { CallHelper, FormatHelper } from "@utils/helpers"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"
import { CallHeader } from "../Header"

interface Props {
  call: CallLeadLog
  onPress: () => void
  onCallPress: () => void
  onMessagePress: () => void
  style?: StyleProp<ViewStyle>
}

export const ShortInfo = ({ call, onPress, onCallPress, onMessagePress }: Props) => {
  const styles = useStyles()

  const { text } = useColors()

  const opponentNumber = CallHelper.getOpponentPhoneNumber(call)
  const phoneNumber = FormatHelper.formatPhoneNumber(opponentNumber)

  return (
    <CallHeader call={call} title={phoneNumber} onPress={onPress}>
      <View style={styles.content}>
        <TouchableOpacity hitSlop={10} onPress={onCallPress}>
          <Icon name={"phoneOutlined"} stroke={text} width={24} height={24} />
        </TouchableOpacity>
        <TouchableOpacity hitSlop={10} onPress={onMessagePress}>
          <Icon name={"logMessage"} stroke={text} width={24} height={24} />
        </TouchableOpacity>
      </View>
    </CallHeader>
  )
}
