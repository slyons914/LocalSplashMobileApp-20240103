import { ActivityIndicator, View } from "react-native"

import { Icon, Typography } from "@components"
import { colors } from "@utils/constants"

import { useStyles } from "./styles"

interface Props {
  isLoading: boolean
}

export const Placeholder = ({ isLoading }: Props) => {
  const styles = useStyles()

  return (
    <View style={styles.container}>
      {isLoading ? (
        <ActivityIndicator size={"large"} color={colors.common.orangePrimary} />
      ) : (
        <>
          <Icon name={"phoneCall"} />
          <Typography style={styles.text}>No calls yet.</Typography>
          <Typography style={styles.text}>Get started by calling a lead.</Typography>
        </>
      )}
    </View>
  )
}
