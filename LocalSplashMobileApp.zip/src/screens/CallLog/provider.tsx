import {
  FC,
  PropsWithChildren,
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react"

import { LeadsAPI } from "@api"
import { CallLeadLog, LeadLogType } from "@models/leads"
import { usePlayer } from "@providers"

import { groupLeadsToCallSections } from "./helpers"

type ListItem = string | CallLeadLog

interface CallLogContext {
  isLoading: boolean
  leads: Array<ListItem>
  expandedCall: CallLeadLog | null
  stickyIndecies: Array<number>
  toggleCall: (item: CallLeadLog) => void
  updateLead: (item: CallLeadLog, field: keyof CallLeadLog) => void
}

const initials: CallLogContext = {
  isLoading: false,
  leads: [],
  expandedCall: null,
  stickyIndecies: [],
  toggleCall: Promise.resolve,
  updateLead: Promise.resolve,
}

const CallLogContext = createContext(initials)

const CallLogProvider = ({ children }: PropsWithChildren) => {
  const [isLoading, setIsLoading] = useState(false)
  const [leads, setLeads] = useState<Array<ListItem>>([])
  const [expandedCall, setExpandedCall] = useState<CallLeadLog | null>(null)

  const { load, remove } = usePlayer()

  useEffect(() => {
    setIsLoading(true)
    LeadsAPI.getCtmLeadLogs(LeadLogType.Call)
      .then(({ data }) => setLeads(groupLeadsToCallSections(data)))
      .finally(() => setIsLoading(false))
  }, [])

  const toggleCall = (item: CallLeadLog) => {
    const isSamePress = expandedCall?.id === item.id
    remove()

    if (isSamePress) {
      setExpandedCall(null)
    } else {
      load(item)
      setExpandedCall(item)
    }
  }

  const updateLead = async (item: CallLeadLog, field: keyof CallLeadLog) => {
    await LeadsAPI.updateLead(item.leadId, { [field]: true })

    const newLeads = leads.map((lead) => {
      if (typeof lead !== "string" && lead.leadId === item.leadId) {
        return { ...lead, [field]: true }
      }

      return lead
    })

    setLeads(newLeads)
  }

  const stickyIndecies = useMemo(() => {
    return leads.reduce<Array<number>>((acc, item, index) => {
      if (typeof item === "string") return [...acc, index]
      return acc
    }, [])
  }, [])

  const value = { isLoading, leads, expandedCall, stickyIndecies, toggleCall, updateLead }

  return <CallLogContext.Provider value={value}>{children}</CallLogContext.Provider>
}

export const useProvider = () => useContext(CallLogContext)

export const withProvider = (Screen: FC) => {
  return () => {
    return (
      <CallLogProvider>
        <Screen />
      </CallLogProvider>
    )
  }
}
