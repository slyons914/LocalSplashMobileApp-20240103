import { useRef } from "react"

import { Platform, UIManager, LayoutAnimation, View } from "react-native"

import { FlashList } from "@shopify/flash-list"

import { Typography } from "@components"
import { CallLeadLog } from "@models/leads"

import { Call } from "./Call"
import { Placeholder } from "./Placeholder"
import { useProvider, withProvider } from "./provider"
import { useStyles } from "./styles"

type ListItem = string | CallLeadLog

if (Platform.OS === "android") {
  UIManager.setLayoutAnimationEnabledExperimental(true)
}

const Screen = () => {
  const styles = useStyles()

  const { isLoading, expandedCall, stickyIndecies, leads, toggleCall } = useProvider()

  const listRef = useRef<FlashList<ListItem>>(null)

  const onItemPress = (call: CallLeadLog) => {
    toggleCall(call)
    listRef.current?.prepareForLayoutAnimationRender()
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut)
  }

  const keyExtractor = (item: ListItem, index: number) => {
    if (typeof item === "string") {
      return index.toString()
    }
    return item.id.toString()
  }

  const renderItem = ({ item, index }: { item: ListItem; index: number }) => {
    const isHeader = typeof item === "string"

    if (isHeader) {
      return (
        <Typography type={"subtext"} style={styles.section}>
          {item}
        </Typography>
      )
    }

    const withIndent = typeof leads[index + 1] === "string"

    return (
      <Call
        call={item}
        onToggle={() => onItemPress(item)}
        expanded={expandedCall?.id === item.id}
        style={[styles.call, withIndent && styles.last]}
      />
    )
  }

  const isPlaceholderVisible = !leads.length || isLoading

  return (
    <View style={styles.container}>
      <Typography type={"title"} style={styles.title}>
        Call Log
      </Typography>
      <FlashList
        ref={listRef}
        data={leads}
        estimatedItemSize={100}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
        extraData={{ expandedCall, styles }}
        stickyHeaderIndices={stickyIndecies}
        scrollEnabled={!isPlaceholderVisible}
        ListEmptyComponent={<Placeholder isLoading={isLoading} />}
        overrideProps={{
          contentContainerStyle: isPlaceholderVisible && styles.list,
        }}
      />
    </View>
  )
}

export const CallLogScreen = withProvider(Screen)
