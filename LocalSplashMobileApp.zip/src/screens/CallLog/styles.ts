import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    flex: 1,
    gap: 16,
    paddingHorizontal: 24,
    backgroundColor: colors.background,
  },
  title: {
    fontSize: 24,
    fontWeight: "600",
  },
  list: {
    flex: 1,
    justifyContent: "center",
  },
  section: {
    fontSize: 16,
    fontWeight: "400",
    paddingBottom: 8,
    backgroundColor: colors.background,
  },
  call: {
    paddingVertical: 12,
  },
  first: {
    paddingTop: 16,
  },
  last: {
    marginBottom: 28,
  },
}))
