import { View } from "react-native"

import { Icon } from "@components"

import { useStyles } from "./styles"

export const BlueBlock = () => {
  const styles = useStyles()

  return (
    <View style={styles.container}>
      <View style={styles.messages}>
        <Icon name={"mockPush2"} style={styles.back} />
        <Icon name={"mockPush1"} style={styles.front} />
      </View>
    </View>
  )
}
