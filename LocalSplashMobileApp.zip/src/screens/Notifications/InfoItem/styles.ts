import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    flexDirection: "row",
    gap: 16,
    backgroundColor: colors.background,
    borderRadius: 20,
    padding: 10,
  },
  label: {
    fontSize: 16,
    fontWeight: "600",
  },
  text: {
    fontSize: 14,
    maxWidth: 280,
  },
}))
