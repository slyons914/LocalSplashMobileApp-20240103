import { View } from "react-native"

import { Icon, Typography } from "@components"

import { useStyles } from "./styles"

interface Props {
  icon: IconName
  label: string
  text: string
}

export const InfoItem = ({ icon, label, text }: Props) => {
  const styles = useStyles()

  return (
    <View style={styles.container}>
      <Icon name={icon} />
      <View>
        <Typography style={styles.label}>{label}</Typography>
        <Typography style={styles.text}>{text}</Typography>
      </View>
    </View>
  )
}
