import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: 16,
    paddingBottom: 40,
    alignItems: "center",
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    marginTop: 36,
  },
  infoBlock: {
    gap: 8,
    marginBottom: 36,
  },
  settingsText: {
    textAlign: "center",
    maxWidth: 300,
    fontSize: 16,
  },
  settings: {
    color: colors.orangePrimary,
  },
  buttonsContainer: {
    alignItems: "center",
    gap: 16,
    marginTop: 16,
  },
  anotherTime: {
    color: colors.orangePrimary,
  },
}))
