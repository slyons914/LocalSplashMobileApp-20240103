import { makeAutoObservable, runInAction } from "mobx"

import { MobileAPI } from "@api"
import { UserCallTrackingSipSettings } from "@models/home"
import { MakeCalls, RingerBehavior } from "@models/settings"

export class SettingsStore {
  notificationsEnabled: boolean = false
  callsSettings: MakeCalls = MakeCalls.wifi
  ringerBehavior: RingerBehavior = RingerBehavior.default
  sipSettings: UserCallTrackingSipSettings | null = null

  constructor() {
    makeAutoObservable(this)
  }

  setNotificationsState = (state: boolean) => {
    this.notificationsEnabled = state
  }

  setCallsSettings = (state: MakeCalls) => {
    this.callsSettings = state
  }

  setRingerBehavior = (state: RingerBehavior) => {
    this.ringerBehavior = state
  }

  checkSipSettings = async () => {
    const { data } = await MobileAPI.getSipSettings()
    runInAction(() => {
      this.sipSettings = data
    })
  }

  requestSipSettings = () => {
    MobileAPI.requestSipSettings()
  }
}
