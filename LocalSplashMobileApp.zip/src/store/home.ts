import { makeAutoObservable, runInAction } from "mobx"

import { MobileAPI } from "@api"
import {
  IGetProfileAnalyticsOverTimeResponseViewModel,
  IGetProfileAnalyticsResponseViewModel,
  IGetProfileListResponseViewModel,
  ProfileViewModel,
  UnreadLeads,
} from "@models"
import { DudaUrls } from "@models/home"

export class HomeStore {
  isLoading: boolean = false
  analyticsData: IGetProfileAnalyticsResponseViewModel | null = null
  profiles: IGetProfileListResponseViewModel | null = null
  unreadLeads: UnreadLeads | null = null
  analyticsOverTime: IGetProfileAnalyticsOverTimeResponseViewModel | null = null
  locationsIndex: number = 0
  locationsItem: ProfileViewModel | null = null
  dudaLinks: DudaUrls | null = null

  constructor() {
    makeAutoObservable(this)
  }

  setLocationsIndex = (index: number) => {
    this.locationsIndex = index
  }

  setLocationsItem = (item: ProfileViewModel) => {
    this.locationsItem = item
  }

  getAnalytics = async (id: number) => {
    this.isLoading = true

    const { data } = await MobileAPI.getAnalytics(id)
    runInAction(async () => {
      this.analyticsData = data
      this.isLoading = false
    })
  }

  filterAnalytics = async (id: number, fromDate: string, toDate: string) => {
    this.isLoading = true
    const { data } = await MobileAPI.filterAnalytics(id, fromDate, toDate)
    runInAction(async () => {
      this.analyticsData = data
      this.isLoading = false
    })
  }

  getAnalyticsOverTime = async (id: number) => {
    this.isLoading = true
    const { data } = await MobileAPI.getAnalyticsOverTime(id)
    runInAction(() => {
      this.analyticsOverTime = data
      this.isLoading = false
    })
  }

  filterAnalyticsOverTime = async (id: number, fromDate: string, toDate: string) => {
    this.isLoading = true
    const { data } = await MobileAPI.filterAnalyticsOverTime(id, fromDate, toDate)
    runInAction(() => {
      this.analyticsOverTime = data
      this.isLoading = false
    })
  }

  getProfiles = async () => {
    this.isLoading = true
    const { data } = await MobileAPI.getProfiles()
    runInAction(() => {
      this.profiles = data
      this.isLoading = false
    })
  }

  getUnreadLeads = async () => {
    this.isLoading = true
    const { data } = await MobileAPI.getUnreadLeads()
    runInAction(() => {
      this.unreadLeads = data
      this.isLoading = false
    })
  }

  getDudaUrls = async (id: number) => {
    this.isLoading = true
    const { data } = await MobileAPI.getWebsiteUrls(id)
    runInAction(() => {
      this.dudaLinks = data
      this.isLoading = false
    })
  }
}
