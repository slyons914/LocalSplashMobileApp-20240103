import { makeAutoObservable, runInAction } from "mobx"

import { BusinessInfoAPI } from "@api"
import {
  AvailableCategories,
  AvailableGoogleCategories,
  GetProfileLocation,
  PatchProfileLocation,
  ProfileGoogleCategories,
} from "@models/settings"

export class BusinessInfoStore {
  isLoading: boolean = false
  locationInfo: GetProfileLocation | null = null
  availableCategories: AvailableCategories | null = null
  availableGoogleCategories: AvailableGoogleCategories | null = null
  profileGoogleCategories: ProfileGoogleCategories | null = null

  constructor() {
    makeAutoObservable(this)
  }

  getLocationInfo = async (id: number) => {
    this.isLoading = true
    const { data } = await BusinessInfoAPI.getProfileLocation(id)
    runInAction(() => {
      this.locationInfo = data
      this.isLoading = false
    })
  }

  changeLocationinfo = (id: number, locationInfo: PatchProfileLocation) => {
    runInAction(async () => {
      this.isLoading = true
      await BusinessInfoAPI.changeProfileLocation(id, locationInfo)
      this.getLocationInfo(id)
      this.isLoading = false
    })
  }

  getAvailableCategories = async () => {
    this.isLoading = true
    const { data } = await BusinessInfoAPI.getAvailableCategories()
    runInAction(() => {
      this.availableCategories = data
      this.isLoading = false
    })
  }

  changeAvailableCategories = (profileId: number, id: number, customTitle?: string) => {
    runInAction(async () => {
      this.isLoading = true
      await BusinessInfoAPI.changeAvailableCategories(profileId, id, customTitle)
      this.isLoading = false
    })
  }

  getAvailableGoogleCategories = async () => {
    this.isLoading = true
    const { data } = await BusinessInfoAPI.getAvailableGoogleCategories()
    runInAction(() => {
      this.availableGoogleCategories = data
      this.isLoading = false
    })
  }

  getProfileGoogleCategories = async (id: number) => {
    this.isLoading = true
    const { data } = await BusinessInfoAPI.getProfileGoogleCategories(id)
    runInAction(() => {
      this.profileGoogleCategories = data
      this.isLoading = false
    })
  }
}
