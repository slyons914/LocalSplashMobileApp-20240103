import { createContext, useContext } from "react"

import { configure } from "mobx"

import { AuthStore } from "./auth"
import { BusinessInfoStore } from "./businessInfo"
import { HomeStore } from "./home"
import { SettingsStore } from "./settings"

configure({
  enforceActions: "never",
})
interface Store {
  authStore: AuthStore
  homeStore: HomeStore
  settingsStore: SettingsStore
  businessInfoStore: BusinessInfoStore
}

const store: Store = {
  authStore: new AuthStore(),
  homeStore: new HomeStore(),
  settingsStore: new SettingsStore(),
  businessInfoStore: new BusinessInfoStore(),
}

const storeContext = createContext(store)

export const useStore = () => {
  return useContext(storeContext)
}
