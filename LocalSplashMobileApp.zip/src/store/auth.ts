import { makeAutoObservable } from "mobx"

export class AuthStore {
  isLoggenIn: boolean = false
  isLoading: boolean = false
  authState: string = ""
  accessToken: string = ""

  constructor() {
    makeAutoObservable(this)
  }

  setAuthState = (state: string) => {
    if (state) this.authState = state
  }

  setAccessToken = (token: string) => {
    this.accessToken = token
  }
}
