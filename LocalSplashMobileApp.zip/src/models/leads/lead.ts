import { CtmLeadLog, FacebookLeadLog, LeadLogType, WebsiteFormLeadLog } from "./logs"

export interface Lead {
  id: number
  profileId?: number
  name?: string
  streetAddress?: string
  phoneNumber: number
  email?: string
  lastInAt: Date
  updatedAt?: Date
  isSpam?: boolean
  isBooked?: boolean
  lastLeadStructure: LeadLogType
  isBlocked?: boolean
  isResponded?: boolean
  requestedReviewAt?: Date
  websiteFormLeadLogs?: Array<WebsiteFormLeadLog>
  ctmLeadLogs?: Array<CtmLeadLog>
  facebookLeadLogs?: Array<FacebookLeadLog>
}
