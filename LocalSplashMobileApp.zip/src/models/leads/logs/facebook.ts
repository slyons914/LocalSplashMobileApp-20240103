import { LeadLog, LeadLogType } from "./base"

export interface FacebookLeadLog extends LeadLog {
  leadStructure: LeadLogType.Facebook
  campaignId?: string
}
