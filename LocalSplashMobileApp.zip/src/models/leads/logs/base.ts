export const enum LeadLogType {
  Website = 1,
  Call = 2,
  Sms = 4,
  Facebook = 16,
}

export interface LeadLog {
  id: number
  leadId: number
  isRead: boolean
  createdAt?: Date
  message?: string
}
