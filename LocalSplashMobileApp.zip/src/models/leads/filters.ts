export interface LeadFilters {
  isSpam?: boolean | null
  isBlocked?: boolean | null
  isRead?: boolean | null
  isBooked?: boolean | null
  ProfileId?: number | null
  FromDate?: string | null
  isResponded?: boolean | null
  ToDate?: string | null
  Search?: string
  AreCtmLeadLogsIncluded?: boolean
  AreWebsiteFormLeadLogsIncluded?: boolean
  AreFacebookLeadLogsIncluded?: boolean
}
