import { Lead } from "./lead"

export interface LeadListItem extends Lead {
  rowNumber: number
  isRead?: boolean
  lastLeadStructure?: number
}

export interface LeadList<T> {
  fromRowNumber?: number
  length?: number
  totalCount: number
  items?: Array<T>
}
