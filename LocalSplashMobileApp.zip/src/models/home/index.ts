export interface UserCallTrackingSipSettings {
  sipHost: string
  sipUsername: string
  sipPassword: string
  profileId: number
  isProfilePrimary: boolean
}

export interface DudaUrls {
  permalinkUrl: string
  ssoUrl: string
}
