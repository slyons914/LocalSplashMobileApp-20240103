export * from "./localsplash-mobile-api.service"

export interface SendMessageSuccessResponse {
  state: string
}
export interface SendMessageErrorResponse {
  title: string
}
export interface LoginSuccess {
  accessToken: string
  refreshToken: string
  accessTokenLifetime: number
  scope: string
}

export interface DecodedToken {
  amr: Array<string>
  aud: string
  auth_time: number
  client_id: string
  email: string
  exp: number
  family_name: string
  given_name: string
  iat: number
  idp: string
  iss: string
  jti: string
  name: string
  nbf: number
  phone_number: string
  scope: Array<string>
  sub: string
  t_and_c_accepted: string
}

export interface UnreadLeads {
  totalLeadCount: number
}

export type DataType = "reviews" | "insights" | "leads" | "listingsClicks" | "googleAdsClicks"

export type ResultsLabel =
  | "Local Leads"
  | "Google Profile Actions"
  | "Google Ads Clicks"
  | "Reviews"
  | "Listings Clicks"

export type Analytics = {
  googleAdsClicks: number
  googleProfileActions: number
  listings: number
  localLeads: number
  reviews: number
  totalResults: number
}

export type DateFilter = {
  fromDate: string
  toDate: string
}
