export interface GetProfileLocation {
  profileId: number
  name: string
  address: string
  address2: string
  city: string
  state: string
  zip: string
  countryCode: string
  phone: string
  email: string
  latitude: number
  longitude: number
  timeZone: string
  isHidden: true
  trackingPhone: string
  website: string
  isWebsiteEditable: boolean
}

export interface PatchProfileLocation {
  propertyName: PropertyName
  name?: string
  address?: Address
  phone?: string
  email?: string
  website?: string
}

export interface Address {
  address?: string
  address2?: string
  city?: string
  state?: string
  zip?: string
  countryCode?: string
  latitude?: number
  longitude?: number
  isHidden?: boolean
}

export type PropertyName = "name" | "address" | "phone" | "email" | "website"

export interface AvailableCategory {
  id: number
  name: string
  parentId: number
  updatedOn: string
  isEnabled: boolean
}
export interface AvailableCategories {
  categories: Array<AvailableCategory>
}
export interface AvailableGoogleCategory {
  id: number
  googleCategoryId: string
  name: string
  language: string
  region: string
  isActive: boolean
}
export interface AvailableGoogleCategories {
  googleCategories: Array<AvailableGoogleCategory>
}

export interface ProfileGoogleCategories {
  googleCategories: Array<string>
}
