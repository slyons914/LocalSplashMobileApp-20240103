import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, insets }) => ({
  container: {
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: colors.background,
    paddingTop: insets.top || 16,
    paddingHorizontal: 24
  },
  title: {
    fontSize: 16,
    flex: 0.5,
  },
  iconsContainer: {
    flexDirection: "row",
    flex: 0.5,
    gap: 24,
    justifyContent: "flex-end",
  },
}))
