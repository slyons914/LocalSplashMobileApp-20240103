import { TouchableOpacity } from "react-native"

import { Icon } from "../Icon"

interface Props {
  onPress: () => void
  value: boolean
}

export const Checkbox = ({ onPress, value }: Props) => {
  return (
    <TouchableOpacity onPress={onPress}>
      {value ? <Icon name={"checkboxActive"} /> : <Icon name={"checkboxInactive"} />}
    </TouchableOpacity>
  )
}
