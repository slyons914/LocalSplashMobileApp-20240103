import { useEffect } from "react"

import { Animated, useAnimatedValue } from "react-native"

import { colors } from "@utils/constants"

import { useStyles } from "./styles"

interface Props {
  height: number
  colored: boolean
}

export const Tile = ({ height, colored }: Props) => {
  const styles = useStyles()

  const backgroundValue = useAnimatedValue(0)

  useEffect(() => {
    Animated.timing(backgroundValue, {
      toValue: colored ? 1 : 0,
      duration: 100,
      useNativeDriver: false,
    }).start()
  }, [colored])

  const backgroundColor = backgroundValue.interpolate({
    inputRange: [0, 1],
    outputRange: [`${colors.common.dark}50`, colors.common.white],
  })

  return <Animated.View style={[styles.tile, { height, backgroundColor }]} />
}
