import { useEffect, useState } from "react"

import { Image, ImageBackground, TouchableOpacity, useColorScheme, View } from "react-native"

import { observer } from "mobx-react-lite"

import { MobileAPI } from "@api"
import { Icon, Typography } from "@components"
import { LocationsModal, ProfileActionsModal } from "@modals"
import { useStore } from "@store"

import { useStyles } from "./styles"

const Component = () => {
  const { homeStore } = useStore()
  const { profiles, locationsIndex, setLocationsIndex, setLocationsItem, getDudaUrls, dudaLinks } =
    homeStore

  const styles = useStyles()
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const [profileActions, setProfileActions] = useState(false)
  const [locationsModal, setLocationsModal] = useState(false)
  const [locationsLabel, setLocationsLabel] = useState<string>(profiles?.profiles![0].title || "")
  const [logoUrl, setLogoUrl] = useState<string | null>(null)

  const getLogo = async (id: number) => {
    const { data } = await MobileAPI.getLogo(id)
    if (data) {
      setLogoUrl(data.logoUrl!)
    }
  }

  useEffect(() => {
    const item = profiles?.profiles?.[locationsIndex]

    if (!item?.id || !item.title) return
    getLogo(item.id)
    getDudaUrls(item.id)
    setLocationsLabel(item.title)
    setLocationsItem(item)
  }, [profiles, locationsIndex])

  return (
    <View style={styles.container}>
      <ImageBackground source={require("./BackGroundImage.png")} style={styles.imageBlock}>
        <View style={styles.logoContainer}>
          {!!logoUrl && (
            <Image source={{ uri: logoUrl }} style={styles.logo} resizeMode={"cover"} />
          )}
        </View>
        <TouchableOpacity onPress={() => setProfileActions(true)} style={styles.orangeBtn}>
          <Icon name={"dotsVertical"} />
        </TouchableOpacity>
      </ImageBackground>
      <TouchableOpacity onPress={() => setLocationsModal(true)} style={styles.locationContainer}>
        <Typography style={styles.locationName}>{locationsLabel}</Typography>
        <Icon name={isLightTheme ? "chevronDown" : "chevronDownWhite"} />
      </TouchableOpacity>
      <ProfileActionsModal
        isVisible={profileActions}
        onClose={() => setProfileActions(false)}
        dudaLinks={dudaLinks}
      />
      <LocationsModal
        isVisible={locationsModal}
        onClose={() => setLocationsModal(false)}
        setLocationsLabel={setLocationsLabel}
        setLocationsIndex={setLocationsIndex}
        setLocationsItem={setLocationsItem}
        locationsIndex={locationsIndex}
      />
    </View>
  )
}

export const Logo = observer(Component)
