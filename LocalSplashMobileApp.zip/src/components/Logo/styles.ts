import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors, width }) => ({
  container: {
    marginVertical: 16,
    alignSelf: "center",
  },
  imageBlock: {
    height: 87,
    width: width * 0.85,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 9,
  },
  logoContainer: {
    height: 65,
    width: 65,
    backgroundColor: colors.white,
    borderRadius: 35,
    alignItems: "center",
    justifyContent: "center",
  },
  logo: {
    height: 36,
    width: 54,
  },
  orangeBtn: {
    height: 38,
    width: 38,
    borderRadius: 35,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.orangePrimary,
    position: "absolute",
    top: 10,
    right: 10,
  },
  locationContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  locationName: {
    fontSize: 16,
  },
}))
