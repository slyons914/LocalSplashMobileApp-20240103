import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
    width: "100%",
  },
  closeBtn: {
    color: colors.orangePrimary,
    fontSize: 16,
    fontWeight: "500",
  },
  title: {
    color: colors.text,
    fontSize: 16,
    fontWeight: "500",
  },
}))
