import { ActivityIndicator, Pressable, Text, useColorScheme, View } from "react-native"

import { colors } from "@utils/constants"

import { useStyles } from "./styles"
import { Icon } from "../Icon"
import { Typography } from "../Typography"

interface Props {
  onLeftPress: () => void
  onRightPress?: () => void
  rightText?: string
  isRightVisible?: boolean
  title?: string
  isLoading?: boolean
}

export const SimpleHeader = ({
  onLeftPress,
  onRightPress,
  rightText,
  isRightVisible,
  title,
  isLoading,
}: Props) => {
  const styles = useStyles()
  const systemColorScheme = useColorScheme()
  const isLightTheme = systemColorScheme === "light"

  const right = isLoading ? (
    <ActivityIndicator color={colors.common.orangePrimary} />
  ) : (
    <Text onPress={onRightPress} style={styles.closeBtn}>
      {rightText}
    </Text>
  )

  return (
    <View style={styles.container}>
      <Pressable hitSlop={5} onPress={onLeftPress}>
        <Icon name={isLightTheme ? "backIcon" : "bacIconWhite"} />
      </Pressable>
      {!!title && <Typography style={styles.title}>{title}</Typography>}
      {!!rightText && isRightVisible ? right : <View />}
    </View>
  )
}
