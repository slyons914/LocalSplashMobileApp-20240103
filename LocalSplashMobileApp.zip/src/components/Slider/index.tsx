import { memo, useEffect, useMemo, useRef } from "react"

import {
  Animated,
  LayoutRectangle,
  PanResponder,
  StyleProp,
  View,
  ViewStyle,
  useAnimatedValue,
} from "react-native"

import { useStyles } from "./styles"

interface Props {
  value?: number
  onChange?: (value: number) => void
  onChangeStop?: (value: number) => void
  style?: StyleProp<ViewStyle>
}

const Component = ({ value, onChange, onChangeStop, style }: Props) => {
  const styles = useStyles()

  const layout = useRef<LayoutRectangle | null>(null)

  const progress = useAnimatedValue(0)

  useEffect(() => {
    Animated.timing(progress, {
      toValue: value || 0,
      duration: 300,
      useNativeDriver: false,
    }).start()
  }, [value])

  const onLayout = (view: View | null) => {
    view?.measureInWindow((x, y, width, height) => {
      layout.current = { x, y, width, height }
    })
  }

  const calculateProgress = (moveX: number) => {
    if (!layout.current) return 0

    const { x, width } = layout.current

    if (moveX < x) return 0
    if (moveX > x + width) return 100

    return Math.round(((moveX - x) / width) * 100)
  }

  const { panHandlers } = useMemo(() => {
    return PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderMove: (_, { moveX }) => {
        const value = calculateProgress(moveX)
        progress.setValue(value)
        onChange?.call(null, value)
      },
      onPanResponderRelease: (_, { moveX }) => {
        const value = calculateProgress(moveX)
        onChangeStop?.call(null, value)
      },
    })
  }, [onChange, onChangeStop])

  const interpolatedValue = progress.interpolate({
    inputRange: [0, 100],
    outputRange: ["0%", "100%"],
  })

  const progressStyle: ViewStyle = { width: interpolatedValue }
  const thumbStyle: ViewStyle = { left: interpolatedValue }

  return (
    <View
      {...panHandlers}
      ref={onLayout}
      hitSlop={{ top: 10, bottom: 10 }}
      style={[styles.container, style]}
    >
      <Animated.View style={[styles.progress, progressStyle]} />
      <Animated.View style={[styles.thumb, thumbStyle]} />
    </View>
  )
}

export const Slider = memo(Component)
