import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  common: {
    fontFamily: "Poppins",
  },
  default: {
    color: colors.text,
  },
  title: {
    color: colors.title,
  },
  subtext: {
    color: colors.subText,
  },
}))
