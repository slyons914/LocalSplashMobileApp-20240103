import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {},
  textInput: {
    borderWidth: 1,
    borderColor: colors.gray6,
    borderRadius: 16,
    paddingVertical: 16,
    paddingHorizontal: 24,
    height: 60,
    backgroundColor: colors.background,
    color: colors.text,
  },
  row: {
    backgroundColor: colors.background,
  },
}))
