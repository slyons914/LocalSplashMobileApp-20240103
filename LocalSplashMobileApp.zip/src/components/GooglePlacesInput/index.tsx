import { GooglePlacesAutocomplete } from "react-native-google-places-autocomplete"

import { PLACES_API_TOKEN } from "@env"
import { Address } from "@models/settings"

import { useStyles } from "./styles"

interface Props {
  setAddress: (data: Address) => void
}

export const GooglePlacesInput = ({ setAddress }: Props) => {
  const styles = useStyles()

  return (
    <GooglePlacesAutocomplete
      placeholder="Search"
      minLength={2}
      debounce={500}
      keyboardShouldPersistTaps={"always"}
      onPress={(data, details = null) => {
        details &&
          setAddress({
            address: data.structured_formatting.main_text,
            address2: "",
            countryCode: data.structured_formatting.secondary_text.split(",")[2].trim(),
            city: data.structured_formatting.secondary_text.split(",")[0].trim(),
            state: data.structured_formatting.secondary_text.split(",")[1].trim(),
            zip: details.address_components.at(-2)!.long_name,
            latitude: details.geometry.location.lat,
            longitude: details.geometry.location.lng,
          })
      }}
      fetchDetails
      query={{
        key: PLACES_API_TOKEN,
        language: "en",
      }}
      styles={{
        container: styles.container,
        textInput: styles.textInput,
        poweredContainer: { display: "none" },
        row: styles.row,
      }}
    />
  )
}
