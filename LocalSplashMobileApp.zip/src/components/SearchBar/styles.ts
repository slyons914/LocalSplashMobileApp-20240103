import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    marginVertical: 15,
    height: 36,
    paddingHorizontal: 8,
    paddingVertical: 7,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.greyLight,
    borderRadius: 10,
  },
  input: {
    height: 40,
    borderColor: "gray",
    borderWidth: 1,
    paddingLeft: 10,
  },
}))
