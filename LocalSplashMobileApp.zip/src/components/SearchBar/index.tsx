import { useState } from "react"

import { StyleProp, TextInput, View, ViewStyle } from "react-native"

import { useStyles } from "./styles"
import { Icon } from "../Icon"

interface Props {
  value: string
  onSearch: (searchValue: string) => void
  placeholder: string
  style?: StyleProp<ViewStyle>
}

export const SearchBar = ({ value = "", onSearch, placeholder = "", style }: Props) => {
  const styles = useStyles()
  const [currentValue, setCurrentValue] = useState(value)

  const handleSearchChange = (text: string) => {
    setCurrentValue(text)
    onSearch(text)
  }

  return (
    <View style={[styles.container, style]}>
      <Icon name="search" />
      <TextInput
        inputMode="text"
        autoCapitalize="none"
        style={styles.container}
        placeholder={placeholder}
        value={currentValue}
        onChangeText={handleSearchChange}
      />
    </View>
  )
}
