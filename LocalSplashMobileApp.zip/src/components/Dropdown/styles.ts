import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    gap: 6,
  },
  inputLabel: {
    color: colors.text,
  },
  textInput: {
    borderWidth: 1,
    borderColor: colors.gray6,
    borderRadius: 8,
    paddingHorizontal: 24,
    paddingVertical: 16,
    color: colors.text,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  error: {
    borderColor: colors.red,
  },
  errorText: {
    color: colors.red,
  },
  disabled: {
    backgroundColor: colors.backgroundSecondary,
  },
  list: {
    backgroundColor: colors.background,
  },
  listItem: {
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  separator: {
    borderWidth: 1,
    borderColor: colors.backgroundSecondary,
  },
}))
