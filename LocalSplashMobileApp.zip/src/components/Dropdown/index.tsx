import { useState } from "react"

import { TextInput, TouchableOpacity, View } from "react-native"

import { FlashList } from "@shopify/flash-list"

import { AvailableCategories, AvailableCategory } from "@models/settings"
import { useColors } from "@utils/hooks"

import { useStyles } from "./styles"
import { Icon } from "../Icon"
import { Typography } from "../Typography"

interface Props {
  data: AvailableCategories
  value: string
  customTitle: string
  setValue: (text: string) => void
  setCustomTitle: (test: string) => void
  setSelectedItem: (item: AvailableCategory) => void
}

export const Dropdown = ({
  data,
  value,
  setValue,
  setSelectedItem,
  customTitle,
  setCustomTitle,
}: Props) => {
  const styles = useStyles()
  const { text } = useColors()

  const [isExpanded, setIsExpanded] = useState(false)

  const onDropdownPress = () => {
    setIsExpanded(!isExpanded)
  }

  const onItemPress = (item: AvailableCategory) => {
    setValue(item.name)
    setSelectedItem(item)
    setIsExpanded(!isExpanded)
  }

  const renderItem = ({ item }: { item: AvailableCategory }) => {
    return (
      <TouchableOpacity style={styles.listItem} onPress={() => onItemPress(item)}>
        <Typography>{item.name}</Typography>
      </TouchableOpacity>
    )
  }
  const itemSeparator = () => {
    return <View style={styles.separator} />
  }

  return (
    <>
      <TouchableOpacity onPress={onDropdownPress} style={styles.textInput}>
        <Typography>{value}</Typography>
        <Icon name={"chevronDown"} stroke={text} />
      </TouchableOpacity>
      {!isExpanded && value === "Other" && (
        <TextInput
          style={styles.textInput}
          value={customTitle}
          onChangeText={setCustomTitle}
          placeholder="Type your search phrase"
        />
      )}
      {isExpanded && (
        <FlashList
          contentContainerStyle={styles.list}
          data={data.categories}
          renderItem={renderItem}
          ItemSeparatorComponent={itemSeparator}
          estimatedItemSize={100}
        />
      )}
    </>
  )
}
