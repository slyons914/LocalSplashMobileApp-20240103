import { useEffect, useState } from "react"

import { View } from "react-native"

import { useStyles } from "./styles"
import { Typography } from "../Typography"

interface Props {
  timer: number | null
  onTimerEnd?: () => void
  duration: number
}

export const Timer = ({ timer, onTimerEnd, duration }: Props) => {
  const styles = useStyles()

  const [diff, setDiff] = useState<number | null>(null)

  useEffect(() => {
    if (timer) {
      const startsAt = timer
      const interval = setInterval(() => {
        let localDiff = (duration ? duration : 60 * 5) - (Date.now() - startsAt) / 1000
        if (localDiff <= 0) {
          onTimerEnd?.call(null)
          localDiff = 0
          clearInterval(interval)
        }
        setDiff(Math.round(localDiff))
      }, 100)
    } else {
      setDiff(null)
    }
  }, [timer])

  return (
    <View style={styles.container}>
      <Typography style={styles.text}>
        Resend Code in {("" + Math.floor(diff! / 60)).padStart(2, "0")}:
        {("" + (diff! % 60)).padStart(2, "0") + ""}
      </Typography>
    </View>
  )
}
