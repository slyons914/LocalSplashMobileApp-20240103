import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  container: {
    marginBottom: 40,
  },
  text: {
    color: colors.orangePrimary,
    fontSize: 16,
    fontWeight: "500",
  },
}))
