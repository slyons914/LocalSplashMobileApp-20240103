import { useState } from "react"

import { FlatList, StyleProp, TouchableOpacity, View, ViewStyle } from "react-native"

import Modal from "react-native-modal"

import { Icon, Typography } from "@components"

import { useStyles } from "./styles"

interface Props {
  speed: number
  onChange: (value: number) => void
  style?: StyleProp<ViewStyle>
}

const items = [0.75, 1, 1.25, 1.5, 2]

export const Speed = ({ speed, onChange, style }: Props) => {
  const [isMenuVisible, setIsMenuVisible] = useState(false)

  const styles = useStyles()

  const toggleMenu = () => {
    setIsMenuVisible((isVisible) => !isVisible)
  }

  const onItemChoose = (value: number) => {
    onChange(value)
    toggleMenu()
  }

  const renderItem = ({ item }: { item: number }) => {
    const isSelected = speed === item

    return (
      <TouchableOpacity onPress={() => onItemChoose(item)} style={[styles.menuItem, styles.row]}>
        <Typography style={styles.menuItemText}>{`${item}X Speed`}</Typography>
        {isSelected && <Icon name={"tick"} />}
      </TouchableOpacity>
    )
  }

  const separator = () => <View style={styles.separator} />

  const header = (
    <>
      <View style={styles.menuItem}>
        <Typography style={styles.menuItemText}>Select Playback Speed</Typography>
      </View>
      {separator()}
    </>
  )

  return (
    <>
      <TouchableOpacity onPress={toggleMenu} style={[styles.container, styles.row, style]}>
        <Typography style={styles.text}>{`${speed}X Speed`}</Typography>
        <Icon name={"chevronDownWhite"} width={16} height={16} />
      </TouchableOpacity>
      <Modal
        isVisible={isMenuVisible}
        animationIn={"fadeIn"}
        animationOut={"fadeOut"}
        onBackdropPress={toggleMenu}
        backdropColor={"none"}
        style={styles.modal}
      >
        <FlatList
          data={items}
          renderItem={renderItem}
          style={styles.menu}
          scrollEnabled={false}
          ListHeaderComponent={header}
          ItemSeparatorComponent={separator}
        />
      </Modal>
    </>
  )
}
