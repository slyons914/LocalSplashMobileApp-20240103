import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  locationContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: colors.backgroundSecondary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  locationName: {
    fontSize: 16,
    maxWidth: 310,
  },
}))
