import { TextInput, Pressable } from "react-native"

import { TextInputMask } from "react-native-masked-text"

import { useStyles } from "./styles"
import { Typography } from "../Typography"

interface Props {
  value: string
  label: string
  onChange?: (text: string) => void
  type?: "phone" | "default"
  error?: string
  setError?: (text: string) => void
  disabled?: boolean
  multiline?: boolean
  onPress?: () => void
  editable?: boolean
  onSubmitEditing?: () => void
}

export const Input = ({
  value,
  label,
  onChange,
  type = "default",
  error,
  setError,
  disabled,
  multiline,
  onPress,
  editable,
  onSubmitEditing,
}: Props) => {
  const styles = useStyles()

  const onChangeText = (text: string) => {
    onChange && onChange(text)
    setError && setError("")
  }

  return (
    <Pressable onPress={onPress} style={styles.container}>
      <Typography style={styles.inputLabel}>{label}</Typography>
      <>
        {type === "phone" ? (
          <TextInputMask
            onChangeText={(text) => onChangeText(text)}
            value={value}
            type={"cel-phone"}
            options={{
              maskType: "BRL",
              withDDD: true,
              dddMask: "(999) 999-9999",
            }}
            style={[styles.textInput, !!error && styles.error, disabled && styles.disabled]}
            placeholder={"Your phone number"}
            maxLength={14}
            textContentType={"telephoneNumber"}
            dataDetectorTypes={"phoneNumber"}
            includeRawValueInChangeText={true}
            editable={!disabled && editable}
            onSubmitEditing={onSubmitEditing}
          />
        ) : (
          <TextInput
            style={[styles.textInput, !!error && styles.error, disabled && styles.disabled]}
            value={value}
            onChangeText={onChangeText}
            editable={!disabled && editable}
            multiline={multiline}
            onSubmitEditing={onSubmitEditing}
          />
        )}
        {!!error && <Typography style={styles.errorText}>{error}</Typography>}
      </>
    </Pressable>
  )
}
