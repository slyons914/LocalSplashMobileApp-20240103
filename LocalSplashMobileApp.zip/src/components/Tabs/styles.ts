import { withStyles } from "@utils/hocs"

export const useStyles = withStyles(({ colors }) => ({
  content: {
    flexDirection: "row",
    gap: 8,
    height: 33,
    marginBottom: 24,
  },
  tab: {
    backgroundColor: colors.backgroundSecondary,
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 34,
  },
  tabText: {
    color: colors.greyDarkMode,
  },
  activeTab: {
    backgroundColor: colors.blue,
  },
  activeTabText: {
    color: colors.white,
  },
}))
