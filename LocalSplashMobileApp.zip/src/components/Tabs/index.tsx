import { useState } from "react"

import { FlatList, TouchableOpacity } from "react-native"

import { useStyles } from "./styles"
import { Typography } from "../Typography"

interface Props {
  tabs: Array<string>
}

export const Tabs = ({ tabs }: Props) => {
  const styles = useStyles()
  const [activeTab, setActiveTab] = useState(0)

  const renderItem = (item: string, index: number) => {
    return (
      <TouchableOpacity
        onPress={() => setActiveTab(index)}
        style={[styles.tab, activeTab === index && styles.activeTab]}
        key={item + index}
      >
        <Typography style={[styles.tabText, activeTab === index && styles.activeTabText]}>
          {item}
        </Typography>
      </TouchableOpacity>
    )
  }

  return (
    <FlatList
      contentContainerStyle={styles.content}
      data={tabs}
      renderItem={({ item, index }) => renderItem(item, index)}
      alwaysBounceHorizontal
      scrollEnabled
      horizontal
      showsHorizontalScrollIndicator={false}
    />
  )
}
