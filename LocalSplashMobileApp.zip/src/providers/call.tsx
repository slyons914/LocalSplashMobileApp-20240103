import { PropsWithChildren, createContext, useContext, useEffect, useRef } from "react"

import { observer } from "mobx-react-lite"
import RNCallKeep, { IOptions } from "react-native-callkeep"
import uuid from "react-native-uuid"

import { useStore } from "@store"
import { SipHelper } from "@utils/helpers"

interface CallContext {
  setup: () => Promise<boolean>
  startCall: (phoneNumber: string) => void
}

const initials: CallContext = {
  setup: () => Promise.resolve(false),
  startCall: Promise.resolve,
}

const options: IOptions = {
  ios: {
    appName: "LocalSplash",
  },
  android: {
    alertTitle: "Permissions required",
    alertDescription: "LocalSplash needs to access your phone accounts",
    cancelButton: "Cancel",
    okButton: "ok",
    imageName: "phone_account_icon",
    additionalPermissions: [],
    foregroundService: {
      channelId: "com.localsplash.mobile",
      channelName: "Foreground service for LocalSplash",
      notificationTitle: "LocalSplash is running on background",
      notificationIcon: "Path to the resource icon of the notification",
    },
  },
}

const CallContext = createContext(initials)

const Provider = ({ children }: PropsWithChildren) => {
  const { settingsStore } = useStore()

  const { sipSettings } = settingsStore

  const callId = useRef<string | null>(null)

  useEffect(() => {
    if (!sipSettings) return

    setup()

    SipHelper.login(sipSettings)

    const incomingListener = SipHelper.addEventListener(
      "incomingReceived",
      ({ displayName, username }) => {
        if (callId.current) return

        const id = uuid.v4().toString()
        callId.current = id
        RNCallKeep.displayIncomingCall(id, displayName, username, "number", false)
      },
    )

    const answerListener = RNCallKeep.addEventListener("answerCall", ({ callUUID }) => {
      RNCallKeep.setCurrentCallActive(callUUID)
      SipHelper.answerCall()
    })

    const releaseListener = SipHelper.addEventListener("callReleased", () => {
      if (!callId.current) return

      RNCallKeep.endCall(callId.current)
      callId.current = null
    })

    const endCallListener = RNCallKeep.addEventListener("endCall", () => {
      SipHelper.endCall()
      callId.current = null
    })

    const speakerListener = RNCallKeep.addEventListener("didChangeAudioRoute", ({ output }) => {
      SipHelper.changeAudioOutput(output)
    })

    const dtmfListener = RNCallKeep.addEventListener("didPerformDTMFAction", ({ digits }) => {
      SipHelper.sendDtmf(digits)
    })

    return () => {
      incomingListener.remove()
      answerListener.remove()
      releaseListener.remove()
      endCallListener.remove()
      speakerListener.remove()
      dtmfListener.remove()
    }
  }, [sipSettings])

  const setup = () => {
    return RNCallKeep.setup(options)
  }

  const startCall = (phoneNumber: string) => {
    if (!sipSettings) return

    const id = uuid.v4().toString()
    callId.current = id

    RNCallKeep.startCall(id, phoneNumber, phoneNumber)
    SipHelper.startCall(phoneNumber, sipSettings.sipHost)
  }

  const value = { setup, startCall }

  return <CallContext.Provider value={value}>{children}</CallContext.Provider>
}

export const CallProvider = observer(Provider)

export const useCall = () => useContext(CallContext)
