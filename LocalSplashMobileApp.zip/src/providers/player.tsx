import { PropsWithChildren, createContext, useContext, useEffect, useState } from "react"

import TrackPlayer, {
  useIsPlaying,
  useProgress,
  usePlaybackState,
  State,
} from "react-native-track-player"

import { Player } from "@components"
import { CallLeadLog } from "@models/leads"

interface Context {
  playing?: boolean
  loading: boolean
  track: CallLeadLog | null
  position: number
  duration: number
  load: (value: CallLeadLog) => void
  remove: () => void
  showPlayer: () => void
  loadTracks: (value: CallLeadLog) => void
  playTrack: (value: CallLeadLog) => void
}

const initials: Context = {
  playing: false,
  loading: true,
  track: null,
  position: 0,
  duration: 0,
  load: Promise.resolve,
  remove: Promise.resolve,
  loadTracks: Promise.resolve,
  showPlayer: Promise.resolve,
  playTrack: Promise.resolve,
}

const PlayerContext = createContext(initials)

export const PlayerProvider = ({ children }: PropsWithChildren) => {
  const [isPlayerVisible, setIsPlayerVisible] = useState(false)
  const [track, setTrack] = useState<CallLeadLog | null>(null)
  const [tracks, setTracks] = useState<CallLeadLog[]>([])

  const [loading, setLoading] = useState(true)

  const { playing } = useIsPlaying()
  const { state } = usePlaybackState()
  const { position, duration } = useProgress()

  useEffect(() => {
    TrackPlayer.setupPlayer()
  }, [])

  useEffect(() => {
    if (!state || [State.None, State.Loading].includes(state)) {
      setLoading(false)
    } else if (state === State.Ready) {
      setLoading(false)
    }
  }, [state])

  const load = (track: CallLeadLog) => {
    setTrack(track)
    const url = track.audioPath
    url && TrackPlayer.load({ url })
  }

  const loadTracks = (track: CallLeadLog) => {
    setTracks((prevTracks: CallLeadLog[]) => [...prevTracks, track])
    // TrackPlayer.add(tracks)
  }

  const playTrack = (track: CallLeadLog) => {
    const current = tracks.find((item: { id: number }) => item.id === track.id)

    current && TrackPlayer.load({ url: current.audioPath || "" })
  }

  const remove = () => {
    TrackPlayer.stop()
    setTrack(null)
  }

  const showPlayer = () => {
    setIsPlayerVisible(true)
  }

  const onPlayerClose = () => {
    setIsPlayerVisible(false)
  }

  const value = {
    playing,
    loading,
    track,
    position,
    duration,
    load,
    remove,
    showPlayer,
    loadTracks,
    playTrack,
  }

  return (
    <PlayerContext.Provider value={value}>
      {children}
      <Player visible={isPlayerVisible} onClose={onPlayerClose} />
    </PlayerContext.Provider>
  )
}

export const usePlayer = () => useContext(PlayerContext)
