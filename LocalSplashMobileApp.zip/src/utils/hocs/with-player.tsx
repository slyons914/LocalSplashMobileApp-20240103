import { FC } from "react"

import { PlayerProvider } from "@providers"

export const withPlayer = (Component: FC) => {
  return () => (
    <PlayerProvider>
      <Component />
    </PlayerProvider>
  )
}
