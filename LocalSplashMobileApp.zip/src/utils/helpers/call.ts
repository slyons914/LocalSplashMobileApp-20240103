import { CallDirection, CallLeadLog } from "@models/leads"

export class CallHelper {
  static getOpponentPhoneNumber(call: CallLeadLog) {
    const { direction, callerNumber, trackingNumber } = call

    return direction === CallDirection.Inbound ? callerNumber : trackingNumber
  }
}
