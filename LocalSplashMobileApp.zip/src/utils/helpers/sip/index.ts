import { NativeModules, NativeEventEmitter } from "react-native"

import { UserCallTrackingSipSettings } from "@models/home"

import { Event, EventHandler } from "./types"

const { SipModule } = NativeModules

const EventEmitter = new NativeEventEmitter(SipModule)

const audioOutputMap: Record<string, number> = {
  receiver: 2,
  earpiece: 2,
  speaker: 3,
}

export class SipHelper {
  static login(settings: UserCallTrackingSipSettings) {
    const { sipUsername, sipPassword, sipHost } = settings

    SipModule.login(sipUsername, sipPassword, sipHost)
  }

  static startCall(phoneNumber: string, domain: string) {
    SipModule.startCall(phoneNumber, domain)
  }

  static answerCall() {
    SipModule.answerCall()
  }

  static endCall() {
    SipModule.endCall()
  }

  static sendDtmf(dtmf: string) {
    SipModule.sendDtmf(dtmf)
  }

  static changeAudioOutput(value: string) {
    SipModule.changeAudioOutput(audioOutputMap[value.toLowerCase()])
  }

  static toggleMicrophone() {
    SipModule.toggleMicrophone()
  }

  static addEventListener<T extends Event>(event: T, handler: EventHandler[T]) {
    return EventEmitter.addListener(event, handler)
  }
}
