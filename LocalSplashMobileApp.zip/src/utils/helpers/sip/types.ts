export type Event = "incomingReceived" | "callReleased"

interface IncomingCallPayload {
  displayName: string
  username: string
}

export interface EventHandler {
  incomingReceived: (payload: IncomingCallPayload) => void
  callReleased: () => void
}
