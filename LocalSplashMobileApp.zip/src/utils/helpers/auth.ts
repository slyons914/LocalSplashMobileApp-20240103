import jwt_decode from "jwt-decode"

import { DecodedToken } from "@models"
import { StorageHelper } from "@utils/helpers"

export class AuthHelper {
  static async getIsAuthorized() {
    const accessToken = await StorageHelper.get<string>("accessToken")
    if (!accessToken) return false
    const decoded: DecodedToken = jwt_decode(accessToken)
    const termsAccepted = decoded.t_and_c_accepted === "true"
    return Date.now() <= decoded.exp * 1000 && termsAccepted
  }

  static async logout() {
    await StorageHelper.set("accessToken", null)
  }
}
