interface DateFormatOptions {
  time?: boolean
  year?: boolean
}

export class FormatHelper {
  static formatPhoneNumber(value?: string) {
    if (!value) return ""

    return value.replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2 - $3")
  }

  static capitalizeFirstLetter(inputString: string) {
    if (inputString.length === 0) {
      return inputString
    } else {
      return inputString[0].toUpperCase() + inputString.slice(1)
    }
  }

  static formatDateString = (date: Date) => {
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, "0")
    const day = String(date.getDate()).padStart(2, "0")
    return `${year}-${month}-${day}`
  }

  static formatDate(value?: Date, options?: DateFormatOptions) {
    if (!value) return ""

    const date = new Date(value)
    const isPastYear = date.getFullYear() < new Date().getFullYear()

    const [dateSting, yearString] = date
      .toLocaleDateString("en-US", {
        year: options?.year && isPastYear ? "numeric" : undefined,
        month: "short",
        day: "2-digit",
      })
      .split(", ")

    if (!options?.time) {
      return yearString ? `${dateSting}, ${yearString}` : dateSting
    }

    const timeString = date.toLocaleTimeString("en-US", {
      hour12: true,
      hour: "numeric",
      minute: "numeric",
    })

    return `${dateSting}, ${yearString ? `${yearString} ${timeString}` : timeString}`
  }

  static formatTimeToDuration(value: number) {
    const rounded = Math.round(value)

    const minutes = Math.floor(rounded / 60)
    const seconds = rounded % 60

    const minutesString = (minutes < 10 ? "0" : "") + minutes
    const secondsSting = (seconds < 10 ? "0" : "") + seconds

    return `${minutesString}:${secondsSting}`
  }

  static normalizeSpaces(value?: string) {
    return value?.replace(/\s+/g, " ")
  }
}
