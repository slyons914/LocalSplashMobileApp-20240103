package com.localsplash.mobile.sip

import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import org.linphone.core.*

class SipModule(reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {
    private val appContext = reactContext.applicationContext
    private val reactContext = reactContext
    private val factory = Factory.instance()
    private var core: Core

    private val call
        get() = core.currentCall ?: core.calls.getOrNull(0)

    private val coreListener = object : CoreListenerStub() {
        override fun onCallStateChanged(
            core: Core,
            call: Call,
            state: Call.State?,
            message: String
        ) {
            when (state) {
                Call.State.IncomingReceived -> {
                    val payload = Arguments.createMap()
                    payload.putString("displayName", call.remoteAddress.displayName)
                    payload.putString("username", call.remoteAddress.username)

                    sendEvent("incomingReceived", payload)
                }

                Call.State.Released -> {
                    sendEvent("callReleased")
                }

                else -> {}
            }

            super.onCallStateChanged(core, call, state, message)
        }
    }

    init {
        if(BuildConfig.DEBUG) {
            factory.setDebugMode(true, "DEBUG")
        }

        core = factory.createCore(null, null, appContext)
    }

    override fun getName(): String {
        return "SipModule"
    }

    @ReactMethod
    fun addListener(eventName: String) {

    }

    fun sendEvent(eventName: String, payload: WritableMap? = null) {
        reactContext
            .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
            .emit(eventName, payload)
    }

    @ReactMethod
    fun removeListeners(count: Int) {

    }

    @ReactMethod
    fun login(username: String, password: String, domain: String, promise: Promise) {
        val authInfo = factory.createAuthInfo(username, null, password, null, null, domain, null)

        val params = core.createAccountParams()
        val identityAddress = factory.createAddress("sip:$username@$domain")
        params.identityAddress = identityAddress
        params.registerEnabled = true

        val serverAddress = factory.createAddress("sip:$domain")
        serverAddress?.transport = TransportType.Tls
        params.serverAddress = serverAddress

        val account = core.createAccount(params)

        core.addAuthInfo(authInfo)
        core.addAccount(account)
        core.defaultAccount = account

        core.addListener(coreListener)
        core.start()
    }

    @ReactMethod
    fun startCall(phone: String, domain: String) {
        val address = core.interpretUrl("${phone}@${domain}")
        address?.displayName = "Caller"
        address ?: return

        val params = core.createCallParams(null)
        params ?: return

        core.inviteAddressWithParams(address, params)
    }

    @ReactMethod
    fun answerCall() {
        call?.accept()
    }

    @ReactMethod
    fun endCall() {
        call?.terminate()
    }

    @ReactMethod
    fun sendDtmf(dtmf: String) {
        call?.sendDtmf(dtmf.single())
    }

    @ReactMethod
    fun changeAudioOutput(output: Int) {
        call?.outputAudioDevice = core.audioDevices.firstOrNull {
            it.type == AudioDevice.Type.values().elementAtOrNull(output)
        }
    }

    @ReactMethod
    fun toggleMicrophone() {
        core.enableMic(!core.micEnabled())
    }
}