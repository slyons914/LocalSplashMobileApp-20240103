declare module "*.svg" {
  import { FC } from "react"

  import { SvgProps } from "react-native-svg"
  const content: FC<SvgProps>
  export default content
}

declare module "@env" {
  export const {
    SIP_USERNAME,
    SIP_PASSWORD,
    SIP_DOMAIN,
    AUTH_API_URL,
    MOBILE_API_URL,
    PLACES_AUTOCOMPLETE_URL,
    PLACES_API_TOKEN,
  }: Record<string, string>
  export const { MIXPANEL_TOKEN }: Record<string, string>
}
